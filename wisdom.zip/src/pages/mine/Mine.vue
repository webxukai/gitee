<template>
    <div>
        <MineVideo />
        <MineMenu />
    </div>
</template>

<script>
import MineVideo from "./components/Video"
import MineMenu from "./components/Menu"
export default {
name:'Mine',
components:{
    MineVideo,
    MineMenu
}
}
</script>

<style>

</style>
