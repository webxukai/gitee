<template>
  <div>
      
  </div>
</template>

<script>
export default {
  name: "Login",
  components: {},
  data() {
    return {};
  },
  methods: {},
  computed: {}
};
</script>

<style lang="stylus" scoped>
</style>