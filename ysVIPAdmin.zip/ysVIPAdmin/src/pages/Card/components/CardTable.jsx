
/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import {Search,DatePicker,Button} from '@icedesign/base';
import net from '@/net.js'
import { hashHistory } from 'react-router';
import { connect } from 'react-redux'
import Dialog from '@/components/Dialog'
import { Grid } from "@icedesign/base";
const { Row, Col } = Grid;

@connect((state)=>{
  return {
    token:state.user.token,
    config:state.user.config
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.columns = [
      {
        title:"卡ID",
        key:'kid',
        dataIndex:"kid",
      },{
        title:"用户手机号",
        key:"userMobile",
        dataIndex:"userMobile",
        render: (value, index, record) => {
          var str = record.userMobile
          var str2 = str.substr(0,3)+" **** "+str.substr(7)
          return (
              <div>{str2}</div>
            )
        }
     },{
        title:"余额",
        key:"balance",
        dataIndex:"balance"
      },{
        title:"赠送余额",
        key:"giveMoney",
        dataIndex:"giveMoney"
      },{
        title:"卡属性",
        key:"properties",
        dataIndex:"properties"
     },{
        title:"赠送余额到期时间",
        key:"giveMoneyTime",
        dataIndex:"giveMoneyTime",
        render:(value,index,record)=>{
          return <div>{record.giveMoneyTime == '2000-01-01 00:00:00' ? '永久': record.giveMoneyTime}</div>
        }
     },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          var str =''
          if(record.discount == undefined){
            str = ''
          }else{
            str = Number(record.discount)*100+'%'
          }
          return (
            <div>
              <span style={{color:"#2077FF",cursor:'pointer',margin:'0 5px'}} title='查看账单'  onClick={()=>hashHistory.push('/card/info/'+record.kid)} >查看账单</span>
              <span style={{color:"#2077FF",cursor:'pointer',margin:'0 5px'}} title='查看实体卡'  onClick={()=>hashHistory.push('/entityCard/'+record.userKid)} >查看实体卡</span>
              <Dialog title='卡详情' trigger={<span style={{color:"#2077FF",cursor:'pointer'}} title='查看实体卡'>卡详情</span>}>
                <div style={styles.con_details}>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>卡KID：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.kid}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>用户KID：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.userKid}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>用户手机号：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.userMobile}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>用户等级：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.grade}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>累计充值：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.totalRecharge}</div>
                    </Col>
                  </Row>



                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>累计消费：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.totalConsumer}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>余额：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.balance}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>赠送余额：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.giveMoney}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>赠送余额到期时间：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.giveMoneyTime == '2000-01-01 00:00:00' ? '永久': record.giveMoneyTime}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>卡创建时间：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.createTime}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>卡属性：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.properties}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>折扣：</div>
                    </Col>
                    <Col span="12">
                      <div>{str}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>特价类型：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.specialType}</div>
                    </Col>
                  </Row>

                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>积分：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.integral}</div>
                    </Col>
                  </Row>

                </div>
              </Dialog>
            </div>

          );
        }}
      ];
    this.state = {
      data:[
        {
          nowPage:1,
          pageSize:1,
          count:0,
          // userSetMealList:[
          rows:[

            {
              'kid':'',
              'balance':0,
              'giveMoney':0,
              'giveMoneyTime':0,
              'merchantKid':'',
              'merchantName':'',
              'properties':'',
              'userKid':'',
              'userMobile':0,
            }
          ]
        }
      ]
    }
  }
  componentDidMount() {
    this.queryCache = {
      limit:10,
      page:1,
      phone:''
    }
    this.fetchData();
  }

  //卡列表接口
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/set-meal/user-set-meals',
      data:this.queryCache
    })
    console.log(data)
    this.setState({
      data
    })
  }
  search = (value)=>{
    this.queryCache.phone = value.key;
    this.fetchData();
  }
  changePage = (currentPage) => {
    this.queryCache.nowPage = currentPage;
    this.fetchData();
  }
  filterFormChange = (value) => {
    this.queryCache = {
      ...this.queryCache,
      startTime:new Date(value[0]).getTime(),
      endTime:new Date(value[1]).getTime(),
    };
    this.fetchData();
  }

  render() {
    const tableData = this.state.data;
    console.log (tableData)
    return (
      <div>
        <IceContainer title="卡列表">
          <div style={{float:'right',marginBottom:'26px',display:'flex',flexWrap:"wrap"}}>
            <Search onSearch={this.search} searchText="" placeholder="请输入手机号" style={{margin:'5px'}}/>
          </div>
          <CustomTable
            dataSource={tableData.rows}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
            pageData = {{
                        current:tableData.nowPage,
                        pageSize:tableData.pageSize,
                        total:tableData.count,
                        onChange:this.changePage,
                        }}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  details: {
    background:'rgba(0,0,0,0)',
    color: "#2077FF",cursor:'pointer',margin:'0',
  },
  con_details: {
    fontSize:'16px',
    padding: '15px'
  },
  row: {
    padding:'10px',
    borderBottom: '1px solid #eee'
  },
  col: {
    textAlign:'right',
    paddingRight:'10px'
  }
};
