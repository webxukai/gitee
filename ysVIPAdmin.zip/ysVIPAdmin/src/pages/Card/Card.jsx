
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import CardTable from './components/CardTable'

import './Card.scss';

export default class Card extends Component {
  static displayName = 'Card';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    var breadcrumb;
    if(this.props.children){
      breadcrumb = [
        { text: '卡管理', link: '' },
        { text: '卡列表', link: '#/card/list' },
        { text: '卡账单详情', link: '' },
      ];
    }
    else{
      breadcrumb = [
        { text: '卡管理', link: '' },
        { text: '卡列表', link: '#/card/list' },
      ];
    }
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <div style={{display:this.props.children ? 'none':'block'}}>
          <CardTable />
        </div>
        <div className={this.props.children ? 'buttonClick' : ''}>
          { this.props.children }
        </div>
      </div>
    );
  }
}
