
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import PayTable from './components/PayTable'
import DataCard from './components/DataCard'
import './PayRecord.scss';

export default class PayRecord extends Component {
  static displayName = 'PayRecord';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const breadcrumb = [
      { text: '账单管理', link: '' },
      { text: '账单记录', link: '#/record/list' },
    ];
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <DataCard />
        <PayTable />
      </div>
    );
  }
}
