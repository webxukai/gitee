import React, { Component } from 'react';
import { toThousands } from '@/utils'
import StatisticalCard from '@/components/StatisticalCard'
import net from '@/net.js'
const dataSource = [
  {
    text: '今日消费金额',
    icon:"xiaofeijilu",
    desc: "todaConsumeMoneyNumber",
    filed:"todaConsumeMoneyComputed"
  },
  {
    text: '今日充值金额',
    icon:"jinrigaikuang_jinrichongzhi",
    desc: 'todayRechargeMoneyNumber',
    filed:"todayRechargeMoneyComputed"
  },
  {
    text: '总消费金额',
    icon:"jinrixiaofei",
    desc: 'totalConsumeMoneyNumber',
    filed:"totalConsumeMoneyComputed"
  },
  {
    text: '总充值金额',
    icon:"weibiaoti-",
    desc: 'totalRechargeMoneyNumber',
    filed:"totalRechargeMoneyComputed"
  }
];

export default class DataCard extends Component {
  static displayName = 'DataCard';

  constructor(props) {
    super(props);
    this.state = {
      data: {
        // todayConsumeMoney:0,
        // todayRechargeMoney:0,
        // totalConsumeMoney:0,
        // totalRechargeMoney:0
        todayConsumeGiveMoney: 0,
        todayConsumeMoney: 0,
        todayRechargeGiveMoney: 0,
        todayRechargeMoney: 0,
        totalConsumeGiveMoney: 0,
        totalConsumeMoney: 0,
        totalRechargeGiveMoney: 0,
        totalRechargeMoney: 0,

        ConsumeMoney:0
      }
    }
  }

  componentDidMount() {
    this.fetchData()
  }
  //账单记录标题
  fetchData = async () => {
    var data = await net.get({
      url:'/memberAdmin/bill/money-info',
    })
    this.setState({
      data:{
        todayConsumeMoney:Math.round(data.todayConsumeMoney*100)/100,
        todayRechargeMoney:Math.round(data.todayRechargeMoney*100)/100,
        totalConsumeMoney:Math.round(data.totalConsumeMoney*100)/100,       
        totalRechargeMoney:Math.round(data.totalRechargeMoney*100)/100,
        
        todayConsumeGiveMoney:Math.round(data.todayConsumeGiveMoney*100)/100,
        todayRechargeGiveMoney:Math.round(data.todayRechargeGiveMoney*100)/100,
        totalConsumeGiveMoney:Math.round(data.totalConsumeGiveMoney*100)/100,
        totalRechargeGiveMoney:Math.round(data.totalRechargeGiveMoney*100)/100,

        todaConsumeMoneyNumber:'赠送：' + data.todayConsumeGiveMoney + '  消费：' + data.todayConsumeMoney,
        todayRechargeMoneyNumber:'赠送：' + data.todayRechargeGiveMoney + '  充值：' + data.todayRechargeMoney,
        totalConsumeMoneyNumber:'赠送：' + data.totalConsumeGiveMoney + '  消费：' + data.totalConsumeMoney,
        totalRechargeMoneyNumber:'赠送：' + data.totalRechargeGiveMoney + '  充值：' + data.totalRechargeMoney,

        todaConsumeMoneyComputed: data.todayConsumeMoney + data.todayConsumeGiveMoney,
        todayRechargeMoneyComputed: data.todayRechargeGiveMoney + data.todayRechargeMoney,
        totalConsumeMoneyComputed: data.totalConsumeGiveMoney + data.totalConsumeMoney,
        totalRechargeMoneyComputed: data.totalRechargeGiveMoney + data.totalRechargeMoney
      }
    })
  }
  render() {
    return (
      <StatisticalCard dataSource={this.state.data} items={dataSource}/>
    );
  }
}
