/* eslint no-underscore-dangle: 0 */
//import store from './redux/store';
import React, { Component } from 'react';
import { Table , moment } from "@icedesign/base";
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import Dialog from '@/components/Dialog'
import {Search,DatePicker,Button,Feedback} from '@icedesign/base';
const { MonthPicker, YearPicker, RangePicker } = DatePicker;
import net from '@/net.js'
import { connect } from 'react-redux'
import { Grid } from "@icedesign/base";
import { mul } from '@/utils'
const { Row, Col } = Grid;
const consumerType = ['储蓄金额','现金金额','微信','支付宝']
@connect((state)=>{
  return {
    token:state.user.token,
    config:state.user.config
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.queryCache2 = {};
    this.columns = [
    {
        title:"卡号",
        key:'userSetMealKid',
        dataIndex:"userSetMealKid"
      },
      {
        title:"订单号",
        key:'kid',
        dataIndex:"kid"
      },
      {
        title:"消费类型",
        key:"consumerType",
        dataIndex:"consumerType",
        render:(value,index,record)=>{
          if(record.consumerType == null || record.consumerType == undefined){
            record.consumerType = ''
          }
          var type = record.consumerType + '';
          var typeList = type.split(','),
              str = '';
         typeList.forEach((type,index)=>{
          if(index == typeList.length - 1){
            str+=consumerType[type]
          }
          else{
            str+=consumerType[type]+' , '
          }
         })
         return <div>{str}</div>
        }
      },{
        title:"交易金额",
        key:"money",
        dataIndex:"money"
      },{
        title:"赠送交易金额",
        key:"money",
        dataIndex:"giveMoney"
      },{
        title:"交易时间",
        key:"createTime",
        dataIndex:"createTime"
      },{
        title:"详情信息",
        key:"information",
        render:(value,index,record) => {
          var str = ''
          var disCount1 =''
          var disCount2 =''
          if (record.discount) {
            if( record.discount.split(',')[0] == undefined){
              disCount1 = ''
            }else{
              disCount1 = mul(Number(record.discount.split(',')[0]),100)+'%'
            }
            if( record.discount.split(',')[1] == undefined){
              disCount2 = ''
            }else{
              disCount2 = mul(Number(record.discount.split(',')[1]),100)+'%'
            }
          }
          if(record.consumerType == null || record.consumerType == undefined){
            record.consumerType = ''
          }
          var type = record.consumerType + '';
          var typeList = type.split(','),
              str = '';
          typeList.forEach((type,index)=>{
            if(index == typeList.length - 1){
              str+=consumerType[type]
            }
            else{
              str+=consumerType[type]+' , '
            }
          })
          return (
              <div>
                <Dialog title='账单详情' style={styles.details}>
                  <div style={styles.con_details}>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡号：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userSetMealKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡所属者名：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userCardName}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡所属者：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userCardKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作类型：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.type}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>之前的特价,最新的特价：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.specialOffer}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作用户名：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.operatorUserName}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作用户kid：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.operatorUserKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易金额：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.money}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>订单号：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.kid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>赠送金额：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.giveMoney}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>之前的折扣,最新的折扣：</div>
                      </Col>
                      <Col span="12">
                        <div>{disCount1},{disCount2}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易时间：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.createTime}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易类型：</div>
                      </Col>
                      <Col span="12">
                        <div>{str}</div>
                      </Col>
                    </Row>
                  </div>
               </Dialog>
              </div>
            )
        }
      },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          return (
            <span>
              <Button type='primary' size='small' onClick={() => this.out_alone(record)}>导出</Button>

            </span>
          );
        }
      }];
    this.state = {
      data:{
         limit:10,
         page:2,
         merchantConsumerRecordRespList:[
          
        ],
        total:0
      },
      startDate:null,
      rowSelection: {
        onChange: this.onChange.bind(this),
        selectedRowKeys: []
      },
      disabledDate : (calendarDate)=> {
        var startDate = this.state.startDate || new Date();
        const { year, month, date } = calendarDate;
        const nowMonth = startDate.getMonth();
        const nowYear = startDate.getFullYear();
        const theDate = moment(`${year}-${month + 1}`, "YYYY-M");
        if(!this.state.startDate){
          return theDate > moment(`${nowYear}-${nowMonth + 1}`, "YYYY-M");
        }
        else{
          return theDate > moment(`${nowYear}-${nowMonth + 1}`, "YYYY-M") || theDate < moment(`${nowYear}-${nowMonth + 1}`, "YYYY-M");
        }
      }
    }
  }
  componentDidMount() {
    this.queryCache = {
        limit:10,
        page:1,
        month:this.getDate(new Date()).substring(0,6),
        startDay:this.firstDay(),
        stopDay:this.lastDay()
    }
    this.queryCache2={
        month:'',
        kids:[]
    }
    this.fetchData();
  }

  //获取指定月份第一天
  firstDay() {
    return (this.getDate(new Date()).substring(0,6)+'01')
  }

  //获取指定月份最后一天
  lastDay() {
   var Year = parseInt(this.getDate(new Date()).substring(0,4)) ;
   var Month = this.getDate(new Date()).substring(4,6);
   switch(Month) {
    case '01':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '02':
      if(Year % 4 == 0 && Year % 100 != 0) {
         return this.getDate(new Date()).substring(0,6)+'29'
         console.log('闰年')
       }else{
        return this.getDate(new Date()).substring(0,6)+'28'
       }
      break;
    case '03':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '04':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '05':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '06':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '07':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '08':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '09':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '10':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '11':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '12':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
   }
  }
  //账单记录接口
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/bill/merchant-records',
      data:this.queryCache
    })
    this.setState({
      ...this.queryCache,
      data
    })
  }
  onChange(ids, records) {
    let { rowSelection } = this.state;
    rowSelection.selectedRowKeys = ids;
    this.setState({ rowSelection });
  }
  search = (value)=>{
    if(!value.key){
      delete this.queryCache.setMealKid
    }
    else{
      this.queryCache.setMealKid = value.key;
    }
    this.fetchData();
  }
  changePage = (currentPage) => {
    this.queryCache.page = currentPage;

    this.fetchData();
  }
  onStartChange = (value) =>{
    this.setState({
      startDate:value
    })
  }
  filterFormChange = (value) => {
    if(value[0] == null){
      var startDate = this.firstDay();
      var stopDate = this.lastDay();
    }
    else{
      var startDate = new Date(value[0])
      var endDate = new Date(value[1])
      var startDate = this.getDate(startDate)
      var stopDate = this.getDate(endDate)
    }
    this.queryCache = {
      ...this.queryCache,
      startDay:startDate,
      stopDay:stopDate,
    };
    this.fetchData();
  }
   onPageSizeChange = (pageSize)=>{
    this.queryCache.limit = pageSize;
    this.fetchData()
  }
  //批量导出
  out = async ({pointReward})=>{
    var ids = this.state.rowSelection.selectedRowKeys

    if(ids.length == 0){
      Feedback.toast.error('请至少选择一条记录');
      return false;
    }else{
      this.queryCache2.kids = this.state.rowSelection.selectedRowKeys
      this.queryCache2.month = this.queryCache.month
      this.getOut()
    }
  }
  //单个导出
  out_alone =  (record)=>{
    this.queryCache2.kids=[record.kid]
    this.queryCache2.month = this.queryCache.month
     this.getOut()
  }
  //商户账单记录导出接口
  getOut = async ()=>{
    var  data = await net.downLoad({
      url:'/memberAdmin/bill/merchant-records.xlsx',
      data:this.queryCache2
    })
    var date=new Date();
    var blob = new Blob([data]);
    var url = window.URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download ='商户账单记录'+ this.getDate(date)+'.xlsx';
    link.click();
    // if(data=true){
    //   Feedback.toast.success('导出成功')
    //   this.fetchData()
    //   this.queryCache2.kids=[]
    //   this.queryCache2.month = ''
    // }
    // else{
    //   Feedback.toast.error('导出失败')
    // }
  }
  //日期转化
  getDate(date) {
    var year = date.getFullYear()
    var month = date.getMonth()+1
    var date = date.getDate()
    if(month < 10){
      month = '0' + month
    }
    if(date < 10){
      date = '0' + date
    }
    return (year.toString() + month.toString() + date.toString())
  }

  render() {
    const tableData = this.state;
    return (
      <div>
        <IceContainer title="账单记录">
          <Button onClick={this.out} type="primary">批量导出</Button>
          <div style={{float:'right',marginBottom:'26px',display:'flex',flexWrap:"wrap"}}>

            <RangePicker name='time' onChange={this.filterFormChange} style={{margin:'5px'}}  onStartChange={this.onStartChange }disabledDate={this.state.disabledDate}/>
            {/*<div>
              <DatePicker.MonthPicker name='time'  style={{margin:'0 5px'}} onChange={this.changeMonth} />
              <DatePicker name='time'  style={{margin:'0 5px'}} defaultValue={this.state.startTime}/>--
              <DatePicker name='time'  style={{margin:'0 5px'}} defaultValue={this.state.stopTime}/>
            </div>*/}
            <Search onSearch={this.search} searchText="" placeholder="请输入卡名称" style={{margin:'5px'}}/>

          </div>
          <CustomTable
            dataSource={tableData.data.merchantConsumerRecordRespList}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
            rowSelection = {this.state.rowSelection}
            pageData = {{
                        current:tableData.page,
                        pageSize:tableData.limit,
                        total:tableData.data.total,
                        onChange:this.changePage,
                        pageSizeSelector:"dropdown",
                        pageSizeList:[10,100,1000],
                        onPageSizeChange:this.onPageSizeChange
                      }}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  details: {
    background:'rgba(0,0,0,0)',
    color: "#2077FF",cursor:'pointer',margin:'0',
  },
  con_details: {
    fontSize:'16px',
    padding: '15px'
  },
  row: {
    padding:'10px',
    borderBottom: '1px solid #eee'
  },
  col: {
    textAlign:'right',
    paddingRight:'10px'
  }
};
