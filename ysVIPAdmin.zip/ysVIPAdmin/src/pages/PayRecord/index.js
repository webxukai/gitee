import PayRecord from './PayRecord';

export default PayRecord;
