
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import ComboTable from './components/ComboTable'


export default class Combo extends Component {
  static displayName = 'Combo';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const breadcrumb = [
      { text: '套餐管理', link: '' },
      { text: '套餐列表', link: '#/combo/list' },
    ];
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <ComboTable />
      </div>
    );
  }
}
