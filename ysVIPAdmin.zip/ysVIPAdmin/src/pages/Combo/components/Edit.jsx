import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
	}
	componentDidMount(){
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	getValue = async (value)=>{
		await this.updateTab(value)
		this.refs.dialog.onClose();
		this.props.fetchData();
	}
	updateTab = async (value)=>{
		var data = await net.put({
			url:'/memberAdmin/set-meal/',
			data: {
				donationAmount: value.donationAmount,
				grade: value.grade,
				kid:value.kid,
				name:value.name,
				rechargeAmount: value.rechargeAmount,
				donationExpireDays:value.donationExpireDays
			}
		})
		if(data = true){
			Feedback.toast.success('修改成功')
		}else{
			Feedback.toast.error('修改失败')
		}
	}
	render(){
		var {record,...others} = this.props
		return (
			<Dialog title='修改' handleSubmit ={this.handleSubmit} ref="dialog" size="small" {...others}>
				<LabelForm ref='form' getValue={this.getValue} record={record} flag={this.props.flag}/>
			</Dialog>
			)
	}
}