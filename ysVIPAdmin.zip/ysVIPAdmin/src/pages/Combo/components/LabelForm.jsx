import React, { Component } from 'react';
import { Form, Input, Field,Select,Balloon,Icon,moment } from '@icedesign/base';
import { connect } from 'react-redux'
import net from '@/net';
import { DatePicker } from "@icedesign/base";
import { DateDiff } from '@/utils'
const { MonthPicker, YearPicker, RangePicker } = DatePicker;
const FormItem = Form.Item;

// @connect((state)=>{
//   return {
//     token:state.user.token,
//     settingList:state.user.settingList
//   }
// },(dispatch)=>{
//   return {
//     setConfig:(value)=>dispatch(setConfig(value))
//   }
// })
export default class MyForm extends Component {
  static displayName = 'MyForm';

  static defaultProps = {};

  constructor(props) {

    super(props);
    this.state={
      flag:this.props.flag
    }
    this.field = new Field(this);
  }
  componentDidMount(){
    var record = this.props.record;
    if(record && record.donationExpireTime){
      if(record.donationExpireTime == '2000-01-01 00:00:00'){
        record.donationExpireDays = 0;
      }
      else{
        var day = DateDiff(moment(record.donationExpireTime).format('YYYY-MM-DD'),moment(new Date()).format('YYYY-MM-DD'))
        record.donationExpireDays = day
      }
    }
    this.field.setValues(record);
  }
  check = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        console.log('Errors in form!!!');
        return;
      }
      this.props.getValue(values);
    });
  };
  render() {
    const init = this.field.init;
    const formItemLayout = {
      labelCol: {
        fixedSpan: 8,
      },
      wrapperCol: {
        span: 14,
      },
    };
    var help = <div style={styles.help}>
                <Balloon
                    align="t"
                    alignment="edge"
                    trigger={
                      <span>
                        <Icon type="help" style={styles.helpIcon} size="xs" />
                      </span>
                    }
                    closable={false}
                  >
                  输入0代表永久有效
                </Balloon>
              </div>,
        child = this.props.flag ? <div><FormItem label="赠送金额：" {...formItemLayout}>
                    <Input
                      {...init('donationAmount',{
                        rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                      })}
                    />
                </FormItem>
                <FormItem label="赠送金额到期天数：" {...formItemLayout}>
                    { help }
                    <Input
                      {...init('donationExpireDays',{
                        rules: [{ required: true, message: '必填选项' },{pattern:/^([1-9]\d*|[0]{1,1})$/,message:"请输入有效天数"}],
                      })}
                    />
                </FormItem></div> : "" 
    return (
         <Form direction="ver" field={this.field}>
            <FormItem label="套餐名称：" {...formItemLayout}>
              <Input
               {...init('name',{
                  rules: [{ required: true, message: '必填选项' }],
                })}
              />
            </FormItem>
            <FormItem label="充值金额：" {...formItemLayout}>
               <Input
                 {...init('rechargeAmount',{
                    rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                  })}
                />
            </FormItem>
            { child }
            <FormItem label="级别：" {...formItemLayout}>
              <Select
                {...init('grade',{
                  rules: [{ required: true, message: '必填选项' }]
                })}>
                {
                  Array.apply(null,{length:16}).map((item,index)=>{
                    return <option value={index+''} key={index}>{index}等级</option>
                  })
                }
              </Select>
            </FormItem>
        </Form>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    marginRight: '5px',
  },
  show: {
    display:'block',
    position:'relative'
  },
  hide: {
    display:'none'
  },
  help:{
    position:"absolute",
    right:"-20px",
    top:"50%",
    transform: "translateY(-50%)"
  }
};
