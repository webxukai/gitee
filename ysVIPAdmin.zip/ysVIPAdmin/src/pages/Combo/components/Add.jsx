import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	componentDidMount(){
	}
	getValue = async (value)=>{
		await this.updateTab(value)
		this.refs.dialog.onClose();
		this.props.fetchData();
	}
	updateTab = async (value)=>{
		var time=''
		var data = await net.post({
			url:'/memberAdmin/set-meal/',
			data:{
				donationAmount: value.donationAmount,
				grade: value.grade,
				name: value.name,
				rechargeAmount: value.rechargeAmount,
				donationExpireDays:value.donationExpireDays
			}
		})
		if( data = true) {
			Feedback.toast.success('新增成功')
			//this.props.FetchData()
		}else{
			Feedback.toast.error('新增失败')
		}
	}
	render(){
		return (
			<Dialog title='新增套餐' handleSubmit ={this.handleSubmit} ref="dialog">
				<LabelForm ref='form' getValue={this.getValue} flag={this.props.flag}/>
			</Dialog>
			)
	}
}