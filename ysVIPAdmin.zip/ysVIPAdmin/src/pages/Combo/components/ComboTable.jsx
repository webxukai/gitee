/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import CustomTable from '@/components/CustomTable'
import DeleteBalloon from '@/components/DeleteBalloon'
import Dialog from '@/components/Dialog'
import Edit from './Edit'
import Add from './Add'
import net from '@/net.js'
import { Feedback } from "@icedesign/base";
import { connect } from 'react-redux'
import { Grid } from "@icedesign/base";
const { Row, Col } = Grid;

@connect((state)=>{
  return {
    token:state.user.token,
    settingList:state.user.settingList
  }
},(dispatch)=>{
  return {
    setConfig:(value)=>dispatch(setConfig(value))
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.columns = [
    {
      title:"套餐ID",
      key:"kid",
      dataIndex:"kid"
    },
    {
      title:"套餐名称",
      key:"name",
      dataIndex:"name"
    },{
      title:"充值金额",
      key:"rechargeAmount",
      dataIndex:"rechargeAmount",
    },{
      title:"赠送金额",
      key:"donationAmount",
      dataIndex:"donationAmount",
      render:(value,index,record)=>{
        return <div>{record.donationAmount || '无'}</div>
      }
    },{
      title:"赠送金额到期时间",
      key:"donationExpireTime",
      dataIndex:"donationExpireTime",
      render:(value,index,record)=>{
        return <div>{record.donationExpireTime == '2000-01-01 00:00:00' ? '永久' : record.donationExpireTime || '无'}</div>
      }
    },{
      title:"级别",
      key:"grade",
      dataIndex:"grade",
      render:(value,index,record)=>{
        return <div>{record.grade}等级</div>
      }
    },{
        title: '查看详情',
        key: 'information',
        render: (value, index, record) => {
          return (
            <div>
              <Dialog title='套餐详情' style={styles.details}  >
                <div style={styles.con_details}>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>套餐KID：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.kid}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>套餐名称：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.name}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>赠送金额：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.donationAmount || '无'}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>赠送金额到期时间：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.donationExpireTime == '2000-01-01 00:00:00' ? '永久' : record.donationExpireTime || '无'}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>等级：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.grade}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>充值金额：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.rechargeAmount}</div>
                    </Col>
                  </Row>
                  <Row style={styles.row}>
                    <Col span="8">
                      <div style={styles.col}>充送扣费比：</div>
                    </Col>
                    <Col span="12">
                      <div>{record.takeChargeFee || '无'}</div>
                    </Col>
                  </Row>
                </div>
              </Dialog>
            </div>
          );
        }
      },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          return (
            <div>
              <Edit record = {record} fetchData={this.fetchData} flag={!!this.props.settingList[1].enable}/>
              <DeleteBalloon handleRemove={()=>this.handleRemove(record.kid)}/>
            </div>
          );
        },
      }]
    this.state = {
      flag: !!this.props.settingList[1].enable,
      data: [{
        donationExpireTime:'',
        setMealKid:'',
        donationAmount:0,
        grade:'',
        name:'',
        rechargeAmount:0,
        takeChargeFee:''
      }],
      columns:this.columns
    };
  }
  componentDidMount() {
    this.queryCache={

      }

    this.setColumns(this.props);
    this.fetchData();
  }
  handleRemove = async (kid) =>{
    var data = await  net.delete({
      url:'/memberAdmin/set-meal/',
      data:{
        setMealKid: kid
      }
    })
    if(data){
      Feedback.toast.success('删除成功')
      this.fetchData()
    }else{
      Feedback.toast.error('删除失败')
    }
  }
  setColumns = (value)=>{
      // if(!value.settingList[1].enable){
      //   var columns = this.state.columns.filter((item)=>{
      //     if(item.key == 'donationAmount' || item.key == 'donationExpireTime'){
      //       return false;
      //     }
      //     return true;
      //   })
      //   this.setState({
      //     columns
      //   })
      // }
      // else{
      //   this.setState({
      //     columns:this.columns
      //   })
      // }
  }
  componentWillReceiveProps(nextProps){
    // if(nextProps.config != this.props.config){
    //   this.setColumns(nextProps)
    // }
  }




  fetchData = async () => {
    var data = await net.get({
      url:'/memberAdmin/set-meal/set-meals',
    })
    this.setState({
      data
    })
  }
  render() {
    const { filterFormValue } = this.state;
    return (
      <div>
        <IceContainer title="套餐设置">
          <Add fetchData={this.fetchData} flag={!!this.props.settingList[1].enable}/>
          <CustomTable
            dataSource={this.state.data}
            className="basic-table"
            style={styles.basicTable}
            columns={this.state.columns}
            hasBorder={false}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  details: {
    background:'rgba(0,0,0,0)',
    color: "#2077FF",cursor:'pointer',margin:'0',
  },
  con_details: {
    fontSize:'16px',
    padding: '15px'
  },
  row: {
    padding:'10px',
    borderBottom: '1px solid #eee'
  },
  col: {
    textAlign:'right',
    paddingRight:'10px'
  }
};
