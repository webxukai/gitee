import Combo from './Combo';

export default Combo;
