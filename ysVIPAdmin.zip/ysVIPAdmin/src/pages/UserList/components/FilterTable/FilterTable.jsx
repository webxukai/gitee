/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import { Table, Pagination,Search,Overlay} from '@icedesign/base';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import IceLabel from '@icedesign/label';
import CustomTable from './../../../../components/CustomTable'
import FilterForm from './Filter';
import { enquireScreen } from 'enquire-js';
import net,{imgURL} from '../../../../net.js'
import Add from './Add'
import { connect } from 'react-redux'

@connect((state)=>{
  return {
    token:state.user.token
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.state = {
      nowImg:'',
      visible:false,
      data:{
        rows:[],
        pageSize:1,
        total:1,
        nowPage:1
      }
    };
    this.columns = [
    {
      title:"昵称",
      key:"nickName",
      dataIndex:"nickName",
      sortable:true
    },{
      title:'头像',
      key:"avatarUrl",
      dataIndex:"avatarUrl",
      render:this.renderAvatar,
    },
    {
      title:'手机号',
      key:"userPhone",
      dataIndex:"userPhone",
      sortable:true
    },{
      title:"金额",
      key:"tokenMoney",
      dataIndex:"tokenMoney",
      sortable:true
    },{
      title:"分享次数",
      key:"shareCount",
      dataIndex:"shareCount",
      sortable:true,
      render:this.renderShare
    },{
      title:"注册时间",
      key:"createTime",
      dataIndex:"createTime",
      sortable:true
    },{
      title:"登录时间",
      key:"loginTime",
      dataIndex:"loginTime",
      sortable:true
    },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          return (
            <span>
              <Add userId={record.userId}/>
            </span>
          );
        },
      }]
  }
  componentDidMount() {
    this.queryCache = {
      nowPage:1,
      pageSize:10,
      search:"",
      orderBy:"",
      orderByType:"",
      startTime:'',
      endTime:''
    }
    this.fetchData();
  }
  fetchData = async () => {
    var data = await net.post({
      url:'/web/user/listStat',
      data:this.queryCache
    })
    this.setState({
      data
    })
  }

  renderName = (value)=>{
    if(!value){
      value = '-'
    }
    return <span>{value}</span>
  }
  renderShare = (value,index,record)=>{
    return <div style={{color:"#2077FF",cursor:'pointer'}} onClick={()=>this.toDetail(record.userId)}>{record.shareCount}</div>
  }
  renderAvatar = (value,index,record)=>{
    value = `${imgURL}?token=${this.props.token}&key=${record.avatarUrl}&height=50&width=50`
    return (
      <div onClick={()=>this.showImg(record.avatarUrl)}>
        <Img src={value} shape="circle" width={40} height={40}/>
      </div>
      )
  }
  toDetail = (id)=>{
    this.props.show(id)
  }
  showImg = (value)=>{
   this.setState({
    nowImg:`${imgURL}?token=${this.props.token}&key=${value}&height=300&width=300`,
    visible:true
   })
  }
  changePage = (currentPage) => {
    this.queryCache.nowPage = currentPage;

    this.fetchData();
  }

  filterFormChange = (value) => {
    this.setState({
      filterFormValue: value,
    });
  }
  search = (value)=>{
    this.queryCache.search = value.key;
    this.fetchData();
  }
  sort = (dataIndex,order)=>{
    if(!dataIndex){ // 临时处理，加了cell的列，取不到dataindex
      dataIndex = 'shareCount'
    }
    this.queryCache.orderBy = dataIndex;
    this.queryCache.orderByType = order.toUpperCase();
    this.fetchData()
  }
  filterTable = () => {
    // 合并参数，请求数据
    var time = this.state.filterFormValue.time;
    this.queryCache = {
      ...this.queryCache,
      startTime:new Date(time[0]).getTime(),
      endTime:new Date(time[1]).getTime(),
    };
    this.fetchData();
  };

  resetFilter = () => {
    this.setState({
      filterFormValue: {
        time:[]
      }
    });
    this.queryCache.startTime = '';
    this.queryCache.endTime = '';
    this.fetchData();
  };

  render() {
    const tableData = this.state.data
    const { filterFormValue } = this.state;
    return (
      <div>
        <IceContainer title="用户筛选">
            <FilterForm
              value={filterFormValue}
              onChange={this.filterFormChange}
              onSubmit={this.filterTable}
              onReset={this.resetFilter}
            />
        </IceContainer>
        <IceContainer>
          <Search style={{float:'right',marginBottom:'26px'}} onSearch={this.search} searchText=""/>
          <CustomTable
            dataSource={tableData.rows}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
            pageData = {{...tableData,rows:[]}}
            changePage={this.changePage}
            onSort={this.sort}
            sortable
          />
        </IceContainer>
        <Overlay
          visible={this.state.visible}
          hasMask
          disableScroll
          align="cc cc"
          onRequestClose={()=>{
            this.setState({
              visible:false
            })
          }}
        >
          <Img src={this.state.nowImg} width={300} height={300}/>
        </Overlay>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  }
};
