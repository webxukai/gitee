/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import { Button,Icon} from '@icedesign/base';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import IceLabel from '@icedesign/label';
import CustomTable from './../../../../components/CustomTable'
import FilterForm from './Filter';
import { enquireScreen } from 'enquire-js';
import net,{imgURL} from '../../../../net.js'
import { connect } from 'react-redux'

@connect((state)=>{
  return {
    token:state.user.token
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);
    // 请求参数缓存
    this.queryCache = {};
    this.state = {
      data:{
        rows:[],
        pageSize:1,
        total:1,
        nowPage:1
      }
    };
    this.columns = [
    {
      title:"分享人",
      key:"shareName",
      dataIndex:"shareName",
    },{
      title:'奖励类型',
      key:"accountType",
      dataIndex:"accountType"
    },
    {
      title:'奖励金额',
      key:"money",
      dataIndex:"money",
    },{
      title:"奖励时间",
      key:"createTime",
      dataIndex:"createTime",
    },{
      title:"描述",
      key:"describeInfo",
      dataIndex:"describeInfo",
    }]
  }

  componentDidMount() {
    this.queryCache = {
      nowPage:1,
      pageSize:10,
      userId:this.props.nowId
    }
    this.fetchData();
  }
  fetchData = async () => {
    var data = await net.post({
      url:'/web/user/shareInfoLogs',
      data:this.queryCache
    })
    this.setState({
      data
    })
  }
  render() {
    const tableData = this.state.data
    return (
      <div>
        <IceContainer>
          <Button type="primary" onClick={this.props.back}><Icon type="arrow-left" />返回</Button>
          <h4 style={styles.title}>奖励详情</h4>
          <CustomTable
            dataSource={tableData.rows}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
            pageData = {{...tableData,rows:[]}}
            changePage={this.changePage}
            onSort={this.sort}
            sortable
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  title:{
    height: '16px',
    lineHeight: '16px',
    fontSize: '16px',
    color: 'rgb(51, 51, 51)',
    fontWeight: 'bold',
    margin: '20px 0px 20px',
    padding: '0px',
  },
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  }
};
