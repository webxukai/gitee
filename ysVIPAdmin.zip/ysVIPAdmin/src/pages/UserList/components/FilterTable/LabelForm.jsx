import React, { Component } from 'react';
import { Form, Input, Field,Select } from '@icedesign/base';
const FormItem = Form.Item;

export default class MyForm extends Component {
  static displayName = 'MyForm';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.field = new Field(this);
  }
  componentWillReceiveProps(props){
    this.field.setValues(props.record);
  }
  check = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        console.log('Errors in form!!!');
        return;
      }
      this.props.getValue(values);
    });
  };
  render() {
    const init = this.field.init;
    const formItemLayout = {
      labelCol: {
        fixedSpan: 6,
      },
      wrapperCol: {
        span: 14,
      },
    };
    return (
         <Form direction="ver" field={this.field}>
            <FormItem label="标签：" {...formItemLayout}>
              <Select
                multiple={true}
                {...init('tabIdList')}
              >
              {
                this.props.tableList.map((item,index)=>{
                  return <option value={item.id} key={index}>{item.userTab}</option>
                })
              }
              </Select>
            </FormItem>
        </Form>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    marginRight: '5px',
  },
};
