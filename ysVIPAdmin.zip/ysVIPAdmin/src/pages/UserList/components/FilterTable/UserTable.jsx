/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import IceLabel from '@icedesign/label';
import { Animate } from '@icedesign/base';
import { connect } from 'react-redux'
import FilterTable from './FilterTable'
import RewardTable from './RewardTable'

@connect((state)=>{
  return {
    token:state.user.token
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};
  constructor(props) {
    super(props);
    // 请求参数缓存
    this.queryCache = {};
    this.state = {
      nowId:"",
      className:""
    };
  }
  componentDidMount() {
    console.log(this)
  }
  afterEnter =()=>{
  }
  back = ()=>{
    this.setState({
      nowId:"",
      className:""
    })
  }
  showId=(id)=>{
    this.setState({
      nowId:id,
      className:"buttonClick"
    })
  }
  render() {
    return (
      <div>
        <div style={{display:this.state.nowId ? 'none':'block'}} ><FilterTable show={this.showId}/></div>
        {
          this.state.nowId ? <div className={this.state.className}><RewardTable back={this.back} nowId={this.state.nowId}/></div> : ''
        }
      </div>
    );
  }
}

