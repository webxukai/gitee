import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
		this.state = {
			tableList:[], // 所有tablist
			record:{
				tabIdList:[]
			}
		}
	}
	open = ()=>{
		this.fetchData()
		this.getUserTab()
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	getValue = async (value)=>{
		await this.updateTab(value)
		this.refs.dialog.onClose();
	}
	getUserTab = async ()=>{
		var data = await net.get({
			url:"/web/user/selectTab",
			data:{
				userId:this.props.userId
			}
		})
		var tabIdList = data.map((item)=>{
			return item.id;
		})
		this.setState({
			record:{
				tabIdList
			}
		})
	}
	updateTab = async ({tabIdList})=>{
		var data =await net.post({
			url:"/web/user/addOrUpdateTab",
			data:{
				tabIdList,
				userId:this.props.userId
			}
		})
		if(data == 'true'){
			Feedback.toast.success('修改成功');
		}
		else{
			Feedback.toast.error('修改失败');
		}
	}
	fetchData = async () => {
	    var data = await net.post({
	      url:'/web/tab/findAllTab'
	    })
	    this.setState({
	    	tableList:data
	    })
  	}
	render(){
		return (
			<Dialog title='修改标签' handleSubmit ={this.handleSubmit} ref="dialog" size="small" open={this.open}>
				<LabelForm ref='form' getValue={this.getValue} tableList={this.state.tableList} record={this.state.record}/>
			</Dialog>
			)
	}
}