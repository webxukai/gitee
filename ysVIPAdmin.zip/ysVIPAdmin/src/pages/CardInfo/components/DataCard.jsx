import React, { Component } from 'react';
import { toThousands } from '@/utils'
import net from '@/net.js'
import StatisticalCard from '@/components/StatisticalCard'
const dataSource = [
  {
    text: '总消费金额',
    icon:"weibiaoti-",
    desc: '总消费金额',
    filed:"totalConsumeMoney"
  },
  {
    text: '总充值金额',
    icon:"jinrixiaofei",
    desc: '总充值金额',
    filed:"totalRechargeMoney"
  }
];

export default class DataCard extends Component {
  static displayName = 'DataCard';

  constructor(props) {
    super(props);
    this.queryCache={}
    this.state = {
      totalConsumeMoney:0,
      totalRechargeMoney:0,
    }
  }

  componentDidMount() {
    this.queryCache = {
      userMealMealKid: this.props.kid
    }
    this.fetchData()
  }
  fetchData = async () => {
    var data = await net.get({
      url: '/memberAdmin/bill/user-money-info',
      data: this.queryCache
    })
    this.setState({
        totalConsumeMoney: data.totalConsumeMoney,
        totalRechargeMoney: data.totalRechargeMoney
    })
  }
  render() {
    return (
      <StatisticalCard dataSource={this.state} items={dataSource}/>
    );
  }
}
