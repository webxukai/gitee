/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import {Search,DatePicker,Button,Grid} from '@icedesign/base';
import net from '@/net.js'
import Dialog from '@/components/Dialog'
import { mul } from '@/utils'
import { Feedback } from "@icedesign/base";
import { connect } from 'react-redux'
const { Row, Col } = Grid;
const consumerType = ['储蓄金额','现金金额','微信','支付宝']
@connect((state)=>{
  return {
    token:state.user.token,
    config:state.user.config
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.queryCache2 = {};
    this.columns = [
      {
        title:"卡号",
        key:'userSetMealKid',
        dataIndex:"userSetMealKid"
      },
      {
        title:"订单号",
        key:'kid',
        dataIndex:"kid"
      },
      {
        title:"消费类型",
        key:"consumerType",
        dataIndex:"consumerType",
        render:(value,index,record)=>{
          if(record.consumerType == null || record.consumerType == undefined){
            record.consumerType = ''
          }
          var type = record.consumerType + '';
          var typeList = type.split(','),
              str = '';
         typeList.forEach((type,index)=>{
          if(index == typeList.length - 1){
            str+=consumerType[type]
          }
          else{
            str+=consumerType[type]+' , '
          }
         })
         return <div>{str}</div>
        }
      },{
        title:"交易金额",
        key:"money",
        dataIndex:"money"
      },{
        title:"赠送交易金额",
        key:"money",
        dataIndex:"giveMoney"
      },{
        title:"交易时间",
        key:"createTime",
        dataIndex:"createTime"
      },{
        title:"详情信息",
        key:"information",
        render:(value,index,record) => {
          var str = ''
          var disCount1 =''
          var disCount2 =''
          if(record.discount) {
            if(record.discount.split(',')[0] == undefined){
              disCount1 = ''
            }else{
              disCount1 = mul(Number(record.discount.split(',')[0]),100)+'%'
            }
            if(record.discount.split(',')[1] == undefined){
              disCount2 = ''
            }else{
              disCount2 = mul(Number(record.discount.split(',')[1]),100)+'%'
            }
          }

          if(record.consumerType == null || record.consumerType == undefined){
            record.consumerType = ''
          }
          var type = record.consumerType + '';
          var typeList = type.split(','),
              str = '';
          typeList.forEach((type,index)=>{
            if(index == typeList.length - 1){
              str+=consumerType[type]
            }
            else{
              str+=consumerType[type]+' , '
            }
          })
          return (
              <div>
                <Dialog title='账单详情' style={styles.details}>
                  <div style={styles.con_details}>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡号：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userSetMealKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡所属者名：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userCardName}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>卡所属者：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.userCardKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作类型：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.type}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>之前的特价,最新的特价：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.specialOffer}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作用户名：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.operatorUserName}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>操作用户kid：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.operatorUserKid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易金额：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.money}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>订单号：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.kid}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>赠送金额：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.giveMoney}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>之前的折扣,最新的折扣：</div>
                      </Col>
                      <Col span="12">
                        <div>{disCount1},{disCount2}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易时间：</div>
                      </Col>
                      <Col span="12">
                        <div>{record.createTime}</div>
                      </Col>
                    </Row>
                    <Row style={styles.row}>
                      <Col span="8">
                        <div style={styles.col}>交易类型：</div>
                      </Col>
                      <Col span="12">
                        <div>{str}</div>
                      </Col>
                    </Row>
                  </div>
               </Dialog>
              </div>
            )
        }
      },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          return (
            <span>
              <Button type='primary' size='small' onClick={() => this.out_alone(record)}>导出</Button>
            </span>
          );
        }
      }];
    this.state = {
      data:{
        pageSize:10,
        total:1,
        nowPage:1,
        cardConsumerRecordList:[
          {
            "consumerType": 0,
            "content": "",
            "createTime": "",
            "discount": "",
            "giveMoney": 0,
            "kid": "",
            "merchantKid": "",
            "merchantName": "",
            "money": 0,
            "operatorUserKid": "",
            "operatorUserName": "",
            "specialOffer": "",
            "surplusMoney": 0,
            "type": 0,
            "userCardKid": "",
            "userCardName": "",
            "userSetMealKid": ""
          }
        ]
      },
      rowSelection: {
        onChange: this.onChange.bind(this),
        selectedRowKeys: []
      }
    }
  }
  componentDidMount() {
    this.queryCache = {
      limit:10,
      page:1,
      userSetMealKid:this.props.kid,
      startDate:this.firstDay(),
      stopDate:this.lastDay()
    },
    this.queryCache2 = {
      billKidList:[],
      userSetMealKid:this.props.kid
    }
    this.fetchData();
  }
  firstDay() {
    return (this.getDate(new Date()).substring(0,6)+'01')
  }

  //获取指定月份最后一天
  lastDay() {
   var Year = parseInt(this.getDate(new Date()).substring(0,4)) ;
   var Month = this.getDate(new Date()).substring(4,6);
   switch(Month) {
    case '01':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '02':
      if(Year % 4 == 0 && Year % 100 != 0) {
         return this.getDate(new Date()).substring(0,6)+'29'
         console.log('闰年')
       }else{
        return this.getDate(new Date()).substring(0,6)+'28'
       }
      break;
    case '03':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '04':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '05':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '06':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '07':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '08':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '09':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '10':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
    case '11':
      return this.getDate(new Date()).substring(0,6)+'30'
      break;
    case '12':
      return this.getDate(new Date()).substring(0,6)+'31'
      break;
   }
  }
  //日期转化
  getDate(date) {
    var year = date.getFullYear()
    var month = date.getMonth()+1
    var date = date.getDate()
    if(month < 10){
      month = '0' + month
    }
    if(date < 10){
      date = '0' + date
    }
    return (year.toString() + month.toString() + date.toString())
  }
  onChange(ids, records) {
    let { rowSelection } = this.state;
    rowSelection.selectedRowKeys = ids;
    this.setState({ rowSelection });
  }
  //卡账单记录
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/bill/card-records',
      data:this.queryCache
    })
    this.setState({
      ...this.queryCache,
      data
    })
  }
  search = (value)=>{
    this.queryCache.search = value.key;
    this.fetchData();
  }
  changePage = (currentPage) => {
    this.queryCache.nowPage = currentPage;

    this.fetchData();
  }
  filterFormChange = (value) => {
    var startDate = new Date(value[0])
    var endDate = new Date(value[1])
    var startDate = this.getDate(startDate)
    var stopDate = this.getDate(endDate)
    this.queryCache = {
      ...this.queryCache,
      startDate,
      stopDate,
    };
    this.fetchData();
  }
  //批量导出
  out = async ({pointReward})=>{
    var ids = this.state.rowSelection.selectedRowKeys
    if(ids.length == 0){
      Feedback.toast.error('请至少选择一条记录');
      return false;
    }else{
      this.queryCache2.billKidList = this.state.rowSelection.selectedRowKeys
      this.getOut()
    }
  }
  //单个导出
  out_alone =  (record)=>{
    this.queryCache2.billKidList=[record.kid]
    this.getOut()
  }
  //卡账单记录导出
  getOut = async ()=>{
    var  data = await net.downLoad({
      url:'/memberAdmin/bill/card-records.xls',
      data:this.queryCache2
    })
    var date = new Date()

    var blob = new Blob([data]);
    var url = window.URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download ='卡账单记录'+ this.getDate(date)+'.xls';
    link.click()
  }
  //日期转化
  getDate(date) {
    var year = date.getFullYear()
    var month = date.getMonth()+1
    var date = date.getDate()
    if(month < 10){
      month = '0' + month
    }
    if(date < 10){
      date = '0' + date
    }
    return (year.toString() + month.toString() + date.toString())
  }

  onPageSizeChange = (pageSize)=>{
    this.queryCache.pageSize = pageSize;
    this.fetchData()
  }
  render() {
    const tableData = this.state.data;
    return (
      <div>
        <IceContainer>
          <Button onClick={this.out} type="primary">批量导出</Button>
          <DatePicker.RangePicker name='time' onChange={this.filterFormChange} style={{margin:'5px',float:"right"}}/>
          <CustomTable
            dataSource={tableData.cardConsumerRecordList}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            rowSelection = {this.state.rowSelection}
            hasBorder={false}
            pageData = {{
                        current:this.state.page,
                        pageSize:this.state.limit,
                        total:tableData.total,
                        onChange:this.changePage,
                        pageSizeSelector:"dropdown",
                        pageSizeList:[10,100,1000],
                        onPageSizeChange:this.onPageSizeChange
                      }}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  details: {
    background:'rgba(0,0,0,0)',
    color: "#2077FF",cursor:'pointer',margin:'0',
  },
  row: {
    padding:'10px',
    borderBottom: '1px solid #eee'
  },
  col: {
    textAlign:'right',
    paddingRight:'10px'
  }
};
