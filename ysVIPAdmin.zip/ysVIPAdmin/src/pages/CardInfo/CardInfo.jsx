
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import PayTable from './components/PayTable'
import DataCard from './components/DataCard'
import './CardInfo.scss';

export default class CardInfo extends Component {
  static displayName = 'CardInfo';

  constructor(props) {
    super(props);
    // console.log(this.props.params.id)
    this.state = {
      kid: this.props.params.id
    }
  }

  render() {
    return (
      <div className="user-list-page">
        <DataCard kid = {this.state.kid} />
        <PayTable kid = {this.state.kid} />
      </div>
    );
  }
}
