import CardInfo from './CardInfo';

export default CardInfo;
