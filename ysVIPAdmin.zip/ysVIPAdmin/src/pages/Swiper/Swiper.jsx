
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import SwiperTable from './components/SwiperTable'


export default class Swiper extends Component {
  static displayName = 'Swiper';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const breadcrumb = [
      { text: '轮播列表', link: '' },
      { text: '轮播图列表', link: '#/swiper/list1' },
    ];
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <SwiperTable />
      </div>
    );
  }
}
