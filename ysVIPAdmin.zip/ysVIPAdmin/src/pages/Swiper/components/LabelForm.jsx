import React, { Component } from 'react';
import { Form, Input, Field,Select } from '@icedesign/base';
const FormItem = Form.Item;
export default class MyForm extends Component {
  static displayName = 'MyForm';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.field = new Field(this);
  }
  componentDidMount(){
    this.field.setValues(this.props.record);
  }
  check = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        console.log('Errors in form!!!');
        return;
      }
      this.props.getValue(values);
    });
  }
  render() {
    const init = this.field.init;
    const formItemLayout = {
      labelCol: {
        fixedSpan: 6,
      },
      wrapperCol: {
        span: 14,
      },
    };
    return (
         <Form direction="ver" field={this.field}>
            <FormItem label="商家唯一标识：" {...formItemLayout}>
              <Input
               {...init('merchantKid',{
                  rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                })}
              />
            </FormItem>
            <FormItem label="商家昵称：" {...formItemLayout}>
               <Input
                 {...init('merchantName',{
                    rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                  })}
                />
            </FormItem>
            <FormItem label="商家手机号：" {...formItemLayout}>
               <Input
                 {...init('phone',{
                    rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                  })}
                />
            </FormItem>
            <FormItem label="轮播图路径：" {...formItemLayout}>
               <Input
                 {...init('picture',{
                    rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                  })}
                />
            </FormItem>
            {/*<FormItem label="级别：" {...formItemLayout}>
              <Select
                {...init('level',{
                  rules: [{ required: true, message: '必填选项' }]
                })}>
                {
                  Array.apply(null,{length:16}).map((item,index)=>{
                    return <option value={index+''} key={index}>{index}等级</option>
                  })
                }
              </Select>
            </FormItem>*/}
        </Form>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    marginRight: '5px',
  },
};
