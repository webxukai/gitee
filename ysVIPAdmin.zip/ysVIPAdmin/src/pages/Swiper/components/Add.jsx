import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	getValue = async (value)=>{
		await this.updateTab(value)
		this.refs.dialog.onClose();
	}
	updateTab = async (value)=>{
		console.log(value.picture)
		var data = await net.post({
			url:'/memberAdmin/advertising/saveAdvertising',
			data:{
				merchantKid: value.merchantKid,
				merchantName: value.merchantName,
				phone: value.phone,
				picture: value.picture
			}
		})
		if( data.state == 1) {
			Feedback.toast.success('新增成功')
		}else{
			Feedback.toast.error('新增失败')
		}
	}
	render(){
		return (
			<Dialog title='新增' handleSubmit ={this.handleSubmit} ref="dialog">
				<LabelForm ref='form' getValue={this.getValue} record={{}}/>
			</Dialog>
			)
	}
}