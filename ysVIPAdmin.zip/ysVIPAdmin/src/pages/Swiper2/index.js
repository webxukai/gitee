import Swiper from './Swiper';

export default Swiper;
