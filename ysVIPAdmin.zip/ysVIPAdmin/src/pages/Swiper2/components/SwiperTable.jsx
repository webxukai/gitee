/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import CustomTable from '@/components/CustomTable'
import DeleteBalloon from '@/components/DeleteBalloon'
import Edit from './Edit'
import Add from './Add'
import net from '@/net.js'
import { connect } from 'react-redux'
import { Feedback } from "@icedesign/base";

@connect((state)=>{
  return {
    token:state.user.token,
    config:state.user.config
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.columns = [
    {
      title:"ID",
      key:"id",
      dataIndex:"id"
    },{
      title:"图片",
      key:"picture",
      render: (value, index, record) => {
        return (
          <div>
           <img style={styles.img} src={'http://47.100.99.28:8086/fileService/file/downloadFile?path='+record.picture}></img>
          </div>
        );
      }
    },{
      title:"审核状态",
      key:"type",
      render: (value, index, record) => {
        switch(record.type){
          case 0:
            return (
              <div>待审核</div>
            );
            case 1:
            return (
              <div>审核成功</div>
            );
            case 2:
            return (
              <div>审核失败</div>
            );
          }
        }
    },{
      title:"回复内容",
      key:"auditReply",
      dataIndex:"auditReply"
    },{
      title:"创建时间",
      key:"createTime",
      dataIndex:"createTime",
    },{
        title: '操作',
        key: 'operation',
        render: (value, index, record) => {
          return (
            <div>
              <DeleteBalloon handleRemove = {()=>this.handleRemove(record.id)}/>
            </div>
          );
        }
      }]
    this.state = {
      data:{
        count:0,
        pageSize:1,
        nowPage:1,
        list:[],
      },
      columns:this.columns
    };
  }
  handleRemove =async (id) => {
    var  data = await net.post({
      url:'/memberAdmin/advertising/removeAdvertisingAudit',
      data:{
        id
      }
    })
    if(data.state == 1){
      Feedback.toast.success('删除成功')
      this.fetchData()
    }else{
      Feedback.toast.error('删除失败')
    }
  }
  componentDidMount() {
    this.queryCache = {
      nowPage:1,
      pageSize:10,
      search:"",
      startTime:'',
      endTime:''
    }
    this.fetchData();
    //this.setColumns(this.props)
  }
  setColumns = ({config})=>{
    if(!config.item2){
        var columns = this.state.columns.filter((item)=>{
          if(item.key == 'deduction' || item.key == 'giveMoney'){
            return false;
          }
          return true;
        })
        this.setState({
          columns
        })
      }
      else{
        this.setState({
          columns:this.columns
        })
      }
  }
  componentWillReceiveProps(nextProps){
    if(nextProps.config != this.props.config){
      this.setColumns(nextProps)
    }
  }
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/advertising/queryAdvertisingAuditList',
      data:this.queryCache
    })
    this.setState({
      data
    })
  }
  changePage = (page) =>{
    this.queryCache.nowPage = page;
    this.fetchData()
  }
  render() {
    const { filterFormValue } = this.state;
    return (
      <div>
        <IceContainer title="轮播列表">
          <Add FetchData={this.fetchData}/>
          <CustomTable
            dataSource={this.state.data.list}
            className="basic-table"
            style={styles.basicTable}
            columns={this.state.columns}
            hasBorder={false}
            pageData = {{
                        current:this.state.data.nowPage,
                        pageSize:this.state.data.pageSize,
                        total:this.state.data.count,
                        onChange:this.changePage,
                        }}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  img: {
    width:'60px',
    height:'60px'
  }
};
