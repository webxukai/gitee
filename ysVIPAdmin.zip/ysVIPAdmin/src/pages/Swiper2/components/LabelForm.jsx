import React, { Component } from 'react';
import { Form, Input, Field,Select } from '@icedesign/base';
import Upload from '@/components/Upload'
import net from '@/net';
const FormItem = Form.Item;
export default class MyForm extends Component {
  static displayName = 'MyForm';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.state = {
    }
    this.field = new Field(this);
  }
  componentDidMount(){
    this.field.setValues(this.props.record);
  }



  check = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        console.log('Errors in form!!!');
        return;
      }
      this.props.getValue(values);
    });
  };
  getFile = async (file)=>{
    this.props.getFile(file)
  }
  render() {
    const init = this.field.init;
    const formItemLayout = {
      labelCol: {
        fixedSpan: 6,
      },
      wrapperCol: {
        span: 14,
      },
    };
    return (
         <Form direction="ver" field={this.field}>
            <FormItem label="图片路径：" {...formItemLayout}>
              <Upload getFile={this.getFile}
                {...init('imgUrl',{
                  rules: [{ required: true, message: '必填选项' }],
                })}
                ></Upload>
             {/* <Input
               {...init('url',{
                  rules: [{ required: true, message: '必填选项' }],
                })}
              />*/}
            </FormItem>
           {/*<FormItem label="充值金额：" {...formItemLayout}>
               <Input
                 {...init('fundMoney',{
                    rules: [{ required: true, message: '必填选项' },{pattern:/^[a-zA-Z\u4e00-\u9fa5]|[\（\）\《\》\——\；\，\,\？\。\.\"\"\“\”\'\‘\’\<\>\！]{1,40}$/,message:'格式错误'}],
                  })}
                />
            </FormItem>*/}
        </Form>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    marginRight: '5px',
  },
  img_con: {

  },
  img: {
    width:'200px',
  }
};
