// import React, { Component } from 'react';
// import LabelForm from './LabelForm'
// import Dialog from '@/components/Dialog'
// import { Feedback } from "@icedesign/base";
// import net from '@/net'
// export default class AddLabel extends Component {
// 	constructor(props){
// 		super(props)
// 	}
// 	handleSubmit = ()=>{
// 		this.refs.form.check();
// 	}
// 	getValue = async (value)=>{
// 		await this.updateTab(value)
// 		this.refs.dialog.onClose();
// 	}
// 	updateTab = async (value)=>{
// 		console.log(value)
// 	}
// 	render(){
// 		return (
// 			<Dialog title='新增' handleSubmit ={this.handleSubmit} ref="dialog">
// 				<LabelForm ref='form' getValue={this.getValue} />
// 			</Dialog>
// 			)
// 	}
// }
import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
var fileObj = null;
export default class AddLabel extends Component {
	constructor(props){
		super(props)
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	state = {
		data:null
	}
	getValue = async (value)=>{
		await this.uploadFile();
		this.refs.dialog.onClose();
		fileObj = null;
	}
	getFile = (file)=>{
		fileObj = file;
	}
	uploadFile = async ()=>{
		// console.log(fileObj)
		var formData = new FormData()
		formData.append('file',fileObj)
		var data = await net.post({
			url: 'http://47.100.99.28:8086/fileService/file/uploadFile',
			data: formData
		})

		this.updateTab(data[0].download)
	}
	close = ()=>{
		fileObj = null;
	}
	updateTab = async (value)=>{
		var data = await net.post({
			url:'/memberAdmin/advertising/saveAdvertising',
			data:{
				picture: value
			}
		})
		if( data.state == 1) {
			Feedback.toast.success('新增成功')
			this.props.FetchData()
		}else{
			Feedback.toast.error('新增失败')
		}
	}
	render(){
		return (
			<Dialog title='新增' handleSubmit ={this.handleSubmit} ref="dialog" close={this.close}>
				<LabelForm ref='form' getValue={this.getValue} record={{}} getFile={this.getFile}/>
			</Dialog>
			)
	}
}