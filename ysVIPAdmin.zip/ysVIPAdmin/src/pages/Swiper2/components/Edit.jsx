import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	getValue = async (value)=>{
		console.log(value)
		await this.updateTab(value)
		this.refs.dialog.onClose();
	}
	updateTab = async (value)=>{
		console.log(value)
	}
	render(){
		var {record,...others} = this.props
		return (
			<Dialog title='修改' handleSubmit ={this.handleSubmit} ref="dialog" size="small" {...others}>
				<LabelForm ref='form' getValue={this.getValue} record={record}/>
			</Dialog>
			)
	}
}