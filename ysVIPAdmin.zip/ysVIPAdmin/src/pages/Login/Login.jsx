

import React, { Component } from 'react';

import UserLogin from './components/UserLogin';
import UserRegister from './components/UserRegister';

import './Login.scss';
// 寻找背景图片可以从 https://unsplash.com/ 寻找
const backgroundImage =
  'https://img.alicdn.com/tfs/TB1zsNhXTtYBeNjy1XdXXXXyVXa-2252-1500.png';

export default class Login extends Component {
  static displayName = 'Login';

  constructor(props) {
    super(props);
    this.state = {
      login:true
    };
  }
  changeCon=(flag)=>{
    this.setState({
      login:flag
    })
  }
  render() {
    const { router } = this.props;
    var content;
    if(this.state.login){
      content = <UserLogin {...router} change={this.changeCon}/>
    }
    else{
      content = <UserRegister {...router} change={this.changeCon}/>
    }
    return (
      <div className="login-page">
        <div style={styles.userLogin} className="user-login">
          <div
            style={{
              ...styles.userLoginBg,
              backgroundImage: `url(${backgroundImage})`,
            }}
          />
          <div style={styles.contentWrapper} className="content-wrapper">
            <h2 style={styles.slogan} className="slogan">
              欢迎使用 <br /> 吉卡云后台管理系统
            </h2>
          {content}
          </div>
        </div>
      </div>
    );
  }
}
const styles = {
  userLogin: {
    position: 'relative',
    height: '100vh',
  },
  userLoginBg: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundSize: 'cover',
  },
  contentWrapper:{
    position: 'absolute',
    top: '-100px',
    left: 0,
    right: 0,
    bottom: 0,
    maxWidth: '1080px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  slogan:{
    textAlign: 'center',
    color: '#fff',
    fontSize: '36px',
    letterSpacing: '2px',
    lineHeight: '48px',
  }
};
