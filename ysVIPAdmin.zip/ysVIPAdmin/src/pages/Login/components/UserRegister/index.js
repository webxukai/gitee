import UserRegister from './UserRegister';

export default UserRegister;
