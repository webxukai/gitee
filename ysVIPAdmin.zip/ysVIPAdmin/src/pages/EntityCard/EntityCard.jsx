import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import EntityCardRecord from './components/entityCardRecord'
export default class EntityCard extends Component {
  static displayName = 'EntityCard';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const breadcrumb = [
      { text: '卡管理', link: '' },
      { text: '卡列表', link: '#/card/list' },
      { text: '实体卡列表', link: '' },
    ];
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <EntityCardRecord />
      </div>
    );
  }
}
