/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import net from '@/net.js'
import { connect } from 'react-redux'
import { withRouter } from 'react-router' ;

@withRouter
@connect((state)=>{
  return {
    token:state.user.token
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.state = {
        data:[]
    }
    // 请求参数缓存
    this.columns = [
    {
      title:"卡ID",
      key:"cardKid",
      dataIndex:"cardKid"
    },{
      title:'创建时间',
      key:"createTime",
      dataIndex:"createTime",
    }]
  }
  componentDidMount() {
    this.fetchData();
  }
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/set-meal/user-entity-cards',
      data:{
          userKid:this.props.params.id
      }
    })
    this.setState({
      data
    })
  }

  render() {
    const tableData = this.state.data
    return (
      <div>
        <IceContainer>
          <CustomTable
            dataSource={tableData}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  }
};
