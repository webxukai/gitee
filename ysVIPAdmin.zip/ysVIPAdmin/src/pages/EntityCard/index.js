import EntityCard from './EntityCard';

export default EntityCard;
