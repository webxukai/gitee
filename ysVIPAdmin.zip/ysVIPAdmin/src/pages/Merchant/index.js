import Merchant from './Merchant';

export default Merchant;