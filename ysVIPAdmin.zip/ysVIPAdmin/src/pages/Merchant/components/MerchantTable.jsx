
/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import {Search,DatePicker,Button} from '@icedesign/base';
import net from '@/net.js'
import { hashHistory } from 'react-router';
import { connect } from 'react-redux'
import Dialog from '@/components/Dialog'
import { Grid } from "@icedesign/base";
const { Row, Col } = Grid;

@connect((state)=>{
  return {
    token:state.user.token,
    config:state.user.config
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.columns = [
      {
        title:"商户ID",
        key:'kid',
        dataIndex:"kid",
      },{
        title:"商户姓名",
        key:'merchantName',
        dataIndex:"merchantName",
      },{
        title:"用户手机号",
        key:"phone",
        dataIndex:"phone",
        render: (value, index, record) => {
          console.log(record)
          var str = record.phone
          // var str2 = ''
          return (
              <div>{str}</div>
            )
        }
     }
      ];
    this.state = {
      data:[
        {
          kid:"",
          merchantName:"",
          phone:""
        }
      ]
    }
  }
  componentDidMount() {
    // console.log(sessionStorage.getItem('token'))
    this.queryCache = {
      merchantKid:sessionStorage.getItem('token')

    }
    this.fetchData();
  }

  //商户列表接口
  fetchData = async () => {
    var data = await net.post({
      url:'/admin/merchant/getSubMerchants',
      data:this.queryCache
    })
    this.setState({
      data
    })
  }
  // search = (value)=>{
  //   this.queryCache.phone = value.key;
  //   this.fetchData();
  // }
  // changePage = (currentPage) => {
  //   this.queryCache.nowPage = currentPage;
  //   this.fetchData();
  // }
  // filterFormChange = (value) => {
  //   this.queryCache = {
  //     ...this.queryCache,
  //     startTime:new Date(value[0]).getTime(),
  //     endTime:new Date(value[1]).getTime(),
  //   };
  //   this.fetchData();
  // }
// findKid = () => {
//   this.queryCache.merchantKid = sessionStorage.getItem('token')
//   this.fetchData();
// }



  render() {
    const tableData = this.state.data;
    console.log (tableData)
    return (
      <div>
        <IceContainer title="商户列表">
          <div style={{float:'right',marginBottom:'26px',display:'flex',flexWrap:"wrap"}}>
            <Search onSearch={this.search} searchText="" placeholder="请输入手机号" style={{margin:'5px'}}/>
          </div>
          <CustomTable
            dataSource={tableData}
            className="basic-table"
            style={styles.basicTable}
            columns={this.columns}
            hasBorder={false}
            pageData = {{
                        current:tableData.nowPage,
                        pageSize:tableData.pageSize,
                        total:tableData.count,
                        onChange:this.changePage,
                        }}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  },
  details: {
    background:'rgba(0,0,0,0)',
    color: "#2077FF",cursor:'pointer',margin:'0',
  },
  con_details: {
    fontSize:'16px',
    padding: '15px'
  },
  row: {
    padding:'10px',
    borderBottom: '1px solid #eee'
  },
  col: {
    textAlign:'right',
    paddingRight:'10px'
  }
};
