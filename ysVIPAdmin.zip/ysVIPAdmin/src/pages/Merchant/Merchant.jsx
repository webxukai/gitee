
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import MerchantTable from './components/MerchantTable'

import './Merchant.scss';

export default class Merchant extends Component {
  static displayName = 'Merchant';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    var breadcrumb;
    if(this.props.children){
      breadcrumb = [
        { text: '商户管理', link: '' },
        { text: '商户列表', link: '#/merchant/list' },
        { text: '商户账单详情', link: '' },
      ];
    }
    else{
      breadcrumb = [
        { text: '商户管理', link: '' },
        { text: '商户列表', link: '#/merchant/list' },
      ];
    }
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <div style={{display:this.props.children ? 'none':'block'}}>
          <MerchantTable />
        </div>
        <div className={this.props.children ? 'buttonClick' : ''}>
          { this.props.children }
        </div>
      </div>
    );
  }
}
