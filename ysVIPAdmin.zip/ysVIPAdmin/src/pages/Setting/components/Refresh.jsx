/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import { Button } from "@icedesign/base";
import CustomTable from '@/components/CustomTable'
import { Grid } from "@icedesign/base";
import { Checkbox } from '@icedesign/base';
import { Feedback } from "@icedesign/base";
const { Group: CheckboxGroup } = Checkbox;
import Edit from './Edit'
import net from '@/net.js'
import { connect } from 'react-redux'
import Dialog from '@/components/Dialog'
const { Row, Col } = Grid;
@connect((state)=>{
  return {
    token:state.user.token,
    settingList:state.user.settingList
  }
})

export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};

     this.state = {
      cantOpen:()=>{
        Feedback.toast.error('最少选择一条')
      },
      value: [],
      list:[
        {
          value: "1",
          label: "积分功能"
        },
        {
          value: "2",
          label: "积分卡折扣/特价"
        },
        {
          value: "3",
          label: "允许现金交易功能"
        },
        {
          value: "4",
          label: "允许混合支付功能"
        }
      ],
      refreshState:{merchantLevelSettingAO:{}}
    };
    this.onChange = this.onChange.bind(this);
  }
  componentDidMount() {
    // this.setColumns(this.props)
  }
  onChange(selectedItems) {
    var cantOpen = ()=>{
      Feedback.toast.error('最少选择一条')
    }
    if( selectedItems.length){
      cantOpen = false;
    }
    this.setState({
      value: selectedItems,
      cantOpen
    });
  }
  getRefreshState = async()=>{
    var data = await net.get({
      url:"/memberAdmin/setting/queryAllRefreshState"
    })
    this.setState({
      refreshState:data
    })
  }
  //全局刷新接口
  globalRefresh = async ()=>{
    var data = await net.post({
      url:'/memberAdmin/setting/allRefresh',
      data:{
        list: this.state.value
      }
    })
    if(data.state == 1){
      Feedback.toast.success('全局刷新成功')
      this.refs.dialog.onClose();
    }else{
      Feedback.toast.error('最少选择一条')
    }
  }

  render() {
    const dis = [{
      key:"积分功能",
      dsc:`把您商户下有积分功能的用户 ，其中的积分功能进行 【${this.state.refreshState.enableIntegral == 1 ? "打开":"关闭"}】。用户消费时将 【${this.state.refreshState.enableIntegral == 1 ? "会":"不会"}】产生积分`
    },{
      key:"积分卡折扣/特价",
      dsc:`把您商户下所有的纯积分卡用户 ，卡中折扣调整为 ${Number(this.state.refreshState.merchantLevelSettingAO.discount) * 100 +'%' } ，特价调整为 ${this.state.refreshState.merchantLevelSettingAO.specialType}`
    },{
      key:"允许现金交易功能",
      dsc:`您商户下所有的用户 现金交易状态 调整为 【${this.state.refreshState.enableCash == 1 ? "允许":"不允许"}】，用户消费时 【${this.state.refreshState.enableCash == 1 ? "可以":"不可以"}】使用现金。`
    },{
      key:"允许混合支付功能",
      dsc:`您商户下所有的用户 混合支付状态 调整为 【${this.state.refreshState.enableBlend == 1 ? "允许":"不允许"}】，用户消费时 【${this.state.refreshState.enableBlend == 1 ? "可以":"不可以"}】混合支付。`
    }]
    var list = this.state.value,
    list = list.sort(),
    text = list.map((item,index)=>{
      var num = Number(item) - 1;
      return (
        <div key={index}>
          <p>{index + 1} . {dis[num].key} :</p>
          <p style={{textIndent:'2em',paddingLeft:'16px'}}>{dis[num].dsc}</p>
        </div>
      )
    })
    return (
      <div>
        <IceContainer>
           <Row>
             <Col span="20">
                <div style={{ padding: "20px" }}>
                  <CheckboxGroup
                    value={this.state.value}
                    style={styles.list}
                    dataSource={this.state.list}
                    onChange={this.onChange}
                  />
                </div>
             </Col>

            <Col span="" style={{float:'right'}}>
              <div>
                <Dialog ref="dialog" title="全局刷新" handleSubmit ={this.globalRefresh} cantOpen={this.state.cantOpen} open={this.getRefreshState} trigger={<Button type="primary">全局刷新</Button>}>
                  { text }
                </Dialog>
              </div>
            </Col>
          </Row>
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  list:{
    color: '#5485F7',
  }
};
