/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import IceContainer from '@icedesign/container';
import DataBinder from '@icedesign/data-binder';
import CustomTable from '@/components/CustomTable'
import Edit from './Edit'
import net from '@/net.js'
import { connect } from 'react-redux'

@connect((state)=>{
  return {
    token:state.user.token,
    settingList:state.user.settingList
  }
})
export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);

    // 请求参数缓存
    this.queryCache = {};
    this.columns = [
      {
        title:"ID",
        key:"id",
        dataIndex:"id"
      },{
        title:"折扣",
        key:"disCount",
        dataIndex:"disCount"
      },{
        title:"等级",
        key:"grade",
        dataIndex:"grade"
      },{
        title:"特价类型",
        key:"specialType",
        dataIndex:"specialType"
      }
    //   {
    //       title: '操作',
    //       key: 'operation',
    //       render: (value, index, record) => {
    //         return (
    //           <div>
    //             <Edit record = {record} disabled={record.id == 1} config={this.props.config}/>
    //           </div>
    //         );
    //       },
    // }
    ]
    this.state = {
      // rows:[{
      //   id:1,
      //   level:"0等级",
      //   special:0,
      //   discount:"99",
      //   recharge:0
      // },{
      //   id:2,
      //   level:"1等级",
      //   special:1,
      //   discount:"99",
      //   recharge:0
      // }],
      data:[
        {
          levelList:[]
        }
      ],
      columns:this.columns
    };
  }
  componentDidMount() {
     this.queryCache = {
      merchatnKid:''
    }
    this.fetchData();
    // this.setColumns(this.props)
  }
  setColumns = ({config})=>{
    if(!config.item3){
      var columns = this.state.columns.filter((item)=>{
        if(item.key == 'special' || item.key == 'discount'){
          return false;
        }
        return true;
      })
      this.setState({
        columns
      })
    }
    else{
      this.setState({
        columns:this.columns
      })
    }
  }
  componentWillReceiveProps(nextProps){
    // if(nextProps.config != this.props.config){
    //   this.setColumns(nextProps)
    // }
  }
  fetchData = async () => {
    var data = await net.post({
      url:'/memberAdmin/setting/getSetting',
      data:this.queryCache
    })
    this.setState({
      data
    })
  }
  render() {
    const { filterFormValue } = this.state;
    return (
      <div>
        <IceContainer title="等级优惠设置">
          <CustomTable
            dataSource={this.state.data.levelList}
            className="basic-table"
            style={styles.basicTable}
            columns={this.state.columns}
            hasBorder={false}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both'
  }
};
