/* eslint no-underscore-dangle: 0 */
import React, { Component } from 'react';
import Img from '@icedesign/img';
import { Switch,Button,Grid,Nav,Notice,Balloon } from "@icedesign/base";
import IceContainer from '@icedesign/container';
import CustomTable from '@/components/CustomTable'
import Edit from './Edit'
import net from '@/net.js'
import { connect } from 'react-redux'
import { setConfig } from '@/redux/actions'
import { Feedback } from "@icedesign/base";
import { mul,div } from '@/utils'
const { Row, Col } = Grid;
const  types = ['积分','充送','折扣/特价','特价允许降级','折扣允许降级','允许现金交易','允许混合支付']

@connect((state)=>{
  return {
    token:state.user.token,
    settingList:state.user.settingList,
    levelList:state.user.levelList
  }
},(dispatch)=>{
  return {
    setConfig:(value)=>dispatch(setConfig(value))
  }
})

export default class EnhanceTable extends Component {
  static displayName = 'EnhanceTable';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.columns = [
    {
        title:"等级",
        key:"grade",
        dataIndex:"grade"
      },{
        title:"折扣",
        key:"discount",
        dataIndex:"discount",
        render:(value,index,record) => {
          var str =''
          if(record.discount == undefined){
            str = ''
          }else{
            str = mul(Number(record.discount),100)+'%'
          }
          return (
            <div>
              {str || '无'}
            </div>
          )
        }
      },{
        title:"特价类型",
        key:"specialType",
        dataIndex:"specialType",
        render:(value,index,record)=>{
          return <div>{record.specialType || '无'}</div>
        }
      },{
        title:"累计充值",
        key:"totalRecharge",
        dataIndex:"totalRecharge",
        render:(value,index,record) => {
          var num = 0
          if(record.grade == 0) {
            num=0
          }else{
            num = record.totalRecharge
          }
          return (
            <div>{num}</div>
            )
        }
      },{
          title: '操作',
          key: 'operation',
          render: (value, index, record) => {
            return (
              <div>
                <Edit record = {record} disabled={record.id == 1} getValue={this.getEditValue} showNotice={this.showNotice}/>
              </div>
            );
          },
    }
    ]
    this.state = {
      settingList:this.props.settingList.map((item)=>{
        return Object.assign({},item)
      }),
      levelList:this.props.levelList.map((item)=>{
        return Object.assign({},item)
      }),
      columns:this.columns,
      visible:false
    }
  }
  //给array数组复制
  async componentDidMount() {
    this.queryCache = {
      merchatnKid:''
    }
    this.fetchData();
    // this.onChange(this.props.config)
  }
  filter = ()=>{
    // 折扣/特价 关闭
    if(this.state.settingList[2].enable == 0){
      var columns = this.columns.filter((item)=>{
        if(item.key == 'discount' || item.key == 'specialType'){
          return false;
        }
        return true;
      })
      this.setState({
        columns
      })
    }
    else{
      this.setState({
        columns:this.columns
      })
    }
  }
  fetchData = async ()=>{
    await this.props.setConfig();
    this.setState({
      settingList: this.props.settingList.map((item)=>{
        return Object.assign({},item)
      }),
      levelList:this.props.levelList.map((item)=>{
        return Object.assign({},item)
      })
    })
    this.filter()
  }
  getEditValue = (value)=>{
    this.state.levelList.map((item,index)=>{
      if(item.id == value.id){
        this.state.levelList[index]= value
        this.state.levelList[index].discount = div(Number(value.discount),100)
        this.setState({
          levelList:this.state.levelList
        })
      }
    })
  }
  onChange= async (index)=> {
      var settingList = this.state.settingList.slice();
      settingList[index].enable = settingList[index].enable ? 0:1
      this.setState({
        settingList:settingList
      })
      this.showNotice();
      this.filter()
    // var data = await net.post({
    //   url:'/memberAdmin/setting/saveSetting',
    //   data:{
    //     settingList:[
    //       {
    //         code,
    //         enable,
    //         id
    //       }
    //     ]
    //   }
    // })
    // this.fetchData()
  }
  onClick= async ()=>{
    var data = await net.post({
      url:'/memberAdmin/setting/saveSetting',
      data:{
        settingList:this.state.settingList,
        levelList:this.state.levelList
      }
    })
    if(data.state == 1){
      Feedback.toast.success('保存设置成功')
      this.setState({
        visible:false
      })
      this.fetchData()
    }else{
      Feedback.toast.error('保存设置失败')
    }
    this.fetchData()
  }
  showNotice = ()=>{
    this.setState({
      visible:true
    })
  }
  //全局设置
  render() {
    var list = this.state.settingList.map((item,index)=>{
      console.log(item)
      console.log(index)
      let id = this.state.settingList[index].id
      let disable = !!(+this.state.settingList[index].state)

      const defaultTrigger = (
        <Switch className="btrigger" style={styles.item} disabled={disable} checked={!!this.state.settingList[index].enable} onChange={()=>this.onChange(index)}/>
      );
      if (disable) {
        if ( id == 1) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  积分
              </Balloon>
            </Col>
        )
        }
        if ( id == 2) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  未开通云支付无法开启充送
              </Balloon>
            </Col>
        )
        }
        if ( id == 3) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  折扣/特价
              </Balloon>
            </Col>
        )
        }
        if ( id == 4) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  特价允许降级
              </Balloon>
            </Col>
        )
        }
        if ( id == 5) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  允许现金交易
              </Balloon>
            </Col>
        )
        }
        if ( id == 6) {
          return (
            <Col xxs="24" xs="12" s={6} l={3} key={index}>
              <span style={styles.item}>{types[index]}</span>
              <Balloon trigger={defaultTrigger} closable={false} >
                  允许混合支付
              </Balloon>
            </Col>
        )
        }
      } else{
        return (
          <Col xxs="24" xs="12" s={6} l={3} key={index}>
            <span style={styles.item}>{types[index]}</span>
            <Switch style={styles.item} disabled={disable} checked={!!this.state.settingList[index].enable} onChange={()=>this.onChange(index)}/>
          </Col>
      )
      }
    })
    var save = <Row style={styles.btn_con}>
                  <Col span="20">
                    <div></div>
                  </Col>
                  <Col span="4">
                    <div><Button type="secondary" onClick={()=>this.onClick()}>保存设置</Button></div>
                  </Col>
                </Row>
    return (
      <div>
        <IceContainer title="全局设置">
          <Notice title="提示" style={{marginBottom:'20px'}} visible={ this.state.visible }>点击右侧 【保存设置】 按钮后才会生效！</Notice>
          {save}
          <Row style={{flexWrap:'wrap'}}>
          { list }

          {/*<Col xxs="24" xs="12" s={6} l={4}>
            <span style={styles.item}>积分</span>
            <Switch style={styles.item} checked={!!this.state.data.settingList[0].code} onChange={(checked)=>this.onChange(checked,'item1')}/>
          </Col>
          <Col xxs="24" xs="12" s={6} l={4}>
            <span style={styles.item}>充送</span>
            <Switch style={styles.item} checked={this.props.config.item2} onChange={(checked)=>this.onChange(checked,'item2')}/>
          </Col>
          <Col xxs="24" xs="12" s={6} l={4}>
            <span style={styles.item}>折扣/特价</span>
            <Switch style={styles.item} checked={this.props.config.item3} onChange={(checked)=>this.onChange(checked,'item3')}/>
          </Col>
          <Col xxs="24" xs="12" s={6} l={4}>
            <span style={styles.item}>特价允许降级</span>
            <Switch style={styles.item} checked={this.props.config.item4} onChange={(checked)=>this.onChange(checked,'item4')}/>
          </Col>
          <Col xxs="24" xs="12" s={6} l={4}>
            <span style={styles.item}>折扣允许降级</span>
            <Switch style={styles.item} checked={this.props.config.item5} onChange={(checked)=>this.onChange(checked,'item5')}/>
          </Col>*/}
          </Row>
          <CustomTable
            dataSource={this.state.levelList}
            className="basic-table"
            style={styles.basicTable}
            columns={this.state.columns}
            hasBorder={false}
          />
        </IceContainer>
      </div>
    );
  }
}

const styles = {
  filterTableOperation: {
    lineHeight: '28px',
  },
  operationItem: {
    marginRight: '12px',
    textDecoration: 'none',
    color: '#5485F7',
  },
  titleWrapper: {
    display: 'flex',
    flexDirection: 'row',
  },
  title: {
    marginLeft: '10px',
    lineHeight: '20px',
  },
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  },
  basicTable:{
    clear:'both',
    marginTop:'50px'
  },
  item:{
    display:'inline-block',
    verticalAlign:'middle',
    margin:'5px'
  },
  btn_con:{
    margin:'30px 0'
  },
  btn:{
    position:'relative',
    top:'-30px'
  }
};
