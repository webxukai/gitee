import React, { Component } from 'react';
import LabelForm from './LabelForm'
import Dialog from '@/components/Dialog'
import { Feedback } from "@icedesign/base";
import net from '@/net'
export default class AddLabel extends Component {
	constructor(props){
		super(props)
		this.state = {
			levelList:this.props.levelList
		}
	}
	componentDidMount(){

	}
	handleSubmit = ()=>{
		this.refs.form.check();
	}
	getValue = async (value)=>{
		this.props.getValue(value)
		this.refs.dialog.onClose();
		this.props.showNotice();
	}
	updateTab = async (value)=>{
		console.log(value)
	}
	render(){
		var {record,...others} = this.props
		return (
			<Dialog title='修改' handleSubmit ={this.handleSubmit} ref="dialog" size="small" {...others}>
				<LabelForm ref='form' getValue={this.getValue} record={record} />
			</Dialog>
			)
	}
}