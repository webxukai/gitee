import React, { Component } from 'react';
import { Form, Input, Field,Select,Range } from '@icedesign/base';
import { mul,div } from '@/utils'
const FormItem = Form.Item;

export default class MyForm extends Component {
  static displayName = 'MyForm';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.field = new Field(this);
    var discount = this.props.record.discount ? mul(Number(this.props.record.discount),100) : ""
    this.state= {
      grade: this.props.record.grade,
      record:{
        ...this.props.record,
        totalRecharge:this.props.record.grade == 0 ? 0 :this.props.record.totalRecharge,
        discount:discount
      }
    }

  }
  componentDidMount(){

    this.field.setValues(this.state.record);
  }
  check = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        console.log('Errors in form!!!');
        return;
      }
      this.props.getValue(values);
    });
  };
  render() {
    const init = this.field.init;
    const formItemLayout = {
      labelCol: {
        fixedSpan: 6,
      },
      wrapperCol: {
        span: 14,
      },
    };
    // var con = !this.props.config.item3 ? '':
    //           <div>
    //             <FormItem label="特价：" {...formItemLayout}>
    //               <Select
    //                 {...init('special',{
    //                    rules: [{ required: true, message: '必填选项' }]
    //                 })}
    //               >
    //               <option value="0">无</option>
    //               <option value="1">A类</option>
    //               <option value="2">B类</option>
    //               <option value="3">C类</option>
    //               <option value="4">D类</option>
    //               </Select>
    //             </FormItem>
    //             <FormItem label="折扣：" {...formItemLayout}>
    //               <Input
    //                 addonAfter="%"
    //                {...init('discount',{
    //                   rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
    //                 })}
    //               />
    //             </FormItem>
    //           </div>
      return (
         <Form direction="ver" field={this.field}>
            <FormItem label=" 折扣：" {...formItemLayout}>
            <Range 
                           {...init('discount',{
                            rules: [{ required: true, message: '必填选项' }]
                         })}
					  scales={10}
            marks={10}
            style={style}
					  />
             {/* <Input
               {...init('discount',{
                  rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'},{
                    validator: (rule, value, callback) => {
                      if(!value){
                        callback('');
                      }
                      var value = Number(value);
                      if(isNaN(value)){
                        callback('');
                      }
                      if(value > 100 || value <= 0){
                        callback('必须输入1-100之间的数字')
                      }
                      callback()
                    }
                  }],
                })}
              /> */}
            </FormItem>
            <FormItem label="特价：" {...formItemLayout}>
              <Select
               {...init('specialType',{
                  rules: [{ required: true, message: '必填选项' }]
               })}
              >
              <option value="无">无</option>
              <option value="A">A类</option>
              <option value="B">B类</option>
              <option value="C">C类</option>
              <option value="D">D类</option>
              </Select>
            </FormItem>
            <FormItem  label="累计充值：" {...formItemLayout}>
             <Input disabled={this.state.grade == 0}
               {...init('totalRecharge',{
                  rules: [{ required: true, message: '必填选项' },{pattern:/^\d+(\.\d+)?$/,message:'必须为有效数字'}],
                })}
              />
            </FormItem>
        </Form>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    marginRight: '5px',
  },
};
const style = {
  marginTop: "20px"
  };
