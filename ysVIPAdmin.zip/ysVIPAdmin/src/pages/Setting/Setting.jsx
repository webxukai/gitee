
import React, { Component } from 'react';
import CustomBreadcrumb from '../../components/CustomBreadcrumb';
import LevelTable from './components/LevelTable'
import SetUp from './components/SetUp'
import Refresh from './components/Refresh'

import './Setting.scss';

export default class Setting extends Component {
  static displayName = 'Setting';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const breadcrumb = [
      { text: '设置', link: '#/setting' },
    ];
    return (
      <div className="user-list-page">
        <CustomBreadcrumb dataSource={breadcrumb} />
        <Refresh />
        <SetUp />
        {/*<LevelTable />*/}
      </div>
    );
  }
}
