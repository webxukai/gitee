import Setting from './Setting';

export default Setting;
