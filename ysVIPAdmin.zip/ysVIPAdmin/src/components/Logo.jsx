import React, { PureComponent } from 'react';
import { Link } from 'react-router';

export default class Logo extends PureComponent {
  render() {
    return (
      <div className="logo" style={{}}>
        <Link to="/" className="logo-text">
           <img className="logo-img" style={styles.logoImg} src="../../public/images/logo.png" alt=""/>
        </Link>
      </div>
    );
  }
}
const styles = {
  logoImg: {
    marginLeft:'30px',
    width:'50px',
    height:'50px',
    
  }
}
