/**

*作者：CHAO TIAN

*时间：2018-06-08

*描述：table组件，可以传入分页数据

**/

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Table,Pagination } from '@icedesign/base';
import { enquireScreen } from 'enquire-js';
export default class CustomTable extends Component {
  static displayName = 'CustomTable';

  static propTypes = {
    dataSource: PropTypes.array,
    columns: PropTypes.array.isRequired,
  };

  static defaultProps = {
    dataSource: [],
  };

  constructor(props) {
    super(props);
    this.state = {};
    this._isMounted = true;
    this.enquireScreenRegister();
  }
  // 响应式处理
  enquireScreenRegister = () => {
    const mediaCondition = 'only screen and (max-width: 720px)';

    enquireScreen((mobile) => {
      if(!this._isMounted){
        return;
      }
      this.setState({
        isMobile: mobile,
      });
    }, mediaCondition);
  }
  // 为了解决组建卸载后，有异步回调执行setState时报错问题
 componentWillUnmount () {
    this._isMounted = false
 }
 // render表格每一列
  renderColumns = () => {
    const { columns} = this.props;
    return columns.map((item) => {
      if (typeof item.render === 'function') {
        return (
          <Table.Column
            title={item.title}
            key={item.key}
            cell={item.render}
            width={item.width || 150}
            sortable={item.sortable}
          />
        );
      }

      return (
        <Table.Column
          key={item.key}
          title={item.title}
          dataIndex={item.dataIndex}
          width={item.width || 150}
          sortable={item.sortable}
        />
      );
    });
  };

  render() {
    const {pageData,changePage} = this.props;
    var pagination = '';
    if(pageData){ // 传入分页数据则渲染分页组件
      pagination = <Pagination
                      { ...pageData }
                      type={this.state.isMobile ? 'simple' : 'normal'}
                    />
    }
    return(
      <div>
        <Table {...this.props}>{this.renderColumns()}</Table>
        <div style={styles.paginationWrapper}>
          { pagination }
        </div>
      </div>
    )
  }
}
const styles = {
  paginationWrapper: {
    textAlign: 'right',
    paddingTop: '26px',
  }
}