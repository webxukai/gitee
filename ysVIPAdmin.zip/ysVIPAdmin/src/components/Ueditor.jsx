/**

*作者：CHAO TIAN

*时间：2018-06-08

*描述：富文本组件

**/

import React, { Component } from 'react';
var editor;
export default class Ueditor extends Component {
  static displayName = 'Ueditor';

  static propTypes = {
    
  };

  static defaultProps = {
    onChange:function(){}
  };

  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount(){
    editor = UE.getEditor(this.props.id);
    editor.ready(()=> {
      editor.setContent(this.props.value || '')
      editor.addListener("contentChange",()=>{   // UEditor 图片上传完成后不会触发contentChange 事件，点击按钮时再一次获取
        this.props.onChange(editor.getContent());
      }); 
    })
  }
  getValue = ()=>{
    return editor.getContent();
  }
  componentWillUnmount() {
    // 组件卸载后，清除放入库的id
    editor.destroy();
    var textArea = document.getElementById('content'); // 删除生成的textArea
    textArea.parentNode.removeChild(textArea)
  }
  render() {
    return(
        <div>
          <script id={this.props.id} name="content" type="text/plain" style={{minWidth:"500px",height:"500px"}}>           
          </script>
        </div>
    )
  }
}
