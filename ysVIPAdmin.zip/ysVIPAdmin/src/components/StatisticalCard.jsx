import React, { Component } from 'react';
import IceContainer from '@icedesign/container';
import { enquireScreen } from 'enquire-js';
import { Balloon, Icon, Grid,Loading} from '@icedesign/base';
import DynamicIcon from 'dynamic-icon';
const CustomIcon = DynamicIcon.create({
  fontFamily: 'iconfont',
  prefix: 'icon',
  css: 'https://at.alicdn.com/t/font_731684_pq76oibbmae.css'
});
const { Row, Col } = Grid;


export default class StatisticalCard extends Component {
  static displayName = 'StatisticalCard';

  constructor(props) {
    super(props);
    this.state = {
      isMobile:false
    }
  }

  componentDidMount() {
    this._isMounted = true;
    this.enquireScreenRegister();
  }

  enquireScreenRegister = () => {
    const mediaCondition = 'only screen and (max-width: 720px)';

    enquireScreen((mobile) => {
      if(!this._isMounted) return
      this.setState({
        isMobile: mobile,
      });
    }, mediaCondition);
  };
  componentWillUnmount () {
    this._isMounted = false
  }
  renderItem = () => {
    const itemStyle = this.state.isMobile ? { justifyContent: 'left' } : {};
    var { items,dataSource } = this.props;
    return items.map((data, idx) => {
      return (
        <Col xxs="24" s={24/(items.length)} l={24/(items.length)} key={idx}>
          <div style={{ ...styles.statisticalCardItem, ...itemStyle }}>
            <div style={styles.circleWrap}>
              <CustomIcon type={data.icon} style={styles.imgStyle} />
            </div>
            <div style={styles.statisticalCardDesc}>
              <div style={styles.statisticalCardText}>
                {data.text}
                <Balloon
                  align="t"
                  alignment="edge"
                  trigger={
                    <span>
                      <Icon type="help" style={styles.helpIcon} size="xs" />
                    </span>
                  }
                  closable={false}
                >
                  {/* {data.desc} */}
                  {dataSource[data.desc]}
                </Balloon>
              </div>
              <div style={styles.statisticalCardNumber}>{dataSource[data.filed]}</div>
            </div>
          </div>
        </Col>
      );
    });
  };

  render() {
    return (
      <IceContainer style={styles.container}>
        <Row wrap>{this.renderItem()}</Row>
      </IceContainer>
    );
  }
}

const styles = {
  container: {
    padding: '10px 20px',
  },
  statisticalCardItem: {
    display: 'flex',
    justifyContent: 'center',
    padding: '10px 0',
  },
  circleWrap: {
    width: '70px',
    height: '70px',
    position: 'relative',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '50%',
    marginRight: '10px',
    background:"#eff6ff"
  },
  imgStyle: {
    maxWidth: '100%',
    color:'rgb(31, 130, 255)',
    fontSize:'30px'
  },
  helpIcon: {
    marginLeft: '5px',
    color: '#b8b8b8',
  },
  statisticalCardDesc: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  statisticalCardText: {
    position: 'relative',
    color: '#333333',
    fontSize: '12px',
    fontWeight: 'bold',
    marginBottom: '4px',
  },
  statisticalCardNumber: {
    color: '#333333',
    fontSize: '24px',
  },
  itemHelp: {
    width: '12px',
    height: '12px',
    position: 'absolute',
    top: '1px',
    right: '-15px',
  },
};
