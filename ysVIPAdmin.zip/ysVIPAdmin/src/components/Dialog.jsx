/**

*作者：CHAO TIAN

*时间：2018-06-08

*描述：模态框组件

**/
import React, { Component } from 'react';
import { Dialog, Button } from '@icedesign/base';

export default class EditDialog extends Component {
  static displayName = 'EditDialog';

  static defaultProps = {};

  constructor(props) {
    super(props);
    this.state = {
      visible: false
    };
  }
  // 打开方法
  onOpen = async (record) => {
    if(this.props.cantOpen){
      if(typeof this.props.cantOpen === "function"){
        this.props.cantOpen();
      }
      return;
    }
    // 有传入的open方法则进行调用
    this.props.open && await this.props.open();
    this.setState({
      visible: true
    });
  };
  // 关闭方法
  onClose = () => {
    // 有传入的open方法则进行调用
    this.props.close && this.props.close();
    this.setState({
      visible: false,
    });
  };

  render() {
    const formItemLayout = {
      labelCol: {
        fixedSpan: 6,
      },
      wrapperCol: {
        span: 14,
      },
    };
    var trigger = this.props.trigger ? <span onClick={() => this.onOpen()}>{this.props.trigger}</span> : 
                  <Button type="primary" onClick={() => this.onOpen()} size={this.props.size || 'medium'} {...this.props}>
                    {this.props.title}
                  </Button>
    return (
      <div style={styles.editDialog}>
        { trigger }
        <Dialog
          style={{ width: 640 }}
          visible={this.state.visible}
          onOk={this.props.handleSubmit} // 点击调用父组件确认方法
          closable="esc,mask,close"
          onCancel={this.onClose}
          onClose={this.onClose}
          title={this.props.title} // 标题
        >
          { this.props.children }
        </Dialog>
      </div>
    );
  }
}

const styles = {
  editDialog: {
    display: 'inline-block',
    margin: '0 2.5px',
  },
};
