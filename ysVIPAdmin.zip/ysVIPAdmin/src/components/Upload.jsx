import { Upload, Button } from "@icedesign/base";
import Img from '@icedesign/img';

const { Core } = Upload;

class UploadCore extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    var img;
    if(this.props.value){
      img = <img src = {this.props.value}  style={{verticalAlign:'middle',marginRight:'15px',width:'100px'}}/>
      // img = <Img src={this.props.value} width={100} height={100} type="contain" />
    }
    else{
      img = <div 
            style={{
              display: "inline-block",
              textAlign: "center",
              width: "100px",
              height: "100px",
              lineHeight: "100px",
              border: "1px dashed #aaa",
              borderRadius: "5px",
              fontSize: "12px"
            }} 
            >上传</div>
    }
    return (
      <div style={styles.wrap}>
        {
          // <Core
          //   ref="inner"
          //   accept="image/png, image/jpg, image/jpeg, image/gif, image/bmp"
          //   name="filename"
          //   onStart={onStart}
          //   onSuccess={onSuccess}
          //   onError={onError}
          //   onChange={onChange.bind(this)}
          // >
          // {img}
          // </Core>
          // <br />
        }
        <input type='file' style={styles.file} onChange={onChange.bind(this)}/>
        { img }
      </div>
    );
  }
}


function beforeUpload(file) {
  console.log("beforeUpload callback : ", file);
}
function onChange(e) {
  var reader = new FileReader();
  var file = e.target.files[0] || e.dataTransfer.files[0],
      that = this;
  reader.onload = function () {
    that.props.onChange(this.result)
  }
  this.props.getFile(file)
  reader.readAsDataURL(file);
}
function onStart(files) {
  console.log("onStart callback : ", files);
}

function onProgress(e, file) {
  console.log("onProgress callback : ", e, file);
}

function onSuccess(res, file) {
  console.log("onSuccess callback : ", res, file);
}

function onError(err, res, file) {
  console.log("onError callback : ", err, res, file);
}

function onAbort(e, file) {
  console.log("onAbort callback : ", e, file);
}
export default UploadCore
const styles = {
  wrap:{
    position:'relative'
  },
  file:{
    position:'absolute',
    left:"0",
    top:"0",
    opacity:"0",
    width:"100px",
    height:"100px"
  }
}

