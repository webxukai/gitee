import React from 'react';
import { Loading } from '@icedesign/base';

const LoadingIndicator = (props) => {
  var color = props.color ? props.color : '#fff';
  return (
    <Loading shape="dot-circle" color={color} style={{ display: 'block', height: '100%',zIndex:'9999' }} {...props }>
        <div style={{ background: 'transparent' }} />
    </Loading>
  );
};

export default LoadingIndicator;