import FilterWithSearch from './FilterWithSearch';

export default FilterWithSearch;
