// <!-- auto generated navs start -->
const autoGenHeaderNavs = [];
const autoGenAsideNavs = [];

// <!-- auto generated navs end -->

const customHeaderNavs = [
  {
    text: '首页',
    to: '/',
    icon: 'home',
  }
];

var customAsideNavs;

function transform(navs) {
  // custom logical
  return [...navs];
}
export const setAsideNavs = (navs)=>{
  customAsideNavs = navs;
}
export const headerNavs = transform([
  ...autoGenHeaderNavs,
  ...customHeaderNavs,
]);
export const getAsideNavs = ()=>{
  return transform([...autoGenAsideNavs, ...customAsideNavs])
}
