

import React, { Component } from 'react';
import { Loading } from "@icedesign/base";
import { connect } from 'react-redux'
import LoadingIndicator from './components/Loading'
@connect((state)=>{
  return {
    loading:state.page.loading
  }
})
export default class App extends Component {
  static displayName = 'App';

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <LoadingIndicator visible={ this.props.loading } color="#333"/>
        {this.props.children}
      </div>
    );
  }
}
