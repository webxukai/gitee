import axios from 'axios'
import store from './redux/store'
import { showLoading ,hideLoading} from './redux/actions'
import { hashHistory } from 'react-router';
import { Feedback } from "@icedesign/base";
// var baseURL = 'https://api.xiaofeitongbao.com/xft',
// var baseURL = 'http://192.168.0.209:8088/xft',
// var baseURL = 'https://dev.xiaofeitongbao.com/xft',
// var baseURL = 'http://106.15.90.68:8899',
var baseURL = 'http://192.168.101.150:8899',

// var baseURL = 'http://192.168.0.166:8910',
// var baseURL = 'http://192.168.0.202:8088/xft',
// var baseURL = 'http://192.168.0.6:8899',
	// imgURL = 'https://api.xiaofeitongbao.com/file/image/download',
	imgURL = 'https://dev.xiaofeitongbao.com/file/image/download',
	num = 0;
axios.defaults.baseURL = baseURL;
axios.interceptors.request.use(config => {
	if(!config.noloading){
	 if(num == 0){
	 	store.dispatch(showLoading())
	 }
  		num++
   }
  return config
}, error => {
  return Promise.reject(error)
})
axios.interceptors.response.use(response => {
	if(!response.config.noloading){
	  num--
	  if (num <= 0) {
		  store.dispatch(hideLoading())
	  }
	}
  if(response.status == 200){
  	var result = response.data,
  		data;
    // 没有网关层
    if(!result.data){
      data = result;
    }
    else{
    	if(result.data.code == 40000){
    		data = result.data.data
    	}
    	else if(result.data.code == 44002 || result.data.code == 44003){
    		store.dispatch({
    			type:"LOGIN_OUT"
    		})
    		hashHistory.push('/login');
    	}
    	else{
        var msg = result.data.msg
        if (msg == '{"msg":"手机号或密码不正确","code":"45000"}') {
          Feedback.toast.error('手机号或密码不正确')
          throw msg;
        }else {
          Feedback.toast.error(msg)
          throw msg;
        }
    	}
    }
  }
  return data;
}, error => {
  num--
  if (num <= 0) {
	store.dispatch(hideLoading())
  }
  Feedback.toast.error('网络请求失败')
  return Promise.reject(error.response)
})
var net = {
	get({url,data}){
		return new Promise((resolve,reject)=>{
			axios({
				method:"GET",
				url:url+'?token='+store.getState().user.token,
				params:data
			}).then((data)=>{
				resolve(data)
			}).catch((e)=>{
				console.log(e)
				// reject(e)
			})
		})
	},
	post({url,data,params=''}){
		return new Promise((resolve,reject)=>{
			axios({
				method:"POST",
				url:encodeURI(url+'?token='+store.getState().user.token+params),
        data:data
			}).then((data)=>{
				resolve(data)
			}).catch((e)=>{
				console.log(e)
				// reject(e)
			})
		})
	},
  downLoad({url,data,params=''}){
    console.log(url)
    return new Promise((resolve,reject)=>{
      axios({
        method:"POST",
        url:encodeURI(url+'?token='+store.getState().user.token+params),
        data:data,
        responseType:'blob'
      }).then((data)=>{
        resolve(data)
      }).catch((e)=>{
        console.log(e)
        // reject(e)
      })
    })
  },
  delete({url,data,params=''}){
    console.log(url)
    return new Promise((resolve,reject)=>{
      axios({
        method:"DELETE",
        url:encodeURI(url+'?token='+store.getState().user.token+params),
        data:data
      }).then((data)=>{
        resolve(data)
      }).catch((e)=>{
        console.log(e)
        // reject(e)
      })
    })
  },
  put({url,data,params=''}){
    console.log(url)
    return new Promise((resolve,reject)=>{
      axios({
        method:"PUT",
        url:encodeURI(url+'?token='+store.getState().user.token+params),
        data:data
      }).then((data)=>{
        resolve(data)
      }).catch((e)=>{
        console.log(e)
        // reject(e)
      })
    })
  }
}
export default net;

export {
	baseURL,
	imgURL
}