export const SET_USER_INFO = 'SET_USER_INFO'; // 设置用户信息
export const LOGIN_OUT = 'LOGIN_OUT'; // 退出
export const SET_CONFIG = 'SET_CONFIG'; // 全局设置
export const SHOW_LOADING = 'SHOW_LOADING'; // 显示loading
export const HIDE_LOADING = 'HIDE_LOADING'; // 隐藏loading