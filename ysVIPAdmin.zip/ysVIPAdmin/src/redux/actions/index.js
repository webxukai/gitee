import net from '../../net'
// export function getUserinfo(){
// 	return function(dispatch,getState){
// 		dispatch({
// 			type:"start",
// 			palyload:0
// 		})
// 		return new Promise((resove,reject)=>{
// 			setTimeout(()=>{
// 			resove({age:966});
// 			},5000)
// 		}).then((data)=>{
// 			dispatch({
// 				type:'SET_USER_INFO',
// 				payload:data
// 			})
// 		})
// 	}
// }

// 获取用户信息
export function setUserinfo({username,password}){
	return {
		type:"SET_USER_INFO",
		payload:new Promise((resove,reject)=>{
				net.post({
					url:'/memberAdmin/merchant/login',
					data:{
						phone:username,
						password
					}
				}).then((data)=>{
					resove(data);
				})
		})
	}
}
// 全局设置
export function setConfig(){
	return {
		type:"SET_CONFIG",
		payload:new Promise((resove,reject)=>{
				net.post({
					url:'/memberAdmin/setting/getSetting',
      		data:{}
				}).then((data)=>{
					resove(data);
				})
		})
	}
}
export function showLoading(){
	return {
		type:"SHOW_LOADING",
		payload:{
			loading:true
		}
	}
}

export function hideLoading(){
	return {
		type:"HIDE_LOADING",
		payload:{
			loading:false
		}
	}
}