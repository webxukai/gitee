import  { SHOW_LOADING,HIDE_LOADING }  from '../actions/types';

const initialState = {
  loading:false
}

export default function(state=initialState, action) {
  switch (action.type) {
    case SHOW_LOADING: {
      return {
        ...state,
        ...action.payload
      }
    }
    case HIDE_LOADING:{
      return {
        ...state,
        ...action.payload
      }
    }
    default:
      return state;
  }
}