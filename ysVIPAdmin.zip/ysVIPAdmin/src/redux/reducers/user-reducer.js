import  { SET_USER_INFO,LOGIN_OUT,SET_CONFIG }  from '../actions/types';

const initialState = {
  token:sessionStorage.getItem('token'),
  userInfo:{},
  settingList:[
    {},{},{},{},{},{},{}
  ],
  levelList:[
    {}
  ]
}

export default function(state=initialState, action) {
  switch (action.type) {
    case SET_USER_INFO: {
      sessionStorage.setItem('token',action.payload.token)
      return {
        ...state,
        token:action.payload.token,
        userInfo:action.payload
      }
    }
    case LOGIN_OUT:{
      sessionStorage.removeItem('token');
      return {
        ...state,
        token:""
      }
    }
    case SET_CONFIG:{
      return {
        ...state,
        settingList:action.payload.settingList,
        levelList:action.payload.levelList
      }
    }
    default:
      return state;
  }
}