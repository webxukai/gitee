import { combineReducers } from 'redux';
import userReducer from './user-reducer';
import pageReducer from './page-reducer';

const allReducers = {
  user: userReducer,
  page:pageReducer
}

const rootReducer = combineReducers(allReducers);

export default rootReducer;