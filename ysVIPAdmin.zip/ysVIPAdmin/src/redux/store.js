import { createStore,applyMiddleware,compose } from "redux";
import promise from 'redux-promise'
import rootReducer from './reducers';

	var store = createStore(rootReducer,compose(applyMiddleware(promise)));


export default store;