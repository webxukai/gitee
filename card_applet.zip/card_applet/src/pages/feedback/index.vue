<template>
  <div class='wrap'>
    <textarea placeholder="请输入您的意见 ..." placeholder-style="font-size:28rpx;color:#333" @input="getContent" :value="content"></textarea>
    <div :class="{'btn':true,unLogin:!content.length}" @tap='submit'>提交</div>
  </div>
</template>

<script>
import net from '@/utils/net'
import tip from '@/utils/tip'
export default {

  data () {
    return {
      content:""
    }
  },
  methods:{
    async submit(){
      if(!this.content.length)return;
      tip.loading('提交中...')
      var result = await net.post({
        url:'/memberMiniprogram/zone/feedback',
        data:{
          content:this.content
        },
        showLoading:false
      })
      tip.loaded();
      if(result){
        tip.tip('提交成功');
        this.content = '';
      }
      else{
        tip.tip('提交失败');
      }
    },
    getContent(e){
      this.content = e.mp.detail.value
    }
  }
}
</script>

<style scoped>
  .wrap{
    padding: 20rpx;
  }
  textarea{
    background: #fff;
    width: 100%;
    height: 260rpx;
    padding:20rpx;
    box-sizing: border-box;
    font-size: 28rpx;
    color: #333333;
  }
  .btn {
    height: 80rpx;
    background: #0390FF;
    border-radius: 8rpx;
    width: 670rpx;
    text-align: center;
    margin: 50rpx auto 0 auto;
    font-size: 32rpx;
    color: #FFFFFF;
    line-height: 80rpx;
  }
  .btn.unLogin {
    background: #D9D9D9;
    color: #999999;
  }
</style>
