<template>
  <div>
    <div class="gap"></div>
    <div class="heac-cell flexBox">
      <div class="cell-name">头像</div>
      <div class="flex1 icon-cont">
        <img :src="userInfo.avatarUrl"/>
      </div>
    </div>
    <div class="gap"></div>
    <div class="cell-cont">
      <div class="cell onborder flexBox">
        <div class="cell-name">昵称</div>
        <div class="flex1 cell-val">{{userInfo.nickName}}</div>
      </div>
    </div>
    <a class="cell-cont" href="/pages/phoneInfo/main">
      <div class="cell flexBox">
        <div class="cell-name">手机号</div>
        <div class="flex1 cell-val link">{{userInfo.phone}}</div>
      </div>
    </a>
  </div>
</template>
<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import base from '@/mixins/base'

  export default {
    data() {
      return {
        userInfo:null,
        init: false
      }
    },
    mixins: [base],
    methods: {
      
    },
    onLoad(){
      this.userInfo = getApp().globalData.userInfo
    }
  }

</script>
<style scoped>

  .link:after {
    display: block;
    content: ' ';
    width: 15rpx;
    height: 15rpx;
    border-style:solid;
    border-color: #999;
    border-width: 1rpx 1rpx 0 0;
    position: absolute;
    transform: rotate(45deg);
    right: 30rpx;
    top: 40rpx;
  }

  .cell-val {
    position: relative;
    text-align: right;
    padding-right: 60rpx;
    height: 100rpx;
    line-height: 100rpx;
  }

  .onborder {
    border-bottom: 1rpx solid #DBDBDB;
  }

  .cell {
    height: 100rpx;
    line-height: 100rpx;
  }

  .cell-cont {
    background-color: #FFF;
    padding: 0 0 0 30rpx;
    font-size: 28rpx;
    color: #333333;

  }

  .heac-cell {
    background-color: #FFF;
    height: 160rpx;
    line-height: 160rpx;
    font-size: 28rpx;
    color: #333333;
    padding: 0 60rpx 0 30rpx;
  }

  .cell-name {
    text-align: left;
  }

  .icon-cont {
    text-align: right;
    box-sizing: border-box;
  }

  .icon-cont img {
    width: 120rpx;
    height: 120rpx;
    border-radius: 50%;
    vertical-align: middle;
  }

</style>
