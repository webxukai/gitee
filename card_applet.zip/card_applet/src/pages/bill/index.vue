<template>
  <div class='wrap' v-if="init">
    <div class="list">
      <div class="clFlexBox">
        <div class="flexBox picker-cont">
          <div class="flex1">
            <picker mode="date" :value="queryMonth" start="1995-06" :end="nowMonth" @change="changeMonth" fields="month">
              <view class="picker">
                <span>{{queryMonth}}</span>
                <img src='/static/down.png' />
              </view>
            </picker>
          </div>
          <div class="flex1">
            <picker mode="selector" :range="cardList" range-key="cardName" @change="changeCard">
              <view class="picker">
                <span>{{setMealName || '卡筛选'}}</span>
                <img src='/static/down.png'/>
              </view>
            </picker>
          </div>
        </div>
        <scroll-view class="flex1 listWrap" scroll-y v-if="bills.length" @scrolltolower="loadMore">

          <div class="bill-cont" @tap='toDetail(item)' v-for="(item,index) in bills" :key="index">
            <div class="bill-item flexBox">
              <div class="flex1">
                <div class="shop-name">{{item.merchantName}}
                  <span class='label' v-if="item.userCardKid != queryUserCare.userKid">家庭组-{{item.userCardName}}的卡</span>
                </div>
                <div class="bill-type">
                  {{ (item.type == 0 && item.operatorUserKid == queryUserCare.userKid) ? "[个人消费]": (item.type == 0 && item.operatorUserKid
                  != queryUserCare.userKid) ? "[家庭组-"+item.operatorUserName+"消费]" : (item.type == 1 && item.operatorUserKid
                  == queryUserCare.userKid) ? "[个人充值]": "[家庭组-"+item.operatorUserName+"充值]" }}
                </div>
                <div class="bill-time">{{item.createTime}}</div>
              </div>
              <div class="right">
                <div class="bill-money">{{item.type==0 ? '-':'+'}}{{item.sunmoney}}</div>
                <div class="bill-money-tip" v-if="item.giveMoney != null">其中{{item.type==0 ? '-':'+'}}{{item.giveMoney}}赠送金额</div>
              </div>
            </div>
          </div>

        </scroll-view>
        <div class="no-list flex1" v-if="!bills.length">
          <img src="/static/no-bill.png" />
          <div class='nocon'>暂无任何账单信息</div>
        </div>
      </div>

    </div>
  </div>

</template>

<script>
  import card from '@/components/card'
  import {
    mapGetters
  } from 'vuex'
  import net from '@/utils/net'
  import { accAdd } from '@/utils'
  import base from '@/mixins/base'
  import tip from '@/utils/tip'
  import moment from 'moment'

  export default {
    data() {
      return {
        init: false,
        end: false, //是否加载到最后一页
        bills: [],
        cardList: [], // 卡套餐集合
        nowMonth: "",
        queryMonth: "",
        setMealName: "", //卡套餐名称
        queryCare: { // 某套餐账单列表的查询参数
          limit: 10,
          page: 1,
          month: '',
          setMealKid: ''
        },
        queryUserCare: { // 用户卡套餐账单列表
          "nowMonth": "",
          "offset": 1,
          "pageSize": 10,
          "userKid": ""
        }
      }
    },
    mixins: [base],
    methods: {
      // 切换月份
      async changeMonth(e) {
        this.queryMonth = e.mp.detail.value;
        if (!this.queryCare.setMealKid) {
          this.queryUserCare.offset = 1;
          await this.getUserBills();
          tip.loaded();
        } else {
          this.queryCare.page = 1;
          await this.getBillList();
          tip.loaded();
        }
      },
      // 切换卡套餐
      async changeCard(e) {
        var index = e.mp.detail.value;
        if (index != 0) {
          this.setMealName = this.cardList[index].cardName;
          this.queryCare.setMealKid = this.cardList[index].cardKid;
          this.queryCare.page = 1;
          await this.getBillList();
          tip.loaded()
        } else {
          this.setMealName = '';
          this.queryCare.setMealKid = '';
          this.queryUserCare.offset = 1;
          await this.getUserBills();
          tip.loaded();
        }
      },
      // 某套餐账单列表的查询参数
      async getBillList(more, noloading) {
        if (!more) this.end = false
        this.queryCare.month = moment(this.queryMonth).format('YYYYMM');
        var bills = await net.post({
          url: '/memberMiniprogram/bill/',
          data: this.queryCare,
          showLoading: !noloading
        })
        console.log(bills)
        bills = bills.consumerRecordAOList
        bills.forEach((item) => {
          item.createTime = moment(item.createTime).format('YYYY-MM-DD HH:mm')
          var giveMoney = item.giveMoney || 0;
          item.sunmoney = accAdd(item.money, giveMoney)
        })
        if (bills.length < 10) {
          this.end = true;
        }
        if (more) {
          this.bills = [...this.bills, ...bills]
        } else {
          this.bills = bills
        }
      },
      // 获取用户卡套餐账单
      async getUserBills(more, noloading) {
        if (!more) this.end = false
        this.queryUserCare.nowMonth = moment(this.queryMonth).format('YYYYMM');
        var bills = await net.post({
          url: '/memberMiniprogram/bill/queryUserRecord',
          data: this.queryUserCare,
          showLoading: !noloading
        })
        bills.forEach((item) => {
          item.createTime = moment(item.createTime).format('YYYY-MM-DD HH:mm')
          var giveMoney = item.giveMoney || 0;
          item.sunmoney = accAdd(item.money, giveMoney)
        })
        if (bills.length < 10) {
          this.end = true;
        }
        if (more) {
          this.bills = [...this.bills, ...bills]
        } else {
          this.bills = bills
        }
      },
      // 获取卡套餐集合
      async getSelectCard() {
        var cardList = await net.post({
          url: '/memberMiniprogram/bill/querySelectCard',
          data: {
            userKid: this.queryUserCare.userKid
          },
          showLoading: false
        })
        this.cardList = [{
          cardKid: "",
          cardName: "不选择"
        }, ...cardList]
      },
      toDetail(info) {
        if (info.type == 1) {
          wx.navigateTo({
            url: '/pages/as_recharge/main?info=' + JSON.stringify(info)
          })
        } else {
          wx.navigateTo({
            url: '/pages/as_consumption/main?info=' + JSON.stringify(info)
          })
        }
      },
      async loadMore() {
        if (this.end) return;
        if (!this.queryCare.setMealKid) { // 没有选择卡套餐
          this.queryUserCare.offset++;
          await this.getUserBills(true);
          tip.loaded();
        } else {
          this.queryCare.page++;
          await this.getBillList(true)
          tip.loaded();
        }
      },
      async initLoad() {
        this.end = false;
        await this.getSelectCard();
        if (!this.queryCare.setMealKid) { // 没有选择卡套餐
          this.queryUserCare.offset = 1;
          await this.getUserBills('', true);
        } else {
          // 当前选中卡是否还在
          var flag = this.cardList.some((item) => {
            return item.cardKid == this.queryCare.setMealKid
          })
          if (!flag) { // 不存在{
            this.queryCare.setMealKid = '';
            this.setMealName = '';
            this.queryUserCare.offset = 1;
            await this.getUserBills('', true)
          } else {
            this.queryCare.page = 1;
            await this.getBillList('', true)
          }
        }
      }
    },
    async onLoad() {
      this.queryMonth = this.nowMonth = moment().format('YYYY-MM')
      this.queryUserCare.userKid = getApp().globalData.userKid
    },
    async onShow() {
      await this.initLoad();
      this.init = true;
    }
  }

</script>

<style scoped>
  .wrap,
  .list,
  .clFlexBox {
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .listWrap{
    overflow: hidden;
  }
  .nocon {
    font-size: 26rpx;
    color: #666666;
  }

  .no-list {
    text-align: center;
    font-size: 26rpx;
    color: #666666;
    background-color: #fff;
    overflow: hidden;
  }

  .no-list img {
    width: 400rpx;
    margin: 115rpx auto 18rpx auto;
    height: 400rpx;
    transform: translateX(-20rpx);
  }

  .shop-name .label {
    font-size: 18rpx;
    color: #FFFFFF;
    background-image: linear-gradient(-141deg, #FD9381 3%, #FD5D55 100%);
    padding: 4rpx 6rpx;
    border-radius: 4rpx;
    margin: 0 14rpx;
    line-height: 18rpx;
    margin-left: 15rpx;
  }

  .shop-name span {
    display: inline-block;
    vertical-align: middle;
  }

  .bill-money-tip {
    text-align: right;
    font-size: 22rpx;
    color: #FF9800;
    line-height: 8rpx;

  }

  .bill-item .right {
    width: 250rpx;
  }

  .bill-money {
    text-align: right;
    font-size: 36rpx;
    color: #333333;
    line-height: 90rpx;
    font-weight: bold;
  }

  .bill-time {
    font-size: 22rpx;
    color: #999999;
    line-height: 28rpx;
  }

  .bill-type {
    font-size: 22rpx;
    color: #333333;
    line-height: 56rpx;
  }

  .shop-name {
    font-size: 30rpx;
    color: #333333;
  }

  .bill-item {
    height: 126rpx;
  }

  .bill-cont {
    background-color: #FFF;
    padding: 20rpx;
    border-bottom: 1rpx solid #DBDBDB;
  }

  .picker-cont {
    border-bottom: 1rpx solid #DBDBDB;
    text-align: center;
    font-size: 26rpx;
    color: #666666;
    height: 80rpx;
    line-height: 80rpx;
    background-color: #FFF;
  }

  .picker span {
    display: inline-block;
    vertical-align: middle;
  }

  .picker img {
    width: 14rpx;
    height: 9rpx;
    vertical-align: middle;
    margin-left: 15rpx;
  }

</style>
