import Vue from 'vue'
import App from './index'

const app = new Vue(App)
app.$mount()
export default {
  config: {
    navigationBarTitleText: '付款码',
    navigationBarBackgroundColor: '#07C3FF',
    navigationBarTextStyle: 'white',
    backgroundTextStyle: "light"
  }
}
