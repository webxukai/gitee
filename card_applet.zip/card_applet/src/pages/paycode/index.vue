<template>

  <div>
    <div class="bg-cont">
      <div class="code-cont">
        <div class="code-tip">
          <span>条形付款码</span>
          <img src="/static/reflash.png" class='reflash' @tap="reflash">
        </div>
        <canvas id='barcode' canvas-id="barcode" :hidden="(shelter || showPayIpt || showPaying)"></canvas>
      </div>
    </div>
    <div class="shelter" v-bind:hidden="!shelter">
      <div class="tip-cont">
        <div class="chose-tip">请选择支付方式</div>
        <img class="close" src='/static/close.png' @tap='hidden'>
        <div class='meals'>
          <div v-for="(item,index) in meals" :key="index"  :class="{'pay-type-line':true,'check':index == checked} " @click="check(index)">
            <img src='/static/select.png'>
            <div class="flexBox line">
              <div class="flex1">
                <div class="card-name" v-if="item.userKid == userKid">个人卡</div>
                <div class="card-name" v-else>家庭组-{{item.userName}}的卡</div>
                <div class="discont">{{item.properties}}</div>
              </div>
              <div class="balance">
                ￥{{item.balance}}
              </div>
            </div>
          </div>
        </div>
        <div class="prime-btn" @tap="chooseMeal">确定</div>
      </div>
    </div>
    <payInput ref='payInput' @end="end" @close="closePayInput"></payInput>
   <paying ref='paying' @cancle='canclePay'></paying>
  </div>

</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net,{ socketType,socketUrl } from '@/utils/net'
  import tip from '@/utils/tip'
  import socket from '@/utils/websocket'
  import base from '@/mixins/base'
  import wxbarcode from 'wxbarcode'
  import moment from 'moment'
  import payInput from '@/components/payInput'
  import paying from '@/components/paying'
  export default {
    data() {
      return {
        leave:false,//判断是否离开
        status:'',//当前状态
        socketUrl:'',
        socket:"", // socket对象
        payCode:"", // 条形码
        init: false,
        shelter:false, //是否显示支付方式
        meals:[], // 套餐列表
        checked:0, // 选择套餐的项数
        interval:null,
        showPaying:false,//正在支付显示
        showPayIpt:false,//密码框显示
        open:false // 连接状态
      }
    },
    mixins: [base],
    components: {
      card,
      payInput,
      paying
    },
    methods: {
      //取消支付
      canclePay(){
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid
            },
            dataType:socketType.CANCELPAY
          })
        })
      },
      //选择套餐
      chooseMeal(){
        var meal = this.meals[this.checked];
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid,
              userSetMealkid:meal.kid
            },
            dataType:socketType.SELECTSETMEAL
          })
        })
        this.shelter = false;
      },
      // 接受用户密码
      end(pwd){
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid,
              payPwd:pwd
            },
            dataType:socketType.PAYPWD
          })
        })
        this.showPayIpt = false;
      },
      // 显示正在支付
      showPayings() {
        this.$refs.paying.show()
        this.showPaying = true;
      },
      // 隐藏正在支付
      hidePaying() {
        this.$refs.paying.hidden();
        this.showPaying = false;
      },
      //显示密码输入框
      showPayInput() {
        this.$refs.payInput.show()
        this.showPayIpt = true;
      },
      //隐藏密码输入框
      hidePayInput() {
        this.$refs.payInput.hide()
        this.showPayIpt = false;
      },
      //用户关闭密码框
      closePayInput(){
        this.showPayIpt = false;
        this.canclePay();//取消支付
      },
      //获取socket地址
      async getSocket(){
        var result = await net.post({
          url:'/memberMiniprogram/delivery/getWebSocketServer',
          data:{
            userKid:getApp().globalData.userKid
          }
        })
        this.socketUrl = `ws://${result.ip}:${result.port}`
      },
      //发送支付密码
      payPwd() {
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid,
              payPwd:''
            },
            dataType:socketType.PAYPWD
          })
        })
      },
      // 刷新条形码
      reflash(){
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid
            },
            dataType:socketType.NEWPAYCODE
          })
        })
      },
      checkConnect(){
        this.interval = setInterval(()=>{

        },3000)
      },
      //选择套餐项
      check(index){
        this.checked = index;
      },
      //隐藏套餐
      hidden(){
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid
            },
            dataType:socketType.CANCELLOGIN
          })
        })
      },
      // 获取条形码
      getPayCode(){
        this.socket.send({
          data:JSON.stringify({
            data:{
              userKid:getApp().globalData.userKid
            },
            dataType:socketType.GETPAYCODE
          })
        })
      },
      // 创建websocket及监听事件
      createWebSocket(){
        this.socket = wx.connectSocket({
          url: this.socketUrl
        })
        console.log('重连')
        this.socket.onOpen(()=>{
          this.socket.send({
              data:JSON.stringify({
                data:{
                  userKid:getApp().globalData.userKid,
                },
                dataType : socketType.BINGDING
              })
          })
          clearInterval(this.interval)
          tip.loaded();
        })
        this.socket.onMessage((res)=> {
          var data = JSON.parse(res.data);
          // 保持心跳链接
          if(data.data == '020003'){
            this.open = true;
            this.socket.send({
              data:JSON.stringify({
                data:'020003',
                dataType:socketType.HEARTBEAT
              })
            })
            this.open = false;
          }
          // 要获取条形码
          if(data.dataType == socketType.GETPAYCODE){
            this.getPayCode()
          }
          if(data.dataType == socketType.PAYCODE){
            // 生成条形码
             wxbarcode.barcode('barcode',data.data.payCode,680,200)
          }
          if(data.dataType == socketType.NEWPAYCODE){
            // 刷新条形码
             wxbarcode.barcode('barcode',data.data.payCode,680,200)
          }
          if(data.dataType == socketType.SELECTSETMEAL){
            // 选择套餐
            this.shelter = true;
            this.status = socketType.SELECTSETMEAL;
            this.meals = data.data.userSetMealInfoList
          }
          // 正在支付
          if(data.dataType == socketType.BEINGPAID){
            this.status = socketType.BEINGPAID;
            this.showPayings();
          }
          //输入密码框
          if(data.dataType == socketType.PAYPWD){
            this.showPayInput();
          }
          // 取消支付
          if(data.dataType == socketType.CANCELPAY){
            var status = data.data.status;
            if(status == 'ok'){
              this.hidePaying();
              this.status = '';
              tip.tip('取消支付')
              this.getPayCode();
            }
          }
          // 支付成功
          if(data.dataType == socketType.PAID){
            this.hidePayInput();
            this.hidePaying();
            tip.loaded();
            tip.tip('支付成功');
            this.getPayCode();
          }
          //支付失败
          if(data.dataType == socketType.NONPAID){
            this.hidePaying();
            this.hidePayInput();
            this.shelter = false;
            this.status = '';
            this.getPayCode();
          }
          // 异常
          if(data.dataType == socketType.EXCEPTION){
            tip.loaded();
            tip.tip(data.data,false);
          }

        })
        this.socket.onClose((msg)=>{
          if(this.leave) return
          tip.loading('重连中...')
          this.interval = setInterval(async ()=>{
            await this.getSocket()
            await this.createWebSocket();
          },5000)
        })
      }
    },
    async onLoad(){
      this.leave = false;
      await this.getSocket()
      await this.createWebSocket();
    },
    onUnload(){
      this.shelter = false;
      this.checked = 0;
      this.leave = true;
      // // 当前状态是选择套餐
      // if(this.status == socketType.SELECTSETMEAL){
      //   this.hidden();
      // }
      // // 正在支付状态
      // else if(this.status == socketType.BEINGPAID){
      //   this.canclePay()
      //   this.hidePaying();
      //   this.status = '';
      // }
      // else{
      this.hidePaying()
      this.hidePayInput()
      // }
      this.socket.close()
      clearInterval(this.interval)
      this.interval = null;
    }
  }

</script>

<style scoped>
  .code-cont .reflash{
    position: absolute;
    right: 30rpx;
    top:50%;
    width: 40rpx;
    height: 40rpx;
    transform:translateY(-50%);
  }
  .line {
    border-bottom: 1rpx solid #E5E5E5;
    height: 130rpx;
    line-height: 130rpx;
  }
  #barcode{
    width: 680rpx;
    height: 200rpx;
    position: absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
  }
  .balance {
    font-size: 32rpx;
    color: #333333;
  }

  .discont {
    font-size: 20rpx;
    color: #999999;
    line-height: 10rpx;
    margin-top: -15rpx;
  }

  .card-name {
    font-size: 28rpx;
    color: #333333;
    line-height: 100rpx;
  }

  .prime-btn {
    width: 370rpx;
    height: 80rpx;
    margin: 80rpx auto 40rpx;
  }

  .pay-type-line {
    padding: 0 40rpx 0 60rpx;
    position: relative;
  }
  .pay-type-line img{
    display: none;
  }
  .check img{
    display: block;
    width: 28rpx;
    height: 28rpx;
    position: absolute;
    top:58rpx;
    left: 19rpx;
  }
  .close {
    width: 28rpx;
    height: 28rpx;
    position: absolute;
    right:20rpx;
    top:20rpx;
  }

  .chose-tip {
    position: relative;
    font-size: 16px;
    color: #0390FF;
    text-align: center;
    border-bottom: 1px solid #E5E5E5;
    font-weight: bold;
    height: 100rpx;
    line-height: 100rpx;
  }

  .shelter {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.50);
  }

  .bg-cont {
    overflow: hidden;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: linear-gradient(-180deg, #07C3FF 0%, #0390FF 100%);
  }

  .code-cont {
    width: 710rpx;
    height: 600rpx;
    background-color: #FFF;
    box-shadow: 0 4rpx 40rpx 0 #0493F2;
    border-radius: 10rpx;
    margin: 260rpx auto;
    position: relative;
  }

  .tip-cont {
    width: 670rpx;
    height: 572rpx;
    background-color: #FFF;
    border-radius: 10rpx;
    margin: 274rpx 40rpx 0;
    position: relative;
    display: flex;
    flex-direction: column;
  }
  .meals{
    flex:1;
    overflow-y:auto;
  }
  .code-tip {
    position: relative;
    background: #D7F5FF;
    border-radius: 10rpx 10rpx 0 0;
    font-size: 32rpx;
    color: #0390FF;
    height: 80rpx;
    line-height: 80rpx;
    padding-left: 30rpx;
    font-weight: bold;
  }


</style>
