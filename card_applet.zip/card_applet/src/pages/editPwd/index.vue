<template>
  <div class='wrap'>
    <div class='header'>验证手机号</div>
    <div class='tip'>修改密码时需验证您绑定的手机号</div>
    <div>
      <div class='label'>手机号</div>
      <div class='iptWrap flexBox'>
        <div class="flex1">
          <input type="number" maxlength="11" placeholder="请输入手机号" placeholder-style="color:#D9D9D9;font-size:32rpx" :value="phone" @input="Ipt"/>
        </div>
        <div :class="{'get-code':true,able:canGetCode && !interval}" @tap="getCode">{{codeMsg}}</div>
      </div>
      <div class='second'>
        <div class='label'>验证码</div>
        <div class='iptWrap flexBox'>
          <div class="flex1">
            <input type="number" maxlength="6" placeholder="请输入验证码" placeholder-style="color:#D9D9D9;font-size:32rpx" :value="code" @input="iptCode"/>
          </div>
        </div>
      </div>
    </div>
    <div :class="{'btn':true,unLogin:!(canGetCode && code.length == 6)}" @tap='edit'>确定</div>
  </div>
</template>

<script>
import net from '@/utils/net'
import tip from '@/utils/tip'
export default {
  data(){
    return {
      phone:"",
      code:"",
      interval:null,
      time:60,
      codeId:""
    }
  },
  computed: {
    canGetCode(){
      return this.phone.length == 11
    },
    codeMsg(){
      return this.interval ? `${this.time}秒后重新获取`:'获取验证码'
    },
  },
  methods:{
    Ipt(e){
      this.phone = e.mp.detail.value
    },
    // 获取code
    iptCode(e){
      this.code = e.mp.detail.value
    },
    // 验证码倒计时
    runTime(){
      this.interval = setInterval(()=>{
        this.time --;
        if(this.time == 0){
          this.time = 60;
          clearInterval(this.interval);
          this.interval = null;
          return;
        }
      },1000)
    },
    async getCode(){
      if(!this.canGetCode || this.interval){
        return;
      }
      var data = await net.put({
        url:'/memberMiniprogram/zone/send-code',
        data:{
          mobile:this.phone
        }
      })
      tip.loaded();
      this.codeId = data.codeId;
      this.runTime()
    },
    async edit(){
      if(!(this.canGetCode && this.code.length == 6)) return 
      tip.loading('验证中...')
      var result = await net.put({
        url:'/memberMiniprogram/zone/check-code',
        data:{
          code:this.code,
          codeId:this.codeId,
          mobile:this.phone,
        },
        showLoading:false
      })
      if(result){
        var phoneInfo = {code:this.code,codeId:this.codeId,mobile:this.phone}; // 下一步修改密码需要
        wx.redirectTo({
          url:'/pages/setPwd/main?info='+JSON.stringify(phoneInfo)
        })
      }
      else{
        tip.tip('验证失败')
      }
    },
  },
  onUnload(){
    this.phone = '';
    this.code = '';
    this.time = 60;
    clearInterval(this.interval);
    this.interval = null;
  }
}
</script>

<style scoped>
  .wrap{
    height: 100%;
    background: #fff;
    padding: 45rpx 40rpx 0;
    box-sizing: border-box;
    position: relative;
  }
  .header{
    font-size: 48rpx;
    color: #000000;
    margin-bottom:45rpx;
  }
  .tip{
    font-size: 26rpx;
    color: #999999;
    margin-bottom: 90rpx;
  }
  .label{
    font-size: 26rpx;
    color: #CCCCCC;
  }
  .iptWrap{
    margin-top: 20rpx;
    border-bottom: 1rpx solid  #E5E5E5;
  }
  .iptWrap input {
    display: block;
    box-sizing: border-box;
    width: 100%;
    height: 80rpx;
    font-size: 32rpx;
    line-height: 80rpx;
  }
  .get-code {
    font-size: 24rpx;
    color: #D9D9D9;
    text-align: right;
    min-width: 160rpx;
    line-height: 80rpx;
  }
  .second{
    margin-top: 45rpx;
  }
  .able {
    color: rgba(2, 103, 255, 0.50);
  }
  .btn {
    position: absolute;
    height: 80rpx;
    background: #0390FF;
    border-radius: 8rpx;
    width: 670rpx;
    text-align: center;
    left:50%;
    margin-left: -335rpx;
    bottom: 100rpx;
    font-size: 32rpx;
    color: #FFFFFF;
    line-height: 80rpx;
  }

  .btn.unLogin {
    background: #D9D9D9;
    color: #999999;
  }
</style>
