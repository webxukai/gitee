<template>
  <div class="main-cont" v-if="init">
    <div v-for="(item,index) in msgList" :key="index">
      <div class="gap"></div>
      <div class="cell-cont">
        <div class="cell flexBox">
          <div class="note" v-if="item.idRead == 0"></div>
          <div class="flex1">
            <div class="mes-title">{{item.title}}</div>
            <div class="mes-infor">{{item.content}}</div>
          </div>
        </div>
      </div>
    </div>
    <div class='nocon' v-if="!msgList.length">暂无消息通知</div>
  </div>
</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'

  export default {
    data() {
      return {
        init:false,
        msgList:[],
        query:{
          limit:10,
          page:1
        },
        end:false
      }
    },
    mixins: [base],
    methods: {
      // 获取消息
      async getMessage(more,noloading){
        var list = await net.post({
          url:'/memberMiniprogram/zone/new-messages',
          data:this.query,
          showLoading:!noloading
        })
        if(list.length < 10){
          this.end = true;
        }
        if(more){
          this.msgList = [...this.msgList,...list]
        }
        else{
          this.msgList = list;
        }
      }
    },
    async onLoad(){
      await this.getMessage()
      tip.loaded()
      this.init = true;
    },
    // 上拉加载
    async onReachBottom(){
      if(this.end)return;
      this.query.page ++;
      await this.getMessage(true)
      tip.loaded()
    },
    async onPullDownRefresh(){
      this.end = false;
      this.query.page = 1;
      await this.getMessage('',true);
      tip.loaded();
      wx.stopPullDownRefresh()
    },
    onUnload(){
      this.init = false;
      this.query.page = 1;
      this.end = false;
    }
  }

</script>

<style scoped>
  .nocon{
    font-size: 26rpx;
    color: #666666;
    text-align: center;
    padding-top: 40rpx;
  }
  .cell-cont {
    padding: 0 20rpx;
  }

  .cell {
    background-color: #FFF;
    min-height: 138rpx;
    box-sizing: border-box;
    padding-bottom: 25rpx
  }

  .note:after {
    display: block;
    content: ' ';
    width: 14rpx;
    height: 14rpx;
    border-radius: 50%;
    position: absolute;
    background-color: #FF3A31;
    left: 20rpx;
    top: 60rpx;
  }

  .note {
    width: 45rpx;
    position: relative;
  }

  .mes-title {
    font-size: 30rpx;
    color: #333333;
    line-height: 80rpx;
    padding-left: 20rpx;
  }

  .mes-infor {
    font-size: 26rpx;
    padding-left: 20rpx;
    color: #999999;
  }

</style>
