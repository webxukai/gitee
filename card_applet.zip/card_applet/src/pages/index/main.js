import Vue from 'vue'
import App from './index'

const app = new Vue(App)
app.$mount()    //手动挂在
export default {
  config: {
    navigationBarTitleText: '首页',
    enablePullDownRefresh:true,
    navigationBarBackgroundColor:'#FFF',
    navigationBarTextStyle:'black',
    backgroundTextStyle:"dark"
  }
}
