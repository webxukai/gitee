<template>
  <div :hidden="!init">
    <!--<img class="imgBG" src="/static/0.png" height="1602" width="750"/>-->

    <!--<div class="mainCont">-->

    <swiper class="top-bg" indicator-dots="true" :autoplay="pictures.length > 1" interval="5000" duration="1000">
      <block>
        <swiper-item v-for="(item,index) in pictures" :key="index">
          <img :src="imgUrl+''+item.picture" height="200" width="200"/>
        </swiper-item>
      </block>
    </swiper>
    <div class="public-cont flexBox">
      <div class="public-img">
        <img src="/static/public.png" height="200" width="200"/>
      </div>
      <swiper :autoplay="notices.length > 1" interval="5000" duration="1000" vertical="true" class="flex1" circular="true">
        <swiper-item class='item' v-for="(item,index) in notices"  :key="index" @tap="toNotice(item)">{{item.title}}</swiper-item>
        <div class='item' v-if="notices.length == 0">暂无最新公共</div>
      </swiper>
    </div>
    <div class="gap"></div>
    <div class="list-cont flexBox">
      <div class="flex1">
        <a href="/pages/paycode/main">
        <div>
          <img src="/static/FKM.png"/>
        </div>
        <div>付款码</div>
        </a>
      </div>
      <div class="flex1" @click="scan">
        <div>
          <img src="/static/SYS.png"/>
        </div>
        <div>扫一扫</div>
      </div>
      <div class="flex1" @tap="familyGroup">
        <a href="/pages/familyGroup/main">
          <div>
            <img src="/static/JTZ.png"/>
          </div>
          <div>家庭组</div>
        </a>
      </div>
    </div>

    <div class="shop-item-cont" @tap="toDetail(item)" v-for="(item,index) in meals" :key="index">
      <div class="gap"></div>
      <div class="shop-item">
        <div class="shop-name-cont flexBox">
          <div class="shop-owner-icon">
            <img src="/static/list1.png"/>
          </div>
          <div class='desc'>
            <div class="shop-owner-name">{{item.merchantName}}</div>
            <div class="shop-discont">{{item.properties}}</div>
          </div>
          <div class="flex1 shop-type">
            <span v-if="userKid == item.userKid">个人</span>
            <span v-else>家庭组-{{item.userName}}的卡</span>
          </div>
        </div>
        <div class="last-tip"> {{item.balance != null ? '剩余总金额 （元)' : '剩余积分'}}</div>
        <div class="last-money">{{item.balance != null ? item.sum : item.integral}}</div>
        <div class="integral shop-tip" v-if="item.balance != null  && item.integral != null">
          <p>积分: {{item.integral}}</p>
        </div>
        <div class="shop-tip" v-if="item.giveMoney!= null ">其中赠送金额{{item.giveMoney}}元 （{{item.giveMoneyTime == '2000-01-01 00:00:00' ? '永久有效' : item.giveMoneyTime+'到期'}}）</div>
      </div>
    </div>
    <div v-if="!meals.length" class='nocon'>暂无可用套餐</div>
    <!--</div>-->
    
  </div>

</template>

<script>
import card from "@/components/card";
import { mapGetters } from "vuex";
import net, { rootUrl, imgUrl } from "@/utils/net";
import tip from "@/utils/tip";
import { accAdd } from "@/utils";
import base from "@/mixins/base";
import moment from "moment";
import md5 from "_js-md5@0.7.3@js-md5";
export default {
  data() {
    return {
      pictures: [], // 轮播图列表
      notices: [], // 公告列表
      meals: [], //可用套餐列表
      rootUrl,
      imgUrl,
      userKid: "",
      init: false // 是否初始化完成
    };
  },
  mixins: [base],
  methods: {
    // 获取轮播图
    async getPictures() {
      var list = await net.get({
        url: "/memberMiniprogram/index/pictures",
        showLoading: false
      });
      this.pictures = list;
    },
    // 获取公告信息
    async getNotices() {
      var notices = await net.get({
        url: "/memberMiniprogram/index/notices",
        showLoading: false
      });
      this.notices = notices;
    },
    // 获取用户可享用套餐
    async getMeals() {
      var meals = await net.get({
        url: "/memberMiniprogram/index/set-meals",
        showLoading: false
      });
      meals.forEach(item => {
        item.giveMoneyTime = moment(item.giveMoneyTime).format(
          "YYYY-MM-DD HH:mm:ss"
        );
        if (item.balance != null) {
          item.sum = accAdd(item.balance, item.giveMoney || 0);
        }
      });
      this.meals = meals;
    },
    toDetail(info) {
      wx.navigateTo({
        url: "/pages/cardInfo/main?info=" + JSON.stringify(info)
      });
    },
    toNotice(item) {
      wx.navigateTo({
        url: "/pages/noticeInfo/main?info=" + JSON.stringify(item)
      });
    },
    scan() {
      wx.scanCode({
        success: async res => {}
      });
    }
  },
  async onLoad() {
    this.userKid = getApp().globalData.userKid;
    tip.loading();
    Promise.all([this.getNotices(), this.getPictures(), this.getMeals()]).then(
      () => {
        this.init = true;
        tip.loaded();
      }
    );
  },
  async onPullDownRefresh() {
    Promise.all([this.getNotices(), this.getPictures(), this.getMeals()]).then(
      () => {
        wx.stopPullDownRefresh();
      }
    );
  },
  async onShow() {
    await this.getMeals();
  }
};
</script>

<style scoped>
.shop-item-cont {
  padding: 0 20rpx;
}
.nocon {
  font-size: 26rpx;
  color: #666666;
  text-align: center;
  padding-top: 40rpx;
}
.shop-item {
  background-color: #fff;
  padding-bottom: 20rpx;
  text-align: center;
  position: relative;
}

.shop-name-cont {
}
.desc {
  margin-top: 14rpx;
  height: 30rpx;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.shop-owner-icon {
  text-align: right;
  height: 80rpx;
  width: 80rpx;
  padding-right: 10rpx;
}

.shop-owner-icon img {
  width: 60rpx;
  height: 60rpx;
  border-radius: 50%;
  overflow: hidden;
  margin-top: 14rpx;
}

.shop-owner-name {
  font-size: 26rpx;
  color: #333333;
  text-align: left;
}

.shop-discont {
  font-size: 18rpx;
  color: #999999;
  text-align: left;
}

.shop-type {
  text-align: right;
}
.shop-type.integral {
  font-size: 18rpx;
  color: #999999;
}
.shop-type span {
  font-size: 18rpx;
  color: #ffffff;
  background-image: linear-gradient(-141deg, #fd9381 3%, #fd5d55 100%);
  padding: 0rpx 6rpx;
  border-radius: 4rpx;
  margin: 0 20rpx;
  line-height: 100rpx;
}
.shop-type .kid {
  color: #999;
  font-size: 18rpx;
  background: transparent;
  margin: 0;
}
.last-tip {
  font-size: 24rpx;
  color: #999999;
  line-height: 55rpx;
}

.last-money {
  font-size: 60rpx;
  font-weight: bold;
  color: #333333;
}

.shop-tip {
  font-size: 22rpx;
  color: #bfbfbf;
}

.list-cont img {
  width: 100rpx;
  height: 100rpx;
  margin-top: 18rpx;
}

.list-cont {
  height: 186rpx;
  background-color: #fff;
  text-align: center;
  font-size: 26rpx;
  color: #333333;
  line-height: 40rpx;
}

.public-cont {
  height: 80rpx;
  line-height: 80rpx;
  font-size: 26rpx;
  color: rgba(0, 0, 0, 0.7);
  background-color: #fff;
}
.public-cont .flex1 {
  height: 80rpx;
}
.public-img {
  width: 95rpx;
}

.public-img img {
  height: 40rpx;
  width: 40rpx;
  margin: 20rpx 0 0 30rpx;
}

.top-bg {
  height: 280rpx;
  width: 100%;
}

.top-bg img {
  height: 100%;
  width: 100%;
}

.userinfo {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.userinfo-avatar {
  width: 128rpx;
  height: 128rpx;
  margin: 20rpx;
  border-radius: 50%;
}

.userinfo-nickname {
  color: #aaa;
}

.usermotto {
  margin-top: 150px;
}

.form-control {
  display: block;
  padding: 0 12px;
  margin-bottom: 5px;
  border: 1px solid #ccc;
}

.counter {
  display: inline-block;
  margin: 10px auto;
  padding: 5px 10px;
  color: blue;
  border: 1px solid blue;
}

.active {
  color: red;
}
</style>
