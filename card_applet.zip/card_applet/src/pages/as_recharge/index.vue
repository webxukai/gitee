<template>
  <div class="counter-warp">
    <div class="as-title">{{info.merchantName}}</div>
    <div class="as-money">+{{info.money}}</div>
    <div class="as-money-info" v-if="info.giveMoney!=null">+{{info.giveMoney}}赠送金额</div>
    <ul class="as-information">
      <li>卡号<span>{{info.userSetMealKid}}</span></li>
      <li>订单号<span>{{info.kid}}</span></li>
      <li>充值时间<span>{{info.createTime}}</span></li>
      <li class='zk'>折扣率
        <span class="as-span">
          <div v-for="(item,index) in discount" :key="index">
            <i class="as-icon"></i>
            <div class='label'>{{ index == discount.length - 1 ? '当前折扣率' :'折扣率'}} {{item}}</div>
            <i class="as-solid" v-if="index != 0"></i>
          </div>
        </span>
      </li>
      <li>特价
        <span class="as-span">
          <div v-for="(item,index) in specialOffer" :key="index">
            <i class="as-icon"></i>
            <div class='label'>类型 {{item}}</div>
            <i class="as-solid" v-if="index != 0"></i>
          </div>
        </span>
      </li>
    </ul>
  </div>
</template>

<script>

export default {
  data(){
    return {
      info:null,
      userKid:'',
      discount:[],//折扣
      specialOffer:[]// 特价
    }
  },
  methods: {
  },
  onLoad(){
    this.info = JSON.parse(this.$root.$mp.query.info)
    var discount = this.info.discount.split(',');
    this.discount = discount.map((item)=>{
      if(item == 'null'){
        return '100%'
      }
      else{
        return Number(item) * 100 + '%'
      }
    })
    var specialOffer = this.info.specialOffer.split(',')
    this.specialOffer = specialOffer.map((item)=>{
      if(item == 'null'){
        return '无'
      }
      return item
    })
    this.userKid = getApp().globalData.userKid
  }
}

</script>
<style>
  .counter-warp{
    height: 100%;
    flex-direction: column;
    background: #fff;
  }
  .as-title{
    text-align: center;
    font-size: 30rpx;
    padding-top: 45rpx;
    color:#333;
  }
  .as-money{
    text-align: center;
    font-size: 60rpx;
    margin-top:30rpx;
    font-weight: bolder;
    color:#333;
  }
  .as-money-info{
    text-align: center;
    font-size: 22rpx;
    margin-top:15rpx;
    color: #FF9800;
  }
  .as-information{
    margin-top: 50rpx;
    font-size: 28rpx;
  }
  .as-information li{
    list-style: none;
    color: #333;
    text-align: left;
    padding: 20rpx 20rpx;
    overflow: hidden;
  }
  .as-information .zk{
    padding-top: 40rpx;
  }
  .as-information li span{
    display: inline-block;
    float: right;
    text-align: right;
    color: #666;
  }
  .as-span{
    display: inline-block;
    width: 250rpx;
    text-align: left!important;
  }
  .as-span > div{
    width: 100%;
    display: flex;
    padding-top: 70rpx;
    position: relative;
  }
  .as-span > div:first-child{
    padding-top: 0rpx;
  }
  .as-span > div:last-child{
    color: #0390FF;
  }
  .as-span > div:last-child .as-solid{
    border-color: #0390FF;
  }
  .as-span > div:last-child .as-icon{
    border-color: #0390FF
  }
/*  .as-span b{
    display: block;
    color: #0390FF;
    padding-top: 70rpx;
    position: relative;
  }*/
  .as-icon{
    width: 30rpx;
    height: 30rpx;
    display: inline-block;
    border: 6rpx solid #999999;
    border-radius: 50%;
    position: relative;
    left:-15rpx;
    box-sizing: border-box;
  }
  .as-span .label{
    flex:1;
    overflow: hidden;
    line-height: 1;
  }
  .as-solid{
    width:4rpx;
    height:72rpx;
    display:inline-block;
    border:0rpx solid #999999;
    position:absolute;
    left:-2rpx;
    top:-1rpx;
    background:#999;
  }
</style>
