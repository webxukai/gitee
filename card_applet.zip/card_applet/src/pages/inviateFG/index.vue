<template>

  <div>
      <div class="gap"></div>
      <div class="search-cont">
        <input type="number" placeholder="搜索手机号邀请成员" maxlength="11" @input="getPhone"/>
      </div>
      <div :class="{'prime-btn':true,uneditable:phone.length != 11}" @tap="inviate">确定邀请</div>
  </div>



</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'

  export default {
    data() {
      return {
        phone:"",
        userKid:""
      }
    },
    mixins: [base],
    methods: {
      getPhone(e){
        this.phone = e.mp.detail.value;
      },
      async inviate(){
        if(this.phone.length != 11 )return
        var result = await net.post({
          url:'/memberMiniprogram/family/inviteMember',
          data:{
            phone:this.phone,
            userKid:this.userKid
          }
        })
        tip.loaded()
        if(result.state == 1){
          getApp().globalData.Group_refalsh = true;
          getApp().globalData.Meals_refalsh = true;
          getApp().globalData.Card_refalsh = true;
          wx.navigateBack()
        }
      }
    },
    onLoad(){
      this.userKid  =  getApp().globalData.userKid;
    }
  }

</script>

<style scoped>

  .prime-btn {
    margin: 80rpx auto;
  }
  .prime-btn.uneditable {
    background: #D9D9D9;
    color: #999999;
  }
  .search-cont {
    background-color: #FFF;
    height: 88rpx;
    line-height: 88rpx;
    font-size: 30rpx;
    color: #999999;
  }

  .search-cont input {
    background-color: #FFF;
    box-sizing: border-box;
    height: 88rpx;
    padding: 0 25rpx;
    color: #666;
  }

  .check-cont {
    width: 50rpx;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .checkbox{
    margin-top: -10rpx;
  }
  .member-tel {
    font-size: 20rpx;
    color: #999999;
  }

  .member-name {
    font-size: 30rpx;
    color: #333333;
    margin-top: 25rpx;
  }

  .head-cont img {
    border-radius: 50%;
    height: 72rpx;
    width: 72rpx;
    margin: 25rpx 0;
    overflow: hidden;
  }

  .head-cont {
    width: 90rpx;
  }


  .cell-cont {
    padding: 0 20rpx;
    background-color: #FFF;
  }

  .cell {
    height: 120rpx;
    border-bottom: 1rpx solid #DBDBDB;
  }

</style>
