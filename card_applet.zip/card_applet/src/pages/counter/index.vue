<template>
  <div class="counter-warp">
    <p>Vuex counter：{{ count }}</p>
    <p>
      <button @click="increment">异步+</button>
      <button @click="decrement">-</button>
    </p>
  </div>
</template>

<script>
// Use Vuex
import store from '@/store'
import { mapActions } from 'vuex'

export default {
  computed: {
    count () {
      return store.state.bus.count
    }
  },
  methods: {
    async increment () {
      await this.asyncAdd();
      console.log('完成')
    },
    decrement () {
      store.commit('decrement')
    },
    ...mapActions({
      asyncAdd:'asyncAdd'
    })
  }
}

</script>
<style>
.counter-warp {
  text-align: center;
  margin-top: 100px;
}
.home {
  display: inline-block;
  margin: 100px auto;
  padding: 5px 10px;
  color: blue;
  border: 1px solid blue;
}

</style>
