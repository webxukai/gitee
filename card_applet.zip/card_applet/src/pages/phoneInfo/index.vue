<template>
  <div class='wrap'>
    <div class='header'>修改手机号</div>
    <div class='tip'>您当前手机号为{{userInfo.phone}}</div>
    <div class='tip'>修改后，您当前账号所有资料、资产不变</div>
    <a :class="{'btn':true}" href="/pages/editPhone/main">立即修改</a>
  </div>
</template>

<script>
import { formatPhone } from '@/utils'
export default {
  data(){
    return {
     userInfo:null
    }
  },
  onLoad(){
    this.userInfo = Object.assign({},getApp().globalData.userInfo);
    this.userInfo.phone = formatPhone(this.userInfo.phone)
  },
}
</script>

<style scoped>
  .wrap{
    height: 100%;
    background: #fff;
    padding: 45rpx 40rpx 0;
    box-sizing: border-box;
    position: relative;
  }
  .header{
    font-size: 48rpx;
    color: #000000;
    margin-bottom:45rpx;
  }
  .tip{
    font-size: 26rpx;
    color: #999999;
    margin-bottom: 28rpx;
  }
  .label{
    font-size: 26rpx;
    color: #CCCCCC;
  }
  .btn {
    position: absolute;
    height: 80rpx;
    background: #0390FF;
    border-radius: 8rpx;
    width: 670rpx;
    text-align: center;
    left:50%;
    margin-left: -335rpx;
    bottom: 100rpx;
    font-size: 32rpx;
    color: #FFFFFF;
    line-height: 80rpx;
  }

  .btn.unLogin {
    background: #D9D9D9;
    color: #999999;
  }
</style>
