<template>
	<div class='wrap' v-if="init">
		<div class='list'>
			<div class='header flexBox'>
				<div class='flex1 label'>免密设置</div>
				 <switch :checked='check' class='switch' @change="changeStatus"/>
			</div>
			<div class='tip'>当前为{{checked ? '开启状态，支付时无需输入支付密码':'关闭状态，支付时需输入支付密码'}}</div>
		</div>
		<payInput ref='pay' @close="hide" @end="payFree"/>
	</div>
</template>


<script>
import payInput from '@/components/payInput'
import net from '@/utils/net'
import tip from '@/utils/tip'
export default{
	data(){
		return {
			init:false,
			hasPayPwd:false,
			checked:false, // 当前状态
			check:false // switch开关
		}
	},
	components:{
		payInput
	},
	methods:{
		changeStatus(e){
			this.check = e.mp.detail.value;
			if(!this.hasPayPwd){
				tip.tip('请先设置支付密码')
				setTimeout(()=>{
					wx.navigateTo({
						url:'/pages/setPwd/main?'
					})
				},1000)
				this.check = this.checked;
				return;
			}
			this.$refs.pay.show()
		},
		hide(){
			this.check = this.checked
		},
		async getStatus(){
	      var data = await net.get({
	        url:"/memberMiniprogram/zone/user/pay-free"
		  })
      	  this.check = this.checked = !!data.state;
      	  this.hasPayPwd = data.hasPayPwd
      	  this.init = true
    	},
    	// 切换免密
    	async payFree(payPwd){
    		try{
	    		var result = await net.put({
	    			url:'/memberMiniprogram/zone/user/pay-free',
	    			data:{
	    				free:this.check ? 1 : 0,
	    				payPwd
	    			},
	    			title:"设置中..."
				})
	    		tip.loaded();
	    		if(result.state == 2){
	    			this.checked = this.check;
					this.$refs.pay.hide();
					tip.tip('设置成功',false)
	    		}
	    		else{
	    			this.check = this.checked;
	    			this.$refs.pay.hide();
					tip.tip('密码输入不正确',false)
					setTimeout(()=>{
						this.$refs.pay.show()
					},1000)
	    		}
    		}catch(e){
    			this.check = this.checked;
    			this.$refs.pay.hide();
    		}
    	}
	},
	async onLoad(){
		await this.getStatus()
		tip.loaded()
	},
	onUnload(){
		this.init = false;
	}
}


</script>

<style scoped>
	.wrap{
		padding-top: 20rpx;
	}
	.list{
		height: 152rpx;
		background: #fff;
		padding:0 23rpx;
	}
	.header{
		padding-top: 12rpx;
	}
	.switch{
		width: 102rpx;
		height: 62rpx;
	}
	.label{
		font-size: 28rpx;
		color: #333333;
		padding-top: 17rpx;
	}
	.tip{
		margin-top: 26rpx;
		font-size: 24rpx;
		color: #999999;
	}
</style>