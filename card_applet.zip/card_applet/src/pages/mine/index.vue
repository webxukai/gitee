<template>
  <div class="main-cont">
    <div class="icon-cont">
      <a href="/pages/myinfor/main">
        <div>
          <img :src="userInfo.avatarUrl"/>
        </div>
        <div class="user-name">
          <span>{{userInfo.nickName}}</span>
          <img src="/static/edit.png"/>
        </div>
        <div class="user-number">{{userInfo.phone}}</div>
      </a>
    </div>
    <div class="cell-cont">
      <a href="/pages/message/main">
        <div class="cell flexBox">
          <div class="cell-icon">
            <img src="/static/msg.png"/>
          </div>
          <div class="cell-name">消息通知</div>
          <div class="flex1"></div>
          <div class="link-cont">
            <div class="note" :hidden="count == 0">{{count}}</div>
          </div>
        </div>
      </a>
    </div>
    <div class="cell-cont">
      <a href="/pages/feedback/main">
        <div class="cell flexBox">
          <div class="cell-icon">
            <img src="/static/advice.png"/>
          </div>
          <div class="cell-name">意见反馈</div>
          <div class="flex1"></div>
          <div class="link-cont">
          </div>
        </div>
      </a>
    </div>
    <div class="cell-cont">
      <a href="/pages/mycard/main">
        <div class="cell flexBox">
        <div class="cell-icon">
          <img src="/static/card.png"/>
        </div>
        <div class="cell-name">我的实体卡</div>
        <div class="flex1"></div>
        <div class="link-cont">
        </div>
      </div>
      </a>
    </div>
    <div class="cell-cont">
      <a href="/pages/payConfig/main">
        <div class="cell flexBox">
        <div class="cell-icon">
          <img src="/static/money.png"/>
        </div>
        <div class="cell-name">支付设置</div>
        <div class="flex1"></div>
        <div class="link-cont">
        </div>
      </div>
      </a>
    </div>
  </div>


</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'
  import { formatPhone } from '@/utils'
  export default {
    data() {
      return {
        userInfo:null,
        count:0
      }
    },
    mixins: [base],
    methods: {
      async getMsgCount(){
        var data = await net.post({
          url:'/memberMiniprogram/zone/isHaveMessage',
          showLoading:false
        })
        this.count = data.count
      }
    },
    onLoad(){
      this.userInfo = Object.assign({},getApp().globalData.userInfo);
      this.userInfo.phone = formatPhone(this.userInfo.phone)
    },
    async onShow(){
      if(getApp().globalData.userInfo_refalsh){
        this.userInfo = Object.assign({},getApp().globalData.userInfo);
        this.userInfo.phone = formatPhone(this.userInfo.phone)
        getApp().globalData.userInfo_refalsh = false;
      }
      await this.getMsgCount()
    }
  }

</script>

<style scoped>

  .note {
    width: 34rpx;
    height: 34rpx;
    border-radius: 50%;
    background-color: rgb(253, 133, 125);
    margin-top: 30rpx;
    margin-right: 40rpx;
    font-size: 20rpx;
    color: #ffffff;
    text-align: center;
    line-height: 34rpx;
  }

  .link-cont::after {
    position: absolute;
    display: block;
    content: ' ';
    border-style: solid;
    border-color: #999;
    border-width: 0 1rpx 1rpx 0;
    height: 15rpx;
    width: 15rpx;
    transform: rotate(-45deg);
    left: 20rpx;
    top: 50rpx;
  }

  .link-cont {
    position: relative;
    width: 55rpx;
  }

  .cell-name {
    font-size: 30rpx;
    color: #333333;
  }

  .cell-icon img {
    width: 40rpx;
    height: 40rpx;
    margin: 38rpx 20rpx 0 8rpx;
  }

  .cell-icon {

  }

  .cell {
    border-bottom: 1rpx solid #DBDBDB;
    height: 120rpx;
    line-height: 115rpx;
  }

  .cell-cont {
    padding: 0 20rpx;
    background-color: #FFF;
  }

  .user-number {
    font-size: 24rpx;
    color: #999999;
  }

  .main-cont {
    height: 100%;
    background-color: #FFF;
  }

  .icon-cont {
    padding-top: 60rpx;
    text-align: center;
    height: 290rpx;
  }

  .icon-cont img {
    height: 140rpx;
    width: 140rpx;
    border-radius: 50%;
    overflow: hidden;
  }
  .user-name span{
    margin-left: 40rpx;
  }
  .user-name img {
    width: 30rpx;
    height: 30rpx;
    margin-left: 15rpx;
    vertical-align: middle;
  }

  .user-name {
    font-size: 32rpx;
    font-weight: bold;
    color: #333333;
    line-height: 60rpx;
  }

</style>
