<template>

  <div>
      <div class="addGoup">
        <div class="group-name">
          <input type="text" placeholder="填写群名称 （2-7个字）" @input="getGroupName" :value="groupName" maxlength="7" />
        </div>
        <div :class="{'add-group-conf':true,editable:groupName.length >= 2}" @tap='create'>确认</div>
      </div>
  </div>

</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'

  export default {
    data() {
      return {
       groupName:"",
       userKid:""
      }
    },
    mixins: [base],
    methods: {
      getGroupName(e){
        this.groupName = e.mp.detail.value;
      },
      async create(){
        if(this.groupName.length < 2)return;
        var result = await net.post({
          url:'/memberMiniprogram/family/createFamilyGroup',
          data:{
            "familyGroupName": this.groupName,
            "userKid": this.userKid
          }
        })
        tip.loaded();
        if(result.state == 1){
          tip.tip('创建成功')
          getApp().globalData.Group_refalsh = true;
          wx.navigateBack()
        }
        else{
          tip.tip('创建失败')
        }
      }
    },
    onLoad(){
      this.userKid = getApp().globalData.userKid;
    },
    onUnload(){
      this.groupName = ''
    }
  }

</script>

<style scoped>

  .addGoup {
    height: 100%;
    text-align: center;
    background-color: #FFF;;
  }

  .group-name {
    text-align: center;
    font-size: 30rpx;
    color: #666666;
    width: 570rpx;
    margin: 0 auto;
    padding-top: 270rpx;
    border-bottom: 1rpx solid #E5E5E5;
    height: 70rpx;
    line-height: 70rpx;
  }

  .add-group-conf {
    background: #D9D9D9;
    border-radius: 8rpx;
    font-size: 32rpx;
    color: #999999;
    width: 670rpx;
    height: 80rpx;
    line-height: 80rpx;
    text-align: center;
    margin: 460rpx auto 0 auto;
  }

  .editable {
    color: #FFF;
    background: #0390FF;
  }


</style>
