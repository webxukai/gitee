<template>

  <div>

    <div class="tip">卡号</div>

    <div class="cardinput">
      <input type="text" placeholder="请输入卡号"/>
    </div>

    <div class="prime-btn">确定绑定</div>

    <div class="dange-btn">解除绑定</div>

  </div>

</template>

<script>
  // Use Vuex
  import store from '@/store'
  import {mapActions} from 'vuex'

  export default {
    computed: {
      count() {
        return store.state.bus.count
      }
    },
    methods: {
      async increment() {
        await this.asyncAdd();
      },
      decrement() {
        store.commit('decrement')
      },
      ...mapActions({
        asyncAdd: 'asyncAdd'
      })
    }
  }

</script>
<style>

  .prime-btn, .dange-btn {
    margin: 50rpx auto;
  }

  .tip {
    font-size: 24rpx;
    color: #777777;
    height: 55rpx;
    line-height: 55rpx;
    padding: 0 20rpx;
  }

  .cardinput {
    background-color: #FFF;
    height: 88rpx;
    line-height: 88rpx;
    font-size: 30rpx;
    color: #333333;
  }

  .cardinput input {
    box-sizing: border-box;
    height: 88rpx;
    padding: 0 20rpx;
  }

</style>
