<template>
  <div class="counter-warp">
    <div class='top'>
      <div class='store'>{{info.merchantName}}</div>
      <div class='money'>-{{info.money}}</div>
      <div class='tip' v-if="info.giveMoney!=null">-{{info.giveMoney}}为赠送金额</div>
    </div>
    <div class='info'>
      <div class='list'>
        <div class='label'>消费人</div>
        <div class='val'>{{info.operatorUserKid == userKid ? '个人':info.operatorUserName}}</div>
      </div>
      <div class='list'>
        <div class='label'>卡号</div>
        <div class='val'>{{info.userSetMealKid}}</div>
      </div>
      <div class='list'>
        <div class='label'>订单号</div>
        <div class='val'>{{info.kid}}</div>
      </div>
      <div class='list'>
        <div class='label'>消费时间</div>
        <div class='val'>{{info.createTime}}</div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  data(){
    return {
      info:null,
      userKid:''
    }
  },
  methods: {
  },
  onLoad(){
    this.info = JSON.parse(this.$root.$mp.query.info)
    this.userKid = getApp().globalData.userKid
  }
}

</script>
<style scoped>
.counter-warp{
  height: 100%;
  background: #fff;
}
.top{
  padding-top: 45rpx;
  text-align: center;
}
.top .store{
  font-size: 30rpx;
  color: #333333;
  margin-bottom: 35rpx;
}
.top .money{
  color: #333333;
  font-size: 60rpx;
  font-weight: bold;
  margin-bottom: 20rpx;
}
.top .tip{
  font-size: 22rpx;
  color: #ff9800;
}
.info{
  padding: 0 20rpx;
  margin-top: 70rpx;
}
.list{
  display: flex;
  margin-bottom: 40rpx;
}
.label{
  font-size: 28rpx;
  color: #666666;
}
.val{
  flex:1;
  font-size: 28rpx;
  color: #333333;
  text-align: right;
}
</style>
