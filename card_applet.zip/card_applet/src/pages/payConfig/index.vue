<template>
  <div class="main-cont">
    <div class="cell-cont">
      <a href="/pages/noPwd/main">
        <div class="cell flexBox">
        <div class="cell-name">免密设置</div>
        <div class="flex1"></div>
        <div class="link-cont">
        </div>
      </div>
      </a>
    </div>
    <div class="cell-cont">
      <a href="/pages/editPwd/main">
        <div class="cell flexBox">
        <div class="cell-name">修改支付密码</div>
        <div class="flex1"></div>
        <div class="link-cont">
        </div>
      </div>
      </a>
    </div>
  </div>


</template>

<script>

  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'
  export default {
    data() {
      return {
        userInfo:null,
        count:0
      }
    }
  }

</script>

<style scoped>

  .link-cont::after {
    position: absolute;
    display: block;
    content: ' ';
    border-style: solid;
    border-color: #999;
    border-width: 0 1rpx 1rpx 0;
    height: 15rpx;
    width: 15rpx;
    transform: rotate(-45deg);
    left: 20rpx;
    top: 50rpx;
  }

  .link-cont {
    position: relative;
    width: 55rpx;
  }

  .cell-name {
    font-size: 30rpx;
    color: #333333;
  }

  .cell-icon img {
    width: 40rpx;
    height: 40rpx;
    margin: 38rpx 20rpx 0 8rpx;
  }

  .cell-icon {

  }

  .cell {
    border-bottom: 1rpx solid #DBDBDB;
    height: 120rpx;
    line-height: 115rpx;
  }

  .cell-cont {
    padding: 0 20rpx;
    background-color: #FFF;
  }
  .cell-cont:last-child .cell{
    border:none;
  }

  .main-cont {
    height: 100%;
  }


</style>
