<template>
  <div class='wrap'>
    <payInput ref='six'/>
  </div>
</template>

<script>
import payInput from '@/components/payInput'

import six from '@/components/six'
import { formatTime } from '@/utils/index'
import { mapGetters } from 'vuex'
import card from '@/components/card'
import base from '@/mixins/base'

export default {
  components: {
    card,
    payInput,
    six
  },
  data () {
    return {
      logs: []
    }
  },
  methods:{
    getValue(value){
      console.log(value)
    },
    dele(){
      this.$refs.six.empty()
    }
  },
  mounted(){
    console.log(this.$refs.six.show())
  }
}
</script>

<style>

.log-item {
  margin: 10rpx;
}
</style>
