<template>

  <div v-if="init" class='wrap'>
    <div class="unenter" v-if="groupInfo.state == 0">
      <div class="unenter-img">
        <img src="/static/unenter.png"/>
      </div>
      <div class="unenter-tip">您尚未加入任何家庭组</div>
      <div class="create-FG" @tap="add">创建家庭组</div>
    </div>
    <scroll-view class="member-cont" v-else scroll-y>
      <div class="member-list">
        <div class="men-type">管理员</div>
        <div v-for="(item,index) in adminList" :key="index">
          <div class="menber flexBox">
            <div class="mmen-icon">
              <img :src="item.picture"/>
            </div>
            <div class="flex1">
              <div class="mem-name"><span>{{item.name}}</span><span class='label'>管理</span></div>
              <div class="men-tel">{{item._phone}}</div>
            </div>
            <div class="but-cont" v-if="item.userKid == userKid">
              我
            </div>
          </div>
          <div class="gap-line" v-if="index != adminList.length - 1"></div>
        </div>
        <div class="men-type">组员</div>
        <div v-for="(item,index) in userList" :key="index">
          <div class="menber flexBox">
            <div class="mmen-icon">
              <img :src="item.picture"/>
            </div>
            <div class="flex1">
              <div class="mem-name">{{item.name}}</div>
              <div class="men-tel">{{item._phone}}</div>
            </div>
            <div class="but-cont">
              <div class="remove-bt" @tap='dele(item)' v-if="admin">移除</div>
            </div>
          </div>
          <div class="gap-line" v-if="index != userList.length - 1"></div>
        </div>
        <div class='nocon' v-if="!userList.length">暂无组员</div>
      </div>
      <div class="inviate-bt prime-btn" @tap="inviate">邀请组成员</div>
      <div class="bottom-bt flexBox">
        <div class="flex1">
          <div class="signout" @tap="signout">退出家庭组</div>
        </div>
        <div class="flex1">
          <div class="dissolution" @tap='dissolve' v-if="admin">解散家庭组</div>
        </div>
      </div>
    </scroll-view>
  </div>

</template>

<script>

  import card from '@/components/card'
  import {mapGetters} from 'vuex'
  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'
  import { formatPhone } from '@/utils'

  export default {
    data() {
      return {
        init: false,
        userKid:"",
        admin:false,
        groupInfo:null,
        adminList:[],// 管理员
        userList:[] // 成员
      }
    },
    mixins: [base],
    methods: {
      // 退出家庭组
      async signout(){
        wx.showModal({
          title: '退出群组',
          content: '确定要退出群组吗?',
          success:async (res)=> {
            if (res.confirm) {
              var isAdmin = this.adminList.some((item)=>{
                return item.userKid == this.userKid
              })
              if(isAdmin && this.userList.length){
                wx.navigateTo({
                  url:'/pages/signOutFG/main?userList='+JSON.stringify(this.userList)
                })
              }
              else{
                var result = await net.post({
                  url:'/memberMiniprogram/family/outFamilyGroup',
                  data:{
                    userKid:this.userKid
                  }
                })
                if(result.state == 1){
                  tip.tip('退出成功')
                  getApp().globalData.Meals_refalsh = true;
                  getApp().globalData.Card_refalsh = true;
                  wx.navigateBack();
                }
                else{
                  tip.tip('退出失败')
                }
              }
            }
          }
        })
      },
      // 邀请
      inviate(){
        if(this.groupInfo.invite == 0){
          tip.tip('不能邀请群成员')
          return ;
        }
        wx.navigateTo({
          url:'/pages/inviateFG/main'
        })
      },
      // 添加群组
      add(){
        wx.navigateTo({
          url:'/pages/addFamilyGroup/main'
        })
      },
      // 获取群组信息
      async getGroupUserList(){
        var groupInfo = await net.post({
          url:'/memberMiniprogram/family/queryFamilyGroupUserList',
          data:{
            userKid:this.userKid
          }
        })
        tip.loaded();
        this.groupInfo = groupInfo;
        if(groupInfo.familyGroupUserList){
          this.adminList = groupInfo.familyGroupUserList.filter((item)=>{
            if(item.type == 0 && item.userKid == this.userKid){
              this.admin = true;
            }
            item._phone = formatPhone(item.phone)
            return item.type == 0
          })
          this.userList = groupInfo.familyGroupUserList.filter((item)=>{
            return item.type == 1
          })
        }
        wx.setNavigationBarTitle({
          title: groupInfo.name || '家庭组'
        })
      },
      // 移除用户
      async dele(info){
        wx.showModal({
          title: '移除成员',
          content: '确定要移除该成员吗?',
          success:async (res)=> {
            if(res.confirm){
              var result = await net.post({
                url:'/memberMiniprogram/family/delUserFromFamilyGroup',
                data:{
                  userKid:this.userKid,
                  anotherUserKid:info.userKid
                }
              })
              if(result.state == 1){
                tip.tip('移除成功')
                this.getGroupUserList();
                getApp().globalData.Meals_refalsh = true;
                getApp().globalData.Card_refalsh = true;
              }
              else{
                tip.tip('移除失败')
              }
            }
          }
        })
      },
      //解散
      async dissolve(){
        wx.showModal({
          title: '解散群组',
          content: '确定要解散群组吗?',
          success:async (res)=> {
            if (res.confirm) {
              var result =  await net.post({
                url:'/memberMiniprogram/family/delFamilyGroup',
                data:{
                  userKid:this.userKid
                }
              })
              if(result.state == 1){
                tip.tip('解散成功')
                getApp().globalData.Meals_refalsh = true;
                getApp().globalData.Card_refalsh = true;
                wx.navigateBack();
              }
              else{
                tip.tip('解散失败');
              }
            }
          }
        })
      }
    },
    async onLoad(){
      this.userKid = getApp().globalData.userKid;
      await this.getGroupUserList()
      this.init = true;
    },

    // 是否刷新一遍家庭组列表(当创建、邀请新成员返回该页面时需要刷新)
    async onShow(){
      if(getApp().globalData.Group_refalsh){
        await this.getGroupUserList();
        getApp().globalData.Group_refalsh = false;
      }
    },
    onUnload(){
      this.init = false;
    }
  }

</script>

<style scoped>
  .wrap{
    height: 100%;
  }
  .nocon{
    font-size: 26rpx;
    color: #666666;
    text-align: center;
    padding-top: 40rpx;
  }
  .men-tel {
    font-size: 20rpx;
    color: #999999;
    margin-top: 10rpx;
  }

  .menber {
    background-color: #FFF;
    height:120rpx;
  }

  .dissolution {
    background: #FF3A31;
    border-radius: 8rpx;
    width: 345rpx;
    height: 70rpx;
    line-height: 70rpx;
    margin: 15rpx auto;
    text-align: center;
    font-size: 32rpx;
    color: #FFF;
  }

  .signout {
    border: 1px solid #FF3A31;
    border-radius: 8rpx;
    width: 345rpx;
    height: 70rpx;
    line-height: 70rpx;
    margin: 15rpx auto;
    text-align: center;
    font-size: 32rpx;
    color: #FF3A31;
    box-sizing: border-box;
  }

  .bottom-bt {
    position: fixed;
    bottom: 0;
    left: 0;
    height: 100rpx;
    width: 100%;
    background-color: #FFF;
    border-top:1rpx solid #E5E5E5;
  }

  .inviate-bt {
    margin: 40rpx auto 40rpx auto;
  }
  .remove-bt {
    font-size: 24rpx;
    color: #999999;
    text-align: center;
    line-height: 48rpx;
    width: 100rpx;
    height: 48rpx;
    border: 1rpx solid #979797;
    border-radius: 8rpx;
    margin-top: 35rpx;
  }

  .gap-line {
    height: 1rpx;
    width: 730rpx;
    margin-left: 20rpx;
    background-color: #E5E5E5;
  }

  .but-cont {
    padding-right: 40rpx;
    line-height: 125rpx;
    font-size: 20rpx;
    color: #999999;
  }
  .mem-name span{
    display: inline-block;
    vertical-align: middle;
  }
  .mem-name .label {
    background-image: linear-gradient(-180deg, #FFE300 0%, #FFB900 97%);
    border-radius: 4rpx;
    font-size: 18rpx;
    padding: 0 5rpx;
    color: #FFFFFF;
     margin-left: 15rpx;
  }

  .mem-name {
    font-size: 30rpx;
    color: #333333;
    margin-top: 20rpx;
  }

  .mmen-icon {
    width: 110rpx;
  }

  .mmen-icon img {
    width: 75rpx;
    height: 75rpx;
    border-radius: 50%;
    margin: 24rpx 0 0 20rpx;
  }

  .men-type {
    font-size: 24rpx;
    color: #777777;
    height: 50rpx;
    line-height: 50rpx;
    padding-left: 20rpx;
  }

  .member-cont {
    min-height: 100%;
    height: 100%;
    display:flex;
    flex-direction: column;
    padding-bottom: 100rpx;
    box-sizing: border-box;
    /*background-color: #f8f9fa;*/
  }
  .member-list{
    flex:1;
    overflow:hidden;
  }
  .create-FG {
    margin: 80rpx auto 0 auto;
    line-height: 80rpx;
    width: 670rpx;
    height: 80rpx;
    border: 1rpx solid #0090FF;
    box-shadow: 0 4rpx 8rpx 0 rgba(0,144,255,0.25);
    border-radius: 8rpx;
    font-size: 32rpx;
    color: #0390FF;
  }

  .unenter-tip {
    font-size: 26rpx;
    color: #666666;
    margin-top: 22rpx
  }

  .unenter {
    height: 100%;
    text-align: center;
    background-color: #FFF;
  }

  .unenter-img {
    height: 330rpx;
    width: 330rpx;
    margin: 0 auto;
    padding-top: 50rpx;
  }

  .unenter-img img {
    width: 100%;
    height: 100%;
  }

</style>
