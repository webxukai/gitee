<template>
  <div class='wrap'>
    <div class='name'>小程序</div>
    <div class='desc'>{{textData.desc}}</div>
    <div class='desc'>{{textData.info}}</div>
    <button open-type="getUserInfo" @getuserinfo="getUserinfo" class='login'>{{textData.Title}}</button>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import tip from '@/utils/tip'
export default {

  data () {
    return {
      
    }
  },
  computed:{
    ...mapGetters({
      textData:'getloginData'
    })
  },
  methods:{
    getUserinfo(e){
      if(e.mp.detail.rawData){// 获取信息成功
        getApp().globalData.userInfo = e.mp.detail;
        wx.reLaunch({url:this.$root.$mp.query.to})
      }
      else{
        tip.tip('请授权,否则无法使用该应用')
      }
    }
  },
  created () {
   
  },
  onShow(){
    wx.setNavigationBarTitle({
      title:this.textData.Title
    })
  }
}
</script>

<style>
.wrap{
  position: absolute;
  width: 80%;
  top:50%;
  left:50%;
  transform: translate(-50%,-50%);
  text-align: center;
}
.name{
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}
.desc{
  font-size: 24rpx;
  margin:10rpx 0;
  color: #666;
}
.login{
  background: #1aad19;
  color: #fff;
  margin-top: 30rpx;
}
</style>
