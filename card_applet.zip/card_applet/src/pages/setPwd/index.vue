<template>
  <div class='wrap'>
    <div v-if="step == 1">
      <div class='header'>设置密码</div>
      <div class='tip'>请您输入需要设置的密码</div>
      <div>
        <div class='label'>6位数密码</div>
        <six @end="getPwd" ref='six'/>
      </div>
    </div>
    <div v-if="step == 2">
      <div class='header'>重复密码</div>
      <div class='tip'>请您验证刚刚输入的密码</div>
      <div>
        <div class='label'>6位数密码</div>
        <six @end="getrePwd" ref='six2'/>
      </div>
    </div>
  </div>
</template>

<script>
import net from '@/utils/net'
import tip from '@/utils/tip'
import six from '@/components/six'
export default {
  data(){
    return {
      step:1,
      pwd:"",
      repwd:"",
      phoneInfo:{
        mobile:"",
        code:"",
        codeId:""
      }
    }
  },
  components:{
    six
  },
  methods:{
    getPwd(pwd){
      this.pwd = pwd
      this.step = 2;
      this.$refs.six.empty()
    },
    // 切换免密
    async payFree(payPwd){
      var result = await net.put({
        url:'/memberMiniprogram/zone/user/pay-free',
        data:{
          free:0,
          payPwd
        },
        showLoading:false
      })
      tip.loaded();
      if(result.status == 2){
        tip.tip('设置成功');
      }
      else{
        tip.tip('取消免密失败')
      }
      setTimeout(()=>{
        wx.navigateBack({
          delta:2
        })
      },1000)
    },
    async getrePwd(pwd){
      this.repwd = pwd;
      if(pwd != this.pwd){
        tip.tip('俩次输入密码不一致');
        this.$refs.six2.empty()
      }
      else{
        tip.loading('设置中...')
        try{
          var result = await net.put({
            url:'/memberMiniprogram/zone/user/pay-pwd',
            data:{
              ...this.phoneInfo,
              newPayPwd:this.pwd
            },
            showLoading:false
          })
          if(result){
            this.payFree(this.pwd)
          }
          else{
            tip.tip('设置密码失败');
            this.step = 1;
            this.pwd = '';
            this.repwd = '';
            this.$refs.six2.empty()
          }
        }catch(e){
          this.step = 1;
          this.pwd = '';
          this.repwd = '';
          this.$refs.six2.empty()
        }
      }
    },
  },
  onLoad(){
    var phoneInfo = this.$root.$mp.query.info // 修改密码需要验证手机号，第一次设置不需要
    if(phoneInfo){
      this.phoneInfo = JSON.parse(phoneInfo);
    }
  },
  onUnload(){
    this.step = 1;
    this.pwd = '';
    this.repwd = '';
  }
}
</script>

<style scoped>
  .wrap{
    height: 100%;
    background: #fff;
    padding: 45rpx 40rpx 0;
    box-sizing: border-box;
    position: relative;
  }
  .header{
    font-size: 48rpx;
    color: #000000;
    margin-bottom:45rpx;
  }
  .tip{
    font-size: 26rpx;
    color: #999999;
    margin-bottom: 90rpx;
  }
  .label{
    font-size: 26rpx;
    color: #CCCCCC;
    margin-bottom: 20rpx;
  }
</style>
