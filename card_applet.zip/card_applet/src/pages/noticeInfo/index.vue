<template>
  <div class='wrap'>
    <div class='title'>{{info.title}}</div>
    <div class='auth'>作者： {{info.createMan}}</div>
    <div class='content'>
      {{info.content}}
    </div>
  </div>
</template>

<script>
import tip from '@/utils/tip'
export default {

  data () {
    return {
      info:''
    }
  },
  methods:{
  },
  onLoad(){
    this.info = JSON.parse(this.$root.$mp.query.info)
  }
}
</script>

<style>
.wrap{
  height: 100%;
  background: #fff;
  padding:20rpx;
  box-sizing: border-box;
}

.title{
  text-align: center;
  color: #666;
  font-size: 32rpx;
}
.auth{
  font-size: 24rpx;
  text-align: right;
  color: #666;
  margin-top:20rpx;
  margin-bottom:50rpx;
}
.content{
  font-size: 28rpx;
  color: #666;
  text-indent: 2em;
}
</style>
