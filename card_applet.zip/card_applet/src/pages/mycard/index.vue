<template>

<div class='wrap' v-if="init">

    <div class="nocard" v-if="!cardList.length">

      <img src="/static/no-card.png" />

      <div class="no-card-tip">暂未绑定任何实体卡</div>

      <div class="add-group-conf" @click="toBind">去绑卡</div>

    </div>

    <div class="card-list" v-else>
      <div v-for="(item,index) in cardList" :key="index">
        <div class="gap"></div>
        <div class="card-cont">
          <div class="card flexBox">
            <div class="flex1">
              <div class="card-num">{{item.cardKid}}</div>
              <img class="unbind" src="/static/unbind.png" alt="" @click="unBind(item.cardKid)">
            </div>
          </div>
        </div>
      </div>
      <div class="prime-btn" @click="toBind">添加卡</div>

    </div>

</div>

</template>

<script>
// Use Vuex
import store from '@/store'
import net from '@/utils/net'
import tip from '@/utils/tip'

export default {
  data(){
    return {
      init:false,
      cardList:[]
    }
  },
  methods: {
    // 获取实体卡
    async getCard(noload){
      var cardList = await net.get({
        url:'/memberMiniprogram/entity-card/all',
        showLoading:!noload
      })
      this.cardList = cardList
    },
    //解绑实体卡
    async unBind(cardKid){
      await tip.confirm('确认解绑改实体卡吗');
      await net.delete({
        url:'/memberMiniprogram/entity-card/',
        data:{
          card:cardKid
        },
        title:'解绑中...'
      })
      tip.tip('解绑成功')
      await this.getCard(false);
      tip.loaded();
    },
    // 绑定实体卡
    toBind(){
      var self = this;
      wx.scanCode({
        success: async (res) => {
          await net.put({
            url:"/memberMiniprogram/entity-card/",
            data:{
              card:res.result
            }
          })
          await self.getCard();
          tip.loaded();
        },
        fail:function(error){
          wx.getSystemInfo({
            success: function(res) {
              if (res.platform == "android") {
                // android扫一扫失败，跳回首页
                wx.switchTab({
                  url: '/pages/index/main',
                })
              } else {

              }
            }
          })
        }
      })
    }
  },
  async onLoad(){
    await this.getCard();
    tip.loaded()
    this.init = true;
  },
  onUnload(){
    this.init = false;
  }
}

</script>
<style>
  .wrap{
    height: 100%;
    background: #fff;
  }
  .prime-btn{
    margin: 60rpx auto;
  }

  .card-bank {
    font-size: 32rpx;
  }

  .card-type {
    font-size: 24rpx;
  }

  .card-num {
    font-size: 30rpx;
  }

  .card-img  img {
    width: 50rpx;
    height: 50rpx;
    border-radius: 50%;
    margin-top: 20rpx;
  }

  .card-img {
    width: 80rpx;
  }

  .card {
    position: relative;
    background-color: crimson;
    border-radius: 8rpx;
    color: #FFF;
    box-shadow:2rpx  2rpx  10rpx 2rpx rgba(0,0,0,.2);
    padding: 40rpx 20rpx;
  }

  .card-cont {
    padding:0 20rpx;
  }
  .unbind{
    position:absolute;
    right:20rpx;
    top:40rpx;
    width: 40rpx;
    height: 40rpx;
  }
  .add-group-conf {
    border-radius: 8rpx;
    font-size: 32rpx;
    color: #0390FF;
    width: 670rpx;
    height: 80rpx;
    line-height: 80rpx;
    text-align: center;
    margin: 85rpx auto 0 auto;
    border: 1rpx solid #0090FF;
    box-shadow: 0 4rpx 8rpx 0 rgba(0,144,255,0.25);
  }


  .nocard {
    text-align: center;
  }

  .nocard img {
    margin: 207rpx auto 45rpx auto;
    width: 420rpx;
    height: 272rpx;
  }

   .no-card-tip {
     font-size: 26rpx;
     color: #666666;
   }

</style>
