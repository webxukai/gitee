<template>
  <div>
    <div class="head-tip">将管理员制定给成员后退出家庭组</div>
    <div class="gap"></div>
    <radio-group class='list' @change="toUser">
      <div class="cell-cont" v-for="(item,index) in userList" :key='index'>
        <div class="cell flexBox">
          <div class="head-cont">
            <img :src="item.picture"/>
          </div>
          <div class="flex1">
            <div class="member-name">{{item.name}}</div>
            <div class="member-tel">{{item._phone}}</div>
          </div>
          <div class="check-cont">
            <radio class='checkbox' :value="item.userKid"/>
          </div>
        </div>
      </div>
    </radio-group>
    <div class="btn" @tap='toAnotherAdmin'>指定为管理员</div>
  </div>
</template>

<script>

  import net from '@/utils/net'
  import tip from '@/utils/tip'
  import base from '@/mixins/base'

  export default {
    data() {
      return {
        init: false,
        userKid:"",
        userList:[],
        anotherUserKid:"" //指定用户的id
      }
    },
    mixins: [base],
    methods: {
      // 获取指定用户的id
      toUser(e){
        this.anotherUserKid = e.mp.detail.value
      },
      //指定用户为管理员
      async toAnotherAdmin(){
        if(!this.anotherUserKid){
          tip.tip('必须指定为管理员');
          return;
        }
        var result = await net.post({
          url:'/memberMiniprogram/family/outFamilyGroup',
          data:{
            userKid:this.userKid,
            anotherUserKid:this.anotherUserKid
          }
        })
        tip.loaded()
        if(result.state == 1){
          tip.tip('退出成功')
          getApp().globalData.Meals_refalsh = true;
          getApp().globalData.Card_refalsh = true;
          wx.navigateBack({
            delta:2
          })
        }
        else{
          tip.tip('指定失败')
        }
      }
    },
    onLoad(){
      this.userList = JSON.parse(this.$root.$mp.query.userList)
      this.userKid = getApp().globalData.userKid;
    }
  }

</script>

<style scoped>

  .btn {
    font-size: 32rpx;
    width: 670rpx;
    height: 80rpx;
    line-height: 80rpx;
    background: #0390FF;
    border-radius: 8rpx;
    color: #FFF;
    margin: 80rpx auto;
    text-align: center;
  }


  .check-cont {
    width: 50rpx;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .checkbox{
    margin-top: -10rpx;
  }
  .member-tel {
    font-size: 20rpx;
    color: #999999;
  }

  .member-name {
    font-size: 30rpx;
    color: #333333;
    margin-top: 25rpx;
  }

  .head-cont img {
    border-radius: 50%;
    height: 72rpx;
    width: 72rpx;
    margin: 25rpx 0;
    overflow: hidden;
  }

  .head-cont {
    width: 90rpx;
  }

  .head-tip {
    background-color: #FFD9D8;
    height: 70rpx;
    line-height: 70rpx;
    font-size: 28rpx;
    color: #FF3A31;
    text-align: center;
  }
  .list .cell-cont:last-child .cell{
    border:none;
  }
  .cell-cont {
    padding: 0 20rpx;
    background-color: #FFF;
  }

  .cell {
    height: 120rpx;
    border-bottom: 1rpx solid #DBDBDB;
  }

</style>
