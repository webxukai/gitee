<template>
  <div class="counter-warp" v-if="init">
    <div class='top'>
      <div class="shop-item-cont">
        <div class="shop-item">
          <div class="shop-name-cont flexBox">
            <div class="shop-owner-icon">
              <img src="/static/list1.png"/>
            </div>
            <div class='desc'>
              <div class="shop-owner-name">{{info.merchantName}}</div>
              <div class="shop-discont">{{info.properties}}</div>
            </div>
            <div class="flex1 shop-type">
              <span class="kid">{{info.kid}}</span>
              <span v-if="userKid == info.userKid">个人</span>
              <span v-else>家庭组-{{info.userName}}的卡</span>
            </div>
          </div>
          <div class="last-tip"> {{info.balance != null ? '剩余总金额 （元)' : '剩余积分'}}</div>
          <div class="last-money">{{info.balance != null ? info.sum : info.integral}}</div>
          <div class="integral shop-tip" v-if="info.balance != null && info.integral != null">
            <p>积分: {{info.integral}}</p>
          </div>
          <div class="shop-tip" v-if="info.giveMoney!=null">其中赠送金额{{info.giveMoney}}元 （{{info.giveMoneyTime == '2000-01-01 00:00:00' ? '永久有效' : info.giveMoneyTime + '到期'}}）</div>
        </div>
      </div>
    </div>
    <div class='billWrap'>
      <div class='header'>账单</div>
      <scroll-view class='bills' @scrolltolower="loadMore" scroll-y>
        <div class='bill' v-for="(item,index) in bills " @tap="toDetail(item)" :key="index">
            <div class='billtop'>
              <div class='title'>
                {{
                  (item.type == 0 && item.operatorUserKid == userKid) ? "[个人消费]":
                  (item.type == 0 && item.operatorUserKid != userKid) ? "[家庭组-"+item.operatorUserName+"消费]" :
                  (item.type == 1 && item.operatorUserKid == userKid) ? "[个人充值]":
                  "[家庭组-"+item.operatorUserName+"充值]"
                }}</div>
              <div class='money'>{{item.type==0 ? '-':'+'}}{{item.sum}}</div>
            </div>
            <div class='billbottom'>
              <div class='time'>{{item.createTime}}</div>
              <div class='tip' v-if="item.giveMoney!=null">其中{{item.type==0 ? '-':'+'}}{{item.giveMoney}}赠送金额</div>
            </div>
        </div>
        <div class='nocon' v-if="!bills.length">暂无账单信息</div>
      </scroll-view>
    </div>
    <div class='unbind' @tap='unbind' v-if="userKid == info.userKid">解绑此卡</div>
  </div>
</template>

<script>
import net from '@/utils/net'
import tip from '@/utils/tip'
import moment from 'moment'
import { accAdd } from '@/utils'
export default {
  data(){
    return {
      init:false,
      info:null,//卡信息
      userKid:"",
      end:false,// 是否加载完
      queryCare:{
        limit:10,
        page:1,
        setMealKid:"",
        month:""
      },
      bills:[]
    }
  },
  methods: {
    toDetail(info){
      if(info.type == 0){
        wx.navigateTo({
          url:'/pages/cousumRecord/main?info='+JSON.stringify(info)
        })
      }
      else{
        wx.navigateTo({
          url:'/pages/as_recharge/main?info='+JSON.stringify(info)
        })
      }
    },
    async getBillList(more){
      var bills = await net.post({
        url:'/memberMiniprogram/bill/',
        data:this.queryCare
      })
      bills = bills.cardBillList
      bills.forEach((item)=>{
        item.createTime = moment(item.createTime).format('YYYY-MM-DD HH:mm')
        item.sum = accAdd(item.money,item.giveMoney || 0)
      })
      if(bills.length < 10){
        this.end = true;
      }
      if(more){
        this.bills = [...this.bills,...bills]
      }
      else{
        this.bills = bills
      }
    },
    //加载更多
    async loadMore(){
      if(this.end) return; // 加载完成直接return

      this.queryCare.page ++;
      await this.getBillList(true)
      tip.loaded();
    },
    async unbind(){
      var result = await net.delete({
        url:'/memberMiniprogram/zone/set-meal',
        data:{
          userSetMealKid:this.queryCare.setMealKid
        }
      })
      tip.loaded();
      if(result.userSetMealKid){
        tip.tip('解绑成功');
        getApp().globalData.Meals_refalsh = true;
        getApp().globalData.Card_refalsh = true;
        wx.navigateBack();
      }
    }
  },
  async onLoad(){
    var info = JSON.parse(this.$root.$mp.query.info)
    this.info = info;
    this.queryCare.setMealKid = info.kid;
    this.userKid = getApp().globalData.userKid
    await this.getBillList();
    tip.loaded()
    this.init = true;
  },
  onUnload(){
    this.init = false;
    this.queryCare.page = 1;
    this.end = false;
  }
}

</script>
<style scoped>
  .nocon{
    font-size: 26rpx;
    color: #666666;
    text-align: center;
    padding-top: 40rpx;
  }
  .counter-warp{
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .top{
    height: 368rpx;
    box-sizing: border-box;
    padding-top: 20rpx;
  }
  .shop-item-cont {
    padding: 0 20rpx;
  }

  .shop-item {
    border-radius: 8rpx;
    background:linear-gradient(-127deg, #50BCFC 0%, #4F9FFC 100%);
    padding-bottom: 20rpx;
    text-align: center;
    box-shadow: 0 10rpx 20rpx rgba(79,159,252,0.5);
  }

  .shop-name-cont {
  }
  .desc{
    margin-top: 14rpx;
    height: 30rpx;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .shop-owner-icon {
    text-align: right;
    height: 80rpx;
    width: 80rpx;
    padding-right: 10rpx;
  }
  .shop-type.integral{
    font-size: 18rpx;
    color: #fff;
  }
  .shop-owner-icon img {
    width: 60rpx;
    height: 60rpx;
    border-radius: 50%;
    overflow: hidden;
    margin-top: 14rpx;
  }

  .shop-owner-name {
    font-size: 26rpx;
    color: #fff;
    text-align: left;
  }

  .shop-discont {
    font-size: 18rpx;
    color: #cdebfe;
    text-align: left;
  }

  .shop-type {
    text-align: right;
  }
  .shop-type span {
    font-size: 18rpx;
    color: #fff;
    background-image: linear-gradient(-141deg, #FD9381 3%, #FD5D55 100%);
    padding: 0 6rpx;
    border-radius: 4rpx;
    margin: 0 20rpx;
    line-height: 100rpx;
  }
  .shop-type .kid{
    color: #fff;
    font-size: 18rpx;
    background: transparent;
    margin:0;
  }
  .last-tip {
    font-size: 24rpx;
    color: #fff;
    line-height: 55rpx;
  }

  .last-money {
    font-size: 60rpx;
    font-weight: bold;
    color: #fff;
  }

  .shop-tip {
    font-size: 22rpx;
    color: #fff;
  }
  .billWrap{
    flex:1;
    background: #fff;
    display: flex;
    flex-direction: column;
  }
  .header{
    border-bottom: 1rpx solid #e5e5e5;
    padding:0 20rpx;
    line-height: 70rpx;
    font-size: 30rpx;
    color: #333333;
  }
  .bills{
    padding-left: 20rpx;
    flex:1;
    box-sizing: border-box;
    overflow: hidden;
  }
  .bill{
    height: 130rpx;
    border-bottom: 1rpx solid #e5e5e5;
    padding-right:20rpx;
    display: flex;
    flex-direction: column;
    justify-content:center;
  }
  .bill .billtop{
    font-size: 30rpx;
    color:#333333;
  }
  .bill .billbottom{
    font-size: 22rpx;
    margin-top: 10rpx;
  }
  .time{
    color: #999999;
  }
  .tip{
    color: #ff9800;
    text-align: right;
  }
  .money{
    font-weight: bold;
    text-align: right;
  }
  .bill .billtop > div,.bill .billbottom > div{
    display: inline-block;
    width: 50%;
  }
  .unbind{
    height: 98rpx;
    background: #FF3A31;
    font-size: 32rpx;
    color: #FFFFFF;
    text-align: center;
    line-height: 98rpx;
  }
</style>
