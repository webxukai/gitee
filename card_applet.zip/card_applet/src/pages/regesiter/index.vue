<template>
  <div content="main-cont" :hidden="!init">

    <div class="main-tip">
      Hi, 首次登陆请补充手机号
    </div>
    <div class="input-cont">
      <div class="line flexBox">
        <div class="line-icon">
          <img src="/static/mobile.png"/>
        </div>
        <div class="flex1">
          <input type="number" maxlength="11" placeholder="请输入手机号" placeholder-style="color:#D9D9D9;font-size:32rpx" :value="mobile" @input="Ipt"/>
        </div>
        <div :class="{'get-code':true,able:canGetCode && !interval}" @tap="getCode">{{codeMsg}}</div>
      </div>
      <div class="line flexBox">
        <div class="line-icon">
          <img src="/static/code.png"/>
        </div>
        <div class="flex1">
          <input type="number" placeholder="请输入验证码" placeholder-style="color:#D9D9D9;font-size:32rpx" :value="code" @input="iptCode"/>
        </div>
      </div>
    </div>
    <div :class="{'btn':true,unLogin:!(canGetCode && code.length == 6)}" @tap='login'>登录</div>
  </div>

</template>

<script>

  import card from '@/components/card'
  import net from '@/utils/net'
  import base from '@/mixins/base'
  import tip from '@/utils/tip'

  export default {
    data() {
      return {
        mobile:'',
        code:'',
        time:60,// 倒计时秒数
        interval:null,
        userInfo:null,
        codeId:'',
        init:false, // 是否初始化完成
        token:''
      }
    },
    mixins: [base],
    components: {
      card
    },
    computed: {
      canGetCode(){
        return this.mobile.length == 11
      },
      codeMsg(){
        return this.interval ? `${this.time}秒后重新获取`:'获取验证码'
      },
    },
    methods: {
      // 获取mobile
      Ipt(e){
        this.mobile = e.mp.detail.value;
      },
      // 获取code
      iptCode(e){
        this.code = e.mp.detail.value
      },
      //获取code
      async getCode(){
        if(!this.canGetCode || this.interval){
          return;
        }
        var result = await net.post({
          url:'/memberMiniprogram/index/getCode',
          data:{
            mobile:this.mobile
          }
        })
        this.codeId = result.codeId;
        tip.loaded();
        this.runTime();
      },
      // 验证码倒计时
      runTime(){
        this.interval = setInterval(()=>{
          this.time --;
          if(this.time == 0){
            this.time = 60;
            clearInterval(this.interval);
            this.interval = null;
            return;
          }
        },1000)
      },
      // 微信登陆
      wxLogin(){
        return new Promise((resolve,reject)=>{
          wx.login({
            success:function({code}){
              resolve(code)
            },
            fail:function(err){
              tip.tip('登录失败')
              reject(err);
            }
          })
        })
      },
      async login(){
        if(!(this.canGetCode && this.code.length == 6)){
          return;
        }
        else{
          // 校验验证码
          var result = await net.post({
            url:'/memberMiniprogram/index/checkCode',
            data:{
              code:this.code,
              codeId:this.codeId,
              mobile:this.mobile,
              avatarUrl:this.userInfo.avatarUrl,
              nickName:this.userInfo.nickName,
              openId:this.userInfo.openId,
              unionId:this.userInfo.unionId
            }
          })
          tip.loaded();
          if(result.state == 1){
            console.log(result)
            getApp().globalData.userInfo = result;
            getApp().globalData.token = result.token;
            getApp().globalData.userKid = result.userKid;
            wx.switchTab({
              url:'/pages/index/main'
            })
          }
          else{
            tip.tip('验证码不正确')
          }
        }
      }
    },
    async onLoad(){
      tip.loading();
      var code = await this.wxLogin();
      var userInfo = await this.getUserInfo('/pages/regesiter/main')
      var data = await net.post({
        url:'/memberMiniprogram/index/userLogin',
        data:{
          code,
          data:userInfo.encryptedData,
          iv:userInfo.iv
        }
      })
      tip.loaded();
      getApp().globalData.token = data.token;
      getApp().globalData.userKid = data.userKid;
      getApp().globalData.userInfo = data;
      this.userInfo = data;
      if(data.state == 0){ // 没完善手机号
        this.init = true;
      }
      else{ // 已完善直接跳转首页
        wx.switchTab({
          url:'/pages/index/main'
        })
      }
    }
  }

</script>

<style scoped>

  .get-code {
    font-size: 24rpx;
    color: #D9D9D9;
    text-align: right;
    min-width: 160rpx;
  }

  .able {
    color: rgba(2, 103, 255, 0.50);
  }
  .line:first-child{
    border-bottom: 1rpx solid #E5E5E5;
    margin-bottom: 25rpx;
  }
  .line input {
    display: block;
    box-sizing: border-box;
    width: 100%;
    height: 110rpx;
    font-size: 32rpx;
    line-height: 110rpx;
    padding-left: 35rpx;
  }
  .line {
    height: 110rpx;
    line-height: 110rpx;
  }

  .line-icon::after {
    position: absolute;
    right: 0;
    top: 50%;
    display: block;
    content: ' ';
    width: 2rpx;
    height: 30rpx;
    margin-top: -15rpx;
    background-color: rgba(2, 103, 255, 0.50);
  }

  .line-icon {
    position: relative;
  }

  .line-icon img {
    width: 32rpx;
    height: 44rpx;
    margin-top: 32rpx;
    margin-right: 30rpx;
  }

  .btn {
    height: 80rpx;
    background: #0390FF;
    border-radius: 8rpx;
    width: 670rpx;
    text-align: center;
    margin: 100rpx auto 0 auto;
    font-size: 32rpx;
    color: #FFFFFF;
    line-height: 80rpx;
  }

  .btn.unLogin {
    background: #D9D9D9;
    color: #999999;
  }

  .main-cont {
    text-align: center;
  }

  .main-tip {
    text-align: center;
    font-size: 40rpx;
    color: #0390FF;
    line-height: 255rpx;
    font-weight: bold;
  }

  .input-cont {
    background-color: #FFF;
    width: 670rpx;
    margin: 0 auto;
    box-shadow: 0 0 30rpx 0 rgba(3,106,255,0.12);
    border-radius: 4rpx;
    padding:0 40rpx;
    box-sizing: border-box;
  }

</style>
