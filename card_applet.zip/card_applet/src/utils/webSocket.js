var socket = {
	_socket:null,
	connect:function(option){
		this._socket = wx.connectSocket({
          ...option
        })
        return new Promise((resolve,reject)=>{
        	this._socket.onOpen(()=>{
        		resolve()
        	})
        	this._socket.onError(()=>{
        		reject();
        	})
        })
	},
	reciveMsg:function(){
		return new Promise((resolve,reject)=>{
			this._socket.onMessage((res)=>{
				resolve(res)
			})
		})
	},
	sendMsg:function(msg){
		return new Promise((resolve,reject)=>{
			this._socket.send({
				data:msg,
				success:function(){
					resolve('success')
				},
				fail:function(){
					reject()
				}
			})
		})
	},
	close:function(){
		return new Promise((resolve,reject)=>{
			this._socket.close({
				success:function(){
					resolve('success')
				},
				fail:function(err){
					reject(err)
				}
			})
		})
	},
	onClose:function(cb){
		this._socket.onClose(()=>{
			cb && cb();
		})
	}
}
export default socket;