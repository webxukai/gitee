'use strict'
import tip from './tip.js'
import store from '@/store'
var i18 = {
  zh:{
    error:"网络请求超时"
  },
  en:{
    error:"Network timeout"
  }
},
// rootUrl = 'http://192.168.0.6:8901',
// rootUrl = 'http://106.15.90.68:8899',
  rootUrl = 'https://jky.s.jhscale.net',
imgUrl = 'http://47.100.99.28:8086/fileService/file/downloadFile?path=',
// rootUrl = 'http://192.168.0.6:8899',
// socketUrl = 'ws://192.168.0.232:8904',
socketUrl = '',
socketType = {
  BINGDING:"binding",
  PAYCODE:"payCode",
  GETPAYCODE:"getPayCode",
  HEARTBEAT:"heartbeat",
  NEWPAYCODE:"newPayCode",
  SELECTSETMEAL:"selectSetMeal",
  PAYPWD:"payPwd",
  CANCELPAY:"cancelPay",
  BEINGPAID:'beingPaid',
  CANCELLOGIN:'cancelLogin',
  PAID:'paid',
  NONPAID:'nonPaid',
  EXCEPTION:'exception'
}
export {
  rootUrl,
  socketUrl,
  socketType,
  imgUrl
}
// http 异步请求的封装，用来向服务器的接口发送RESTful类型的数据。
export default {
    async get({
      url = '',
      data = {},
      defaultVal = {},
      showLoading = true,
      title = "加载中"
    }) {
      const method = 'GET'
      return await this._ajax({url: url, data: data, method: method, defaultVal: defaultVal, showLoading: showLoading,title})
    },

    async post({
      url = '',
      data = {},
      defaultVal = {},
      showLoading = true,
      title = "加载中"
    }) {
      const method = 'POST'
      return await this._ajax({url: url, data: data, method: method, defaultVal: defaultVal, showLoading: showLoading,title})
    },

    async put({
      url = '',
      data = {},
      defaultVal = {},
      showLoading = true,
      title = "加载中"
    }) {
      const method = 'PUT'

      return await this._ajax({url: url, data: data, method: method, defaultVal: defaultVal, showLoading: showLoading,title})
    },

    async delete({
      url = '',
      data = {},
      defaultVal = {},
      showLoading = true,
      title = "加载中"
    }) {
      const method = 'DELETE'
      return await this._ajax({url: url, data: data, method: method, defaultVal: defaultVal, showLoading: showLoading,title})
    },

    async _ajax({
      url = '',
      data = {},
      method = 'GET',
      defaultVal = {},
      showLoading = true,
      title = '加载中'
    }) {
      let retData = defaultVal
      if(showLoading){
        tip.loading(title);
      }
      else{
        wx.showNavigationBarLoading()
      }
      try {
        retData = await new Promise((resolve,reject)=>{
          wx.request({
            url: rootUrl+url+'?token='+getApp().globalData.token,
            method: method,
            data: data,
            success:function (ret){
              if (ret.statusCode === 200) {
                wx.hideNavigationBarLoading()
                // resolve(ret.data)
                if(ret.data.data.code == 40000){
                  resolve(ret.data.data.data)
                }
                else{
                  var msg = ret.data.data.msg;
                  tip.error(msg);
                  reject(msg)
                }
              } else {
                var obj = i18[store.state.page.lng]
                tip.error(obj.error)
                reject()
              }
            },
            fail:function(error){
              var obj = i18[store.state.page.lng]
              tip.error(obj.error)
              reject()
            }
          })
        })
      } catch (error) {
        wx.stopPullDownRefresh()
        throw error
      }
      return retData
    },

    // 上传文件
    async uploadImage({
      url = '',
      filePath = '',
      name = '',
      formData = {},
      defaultVal = {}
    }) {
      formData['media_type'] = 'image'
      return await this._uploadFile({url: url, filePath: filePath, name: name, formData: formData, defaultVal: defaultVal})
    },

    async uploadVideo({
      url = '',
      filePath = '',
      name = '',
      formData = {},
      defaultVal = {}
    }) {
      formData['media_type'] = 'video'
      return await this._uploadFile({url: url, filePath: filePath, name: name, formData: formData, defaultVal: defaultVal})
    },

    async _uploadFile({
      url = '',
      filePath = '',
      name = '',
      formData = {},
      defaultVal = {}
    }) {
      let retData = defaultVal
      try {
        let options = {
          url: rootUrl+url+'?token='+getApp().globalData.token,
          filePath: filePath,
          name: name,
          formData: formData
        }
        tip.loading();
        retData = await new Promise((resolve,reject)=>{
          wx.uploadFile({
            ...options,
            success:function (ret){
              if (ret.statusCode === 200) {
                resolve(ret.data)
              } else {
                reject(ret.data)
              }
            },
            fail:function(error){
              reject(error)
            }
          })
        })
      } catch (e) {
        console.log('something wrong: ', e)
        throw e
      } finally {}
      return retData
    }
  }
