<script>
  import {mapGetters} from 'vuex'

  export default {
    computed: {
      ...mapGetters({
        'textData': 'gettabbarData',
      })
    },
    created() {
      // 调用API从本地缓存中获取数据
      const logs = wx.getStorageSync('logs') || []
      logs.unshift(Date.now())
      wx.setStorageSync('logs', logs)
      console.log('app created and cache logs by setStorageSync')
    },
    methods: {
      setTabbar() {
        Object.keys(this.textData).forEach((key, index) => {
          wx.setTabBarItem({
            index: index,
            text: this.textData[key]
          })
        })
      }
    }
  }
</script>

<style>

  page {
    background-color: #f8f9fa;
    height: 100%;
  }

  .container {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    padding: 200rpx 0;
    box-sizing: border-box;
  }
  .navigator-hover{
    background: transparent;
    opacity: 1;
  }
  /* this rule will be remove */
  * {
    font-family: PingFangSC-Regular Microsoft YaHei;
    transition: width 2s;
    -moz-transition: width 2s;
    -webkit-transition: width 2s;
    -o-transition: width 2s;
  }

  .flexBox {
    display: flex;
  }

  .flex1 {
    flex: 1;
  }

  .clFlexBox {
    display: flex;
    flex-direction: column;
  }

  .gap {
    height: 20rpx;
  }

  .bg {
    background-color: #f8f9fa;
  }


  .prime-btn {
    background: #0390FF;
    border-radius: 8rpx;
    width: 670rpx;
    height: 80rpx;
    line-height: 80rpx;
    text-align: center;
    font-size: 32rpx;
    color: #FFFFFF;
  }

  .dange-btn {
    background: #FF3A31;
    border-radius: 8rpx;
    width: 670rpx;
    height: 80rpx;
    line-height: 80rpx;
    text-align: center;
    font-size: 32rpx;
    color: #FFFFFF;
  }

  .prime-btn:active{
    background: #0071CA;
  }

  .imgBG {
    position: absolute;
    display: block;
    width: 100%;
    left: 0;
    top: -128rpx;
    height: 1334rpx;
  }

  .mainCont {
    position: absolute;
    display: block;
    width: 100%;
    left: 0;
    top: 0;
    height: 1334rpx;
    opacity: .5;
  }
    /*  重写 checkbox 样式  */
  /* 未选中的 背景样式 */
  checkbox .wx-checkbox-input{
     border-radius: 50%;/* 圆角 */
     width: 30rpx; /* 背景的宽 */
     height: 30rpx; /* 背景的高 */
  }
  /* 选中后的 背景样式*/
  checkbox .wx-checkbox-input.wx-checkbox-input-checked{
     border: none;
     background: red;
     background-color:#0390FF;
     border-color:#0390FF;
  }
  /* 选中后的 对勾样式 （白色对勾 可根据UI需求自己修改） */
  checkbox .wx-checkbox-input.wx-checkbox-input-checked::before{
     border-radius: 50%;/* 圆角 */
     width: 40rpx;/* 选中后对勾大小，不要超过背景的尺寸 */
     height: 40rpx;/* 选中后对勾大小，不要超过背景的尺寸 */
     line-height: 40rpx;
     text-align: center;
     font-size:20rpx; /* 对勾大小 30rpx */
     color:#fff; /* 对勾颜色 白色 */
     background: transparent;
     transform:translate(-50%, -50%) scale(1);
     -webkit-transform:translate(-50%, -50%) scale(1);
  }
    /*  重写 radio 样式  */
  /* 未选中的 背景样式 */
  radio .wx-radio-input{
     border-radius: 50%;/* 圆角 */
     width: 30rpx; /* 背景的宽 */
     height: 30rpx; /* 背景的高 */
     overflow: hidden;
  }
  /* 选中后的 背景样式  */
  radio .wx-radio-input.wx-radio-input-checked{
     border: none;
     background-color:#0390FF;
     border-color:#0390FF;
  }
  /* 选中后的 对勾样式 （白色对勾 可根据UI需求自己修改） */
  radio .wx-radio-input.wx-radio-input-checked::before{
     border-radius: 50%;/* 圆角 */
     width: 40rpx;/* 选中后对勾大小，不要超过背景的尺寸 */
     height: 40rpx;/* 选中后对勾大小，不要超过背景的尺寸 */
     line-height: 40rpx;
     text-align: center;
     font-size:20rpx; /* 对勾大小 30rpx */
     color:#fff; /* 对勾颜色 白色 */
     background: #0390FF;
     transform:translate(-50%, -50%) scale(1);
     -webkit-transform:translate(-50%, -50%) scale(1);
  }
</style>
