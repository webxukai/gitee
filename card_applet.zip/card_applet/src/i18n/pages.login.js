// 授权页面翻译
const index = {
  zh: {
    'Title':'授权登录',
    'desc':"请求获取您的如下公开信息",
    'info':'(昵称丶头像)等'
  },
  en: {
    'Title':"Login",
    'desc':"get info:",
    'info':'(昵称丶头像)等'
  }
}

module.exports = index
