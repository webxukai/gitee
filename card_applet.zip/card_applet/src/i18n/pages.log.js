// 日志页面翻译
const index = {
  zh: {
    'Title':'启动日志',
  },
  en: {
    'Title':"log"
  }
}

module.exports = index
