// 首页翻译
const index = {
  zh: {
    'Title': '首页',
    'text': "去vuex页面",
    'lng': "切换语言",
    'req': "测试请求"
  },
  en: {
    'Title': "home",
    'text': "go vuex page",
    'lng': "change lng",
    'req': "test request"
  }
}

module.exports = index
