// tabbar翻译
const index = {
  zh: {
    'tab0': '首页',
    'tab1': '账单',
    'tab2': '我的'
  },
  en: {
    'tab0': 'home',
    'tab1': 'bill',
    'tab2': 'mine'
  }
}

module.exports = index
