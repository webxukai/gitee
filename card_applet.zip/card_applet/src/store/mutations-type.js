export const ASYNC_ADD = 'ASYNC_ADD' // 异步增加count
export const CHANGE_LNG = 'CHANGE_LNG' // 改变语言
