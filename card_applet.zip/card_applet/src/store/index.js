import Vue from 'vue'
import Vuex from 'vuex'
import page from './modules/pageModule'
import bus from './modules/busModule'
Vue.use(Vuex)


export default new Vuex.Store({
	modules:{
		page,
		bus
	}
})
