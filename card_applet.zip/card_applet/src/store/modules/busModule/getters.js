
export default {
	getCount:(state)=>{
      return state.count
    }
}