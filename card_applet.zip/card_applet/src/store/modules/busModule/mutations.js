import {
	ASYNC_ADD,
}from '@/store/mutations-type'

export default {
	[ASYNC_ADD](state){
		state.count ++;
	}

}