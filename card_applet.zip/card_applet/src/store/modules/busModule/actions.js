import {
	ASYNC_ADD
}from '@/store/mutations-type'

export default {
  	asyncAdd({commit}){
	    return new Promise((resolve)=>{
	      setTimeout(()=>{
	        commit(ASYNC_ADD);
	        resolve()
	      },2000)
	    })
    }
}
