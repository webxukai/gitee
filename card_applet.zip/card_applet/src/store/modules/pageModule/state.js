var data = wx.getStorageSync('page') ? JSON.parse(wx.getStorageSync('page')) : {lng:'zh'}
export default data