import indexData from '@/i18n/pages.index.js'
import loginData from '@/i18n/pages.login.js'
import tabBarData from '@/i18n/pages.tabBar.js'
import logData from '@/i18n/pages.log.js'
export default {
    getIndexData:({lng})=>{
    	return indexData[lng]
    },
    getloginData:({lng})=>{
    	return loginData[lng]
    },
    gettabbarData:({lng})=>{
    	return tabBarData[lng]
    },
    getlogData:({lng})=>{
    	return logData[lng]
    }
}