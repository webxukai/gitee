import {
	CHANGE_LNG
}from '@/store/mutations-type'

export default {
	[CHANGE_LNG](state){
		var lng = state.lng;
		if(lng == 'zh'){
			lng = 'en'
		}
		else{
			lng = 'zh'
		}
		state.lng = lng
		wx.setStorageSync('page',JSON.stringify(state));
	}
}