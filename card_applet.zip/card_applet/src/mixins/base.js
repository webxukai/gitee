
export default {
	data(){
		return {
			userInfo:{}
		}
	},
	methods:{
		getUserInfo:(path)=>{
			return new Promise((resolve,reject)=>{
				var userInfo = getApp().globalData.userInfo;
				if(userInfo){
					resolve(userInfo)
					return;
				}
				wx.getSetting({
					success:function(res){
						if (res.authSetting['scope.userInfo']) { // 有用户权限
							wx.getUserInfo({
					            success: (res) => {
					              getApp().globalData.userInfo = res
					              resolve(res);
					            },
					            fail:(e)=>{
					            	reject(e)
					            }
			          		})
 						}
 						else{
 							wx.redirectTo({url:'../login/main?to='+path})
 						}
					},
					fail:function(e){
						reject(e)
					}
				})
			})
		}
	}
};