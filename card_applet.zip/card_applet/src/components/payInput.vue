<template>
  <div v-if="showWrap" class='wrap'>
    <div class='mask' v-if="mask"></div>
    <div :class="[className,'pay-tool']">
      <div class="pay-tool-title border-bottom">
        <strong>请输入支付密码</strong>
        <div class="closeWrap" @tap="close">
        <img src='/static/close.png' class='close'>
        </div>
      </div>
      <div class="pay-tool-content">
        <div class="pay-tool-inputs">
          <div class="item" v-for="(i,index) in items" :key="index">
            <span class="icon_dot" v-if="password[i] !==undefined"></span>
          </div>
        </div>
      </div>
      <div class="pay-tool-keyboard">
        <ul>
          <li @tap="keyUpHandle(e,val)" v-for="(val,index) in keys" :key="index">
            {{ val }}
          </li>
          <li class="del" @click="delHandle">
            <img src="/static/dele.png">
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  const keys = () => [1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0]
  // let sendFlag = true // 防止重复发送密码
  export default {
    data() {
      return {
        items: [0, 1, 2, 3, 4, 5],
        keys: keys(),
        password: [],
        mask: false,
        className: "",
        showWrap: false
      }
    },
    methods: {
      backHandle() {
        this.clearPasswordHandle() // 返回时清除password
        this.$emit('backFnc') // 返回上级
      },
      keyUpHandle(e, val) {
        let len = this.password.length
        if (val === '' || len >= 6) return
        this.password.push(val)
        this.ajaxData()
      },
      delHandle() {
        if (this.password.length <= 0) return false
        this.password.shift()
      },
      ajaxData() {
        if (this.password.length >= 6) {
          var val = ''
          this.password.forEach((item) => {
            val += String(item)
          })
          this.$emit('end', val)
          this.hide();
        }
        return false
      },
      clearPasswordHandle: function () {
        this.password = []
      },
      show() {
        this.mask = true;
        this.showWrap = true;
        this.className = 'show'
      },
      close(){
        this.hide();
        this.$emit('close')
      },
      hide() {
        this.mask = false;
        this.className = 'hiden'
        setTimeout(() => {
          this.showWrap = false;
        }, 0.5)
        this.clearPasswordHandle()
      }
    }
  }

</script>

<style lang="less" scoped>
  .wrap {
    position: fixed;
    z-index: 99;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
  }

  .pay-tool {
    animation-fill-mode: both;
    animation-duration: 0.5s;
    animation-timing-function: ease;
  }

  .pay-tool.show {
    animation-name: slideIn;
  }

  .pay-tool.hiden {
    animation-name: slideOut;
  }

  .mask {
    position: fixed;
    z-index: 99;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.50)
  }

  .pay-tool {
    z-index: 999;
    position: fixed;
    height: 782rpx;
    width: 100%;
    left: 0;
    bottom: 0;
    background-color: #fff;
    overflow: hidden;
    &-title {
      position: relative;
      width: 100%;
      height: 90rpx;
      line-height: 90rpx;
      text-align: center;
      overflow: hidden;
      border-bottom: 1rpx solid #E5E5E5;
      .closeWrap{
        position: absolute;
        right:0;
        bottom:0;
        width:90rpx;
        height: 90rpx;
      }
      .close {
        width: 20rpx;
        height: 20rpx;
        position: absolute;
        top: 50%;
        margin-top: -10rpx;
        right: 30rpx;
      }
      strong {
        color: #333333;
        font-size: 30rpx;
      }
    }
    &-content {
      .pay-tool-inputs {
        width: 690rpx;
        height: 100rpx;
        margin: 40rpx auto 0;
        border: 1rpx solid #999999;
        border-radius: 10rpx;
        box-shadow: 0 0 1px #e6e6e6;
        display: flex;
        .item {
          width: 16.66666666%;
          height: 100%;
          border-right: 1rpx solid #999999;
          line-height: 100rpx;
          text-align: center;
          &:last-child {
            border-right: none;
          }
          .icon_dot {
            display: inline-block;
            width: 20rpx;
            height: 20rpx;
            background-color: #000;
            border-radius: 50%;
          }
        }
      }
      .pay-tool-link {
        padding: 0.53333333rem 0.8rem 0;
        text-align: right;
        .link {
          font-size: 0.66666666rem;
          color: #3c8cfb;
        }
      }
    }
    .pay-tool-keyboard {
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      ul {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        li {
          position: relative;
          width: 33.3333%;
          height: 120rpx;
          line-height: 120rpx;
          box-sizing: border-box;
          text-align: center;
          border-right: 1rpx solid #E5E5E5;
          border-bottom: 1rpx solid #E5E5E5;
          font-size: 50rpx;
          &:nth-child(1),
          &:nth-child(2),
          &:nth-child(3) {
            border-top: 1rpx solid #E5E5E5;
          }
          &:nth-child(3),
          &:nth-child(6),
          &:nth-child(9),
          &:nth-child(12) {
            border-right: none;
          }
          &:nth-child(10),
          &:nth-child(11),
          &:nth-child(12) {
            border-bottom: none;
          }
          &:nth-child(10),
          &:nth-child(12) {
            background: #E6E6E6;
          }
          &:active {
            background-color: #d1d4dd;
          }
          >img {
            width: 70rpx;
            height: 70rpx;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-top: -35rpx;
            margin-left: -35rpx;
          }
        }
      }
    }
  }

  @keyframes slideIn {
    0% {
      transform: translateY(100%);
      opacity: 0;
      display: block;
    }
    100% {
      transform: translateY(0);
      opacity: 1
    }
  }

  @keyframes slideOut {
    0% {
      opacity: 1
    }
    100% {
      transform: translateY(100%);
      opacity: 0;
      display: none;
    }
  }

</style>
