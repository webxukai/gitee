<template>
  <div class='wrap' :hidden="!showWrap">
    <div class="as-content">
      <div>
        <img class="as-img" src="/static/paying.png">
      </div>
      <div class="as-text">正在交易中</div>
      <button class="as-btn" @tap='unpaying'>取消操作</button>
    </div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
        showWrap:false
      }
    },
    methods: {
      unpaying() {
        this.$emit('cancle')
      },
      show(){
        this.showWrap = true;
      },
      hidden(){
        this.showWrap = false;
      }
    }
  }
</script>

<style  lang="less" scoped>
  .wrap{
      position:fixed;
      z-index: 9;
      width:100%;
      height:100%;
      left:0;
      top:0;
      background: rgba(0,0,0,0.5);
      padding:35% 5%;
  }
  .as-content{
    width:90%;
    height:600rpx;
    background:#fff;
    text-align:center;
    border-radius:10rpx;
  }
  .as-img{
    margin-top:100rpx;
    width:150rpx;
    height:150rpx;
  }
  .as-text{
    margin: 30rpx;
  }
  .as-btn{
    width:60%;
    margin-top:120rpx;
    background:#0390ff;
    color:rgba(255,255,255,1);
  }
  .pay-tool{
    animation-fill-mode:both;
    animation-duration: 0.5s;
    animation-timing-function:ease;
  }
  .pay-tool.show{
    animation-name: slideIn;
  }
  .pay-tool.hiden{
    animation-name: slideOut;
  }
  .mask{
    position:fixed;
    z-index: 99;
    width:100%;
    height:100%;
    background:rgba(0,0,0,0.50)
  }
  .pay-tool {
    z-index: 999;
    position: fixed;
    width:100%;
    left:0;
    background:rgba(0,0,0,0.5);
    overflow: hidden;
  }

</style>