<template>
  <div class='content'>
    <!-- 输入框（表格） -->
    <div :class='[!interval? "pay_number":"pay_number_interval",i_focus?"get_focus":"","wrap"]' @tap="set_focus" :style="{width:width,height:height}">
      <div :class='[i_focus && value_length >= item - 1 ?(!interval?"get_focus_dot":"get_focus_dot_interval"):(!interval?"password_dot":"password_dot_interval")]' v-for="(item,index) in value_num" :key="index">
        <div v-if="value_length == item - 1 && i_focus" class="cursor"></div>
        <div v-if="value_length >= item" :class="[see ?'':'dot']">{{see?val_arr[index]:""}}</div>
      </div>
    </div>

    <!-- 输入框（隐藏） -->
    <input :value="input_value" :focus="i_focus" :maxlength="value_num.length" type="number" class='input_container' placeholder="" @input="get_value" @focus="get_focus" @blur="blur" />
  </div>
</template>

<script>
export default {
  data(){
    var num = Array.apply(null,{length:this.num}).map((_,index)=>{
      return index+1
    })
    var val_arr = [];
    for (let i = 0; i < this.num; i++) {
      val_arr.push(this.value.substr(i, 1))
    }
    return {
      input_value:this.value, // 输入框值
      i_focus:this.focus, // 焦点
      val_arr:val_arr, // 格子值
      value_length:this.value.length, // 值的长度
      value_num:num  // 格子数  
    }
  },
  props: {
    // 是否显示间隔输入框
    interval:{
      type:Boolean,
      default:true
    },
    focus:{
      type:Boolean,
      default:false
    },
    // 格子数
    num:{
      type: Number,
      default: 6
    },
    // 是否明文
    see:{
      type:Boolean,
      default:true
    },
    width:{
      type:String,
      default:'100%'
    },
    height:{
      type:String,
      default:'100rpx'
    },
    value:{
      type:String,
      default:''
    }
  },
  watch:{
    value_length(value){
      this.$emit('input',this.input_value)
      if(value == this.num){ // 当到达最大格子数
        this.$emit('end',this.input_value)
      }
    }
  },
  methods: {

    // 获得焦点时
    get_focus() {
      this.i_focus = true;
    },

    // 失去焦点时
    blur() {
      this.i_focus = false;
    },

    // 点击聚焦
    set_focus() {
      this.i_focus = true;
    },

    empty(){
      this.input_value = '';
      this.val_arr = [];
      this.value_length = 0;
      this.i_focus = true;
    },
    // 获取输入框的值
    get_value(e) {
      // 设置空数组用于明文展现
      let val_arr = [];
      // 获取当前输入框的值
      let now_val = e.mp.detail.value
      // 遍历把每个数字加入数组
      for (let i = 0; i < this.num; i++) {
        val_arr.push(now_val.substr(i, 1))
      }
      
      // 获取输入框值的长度
      let value_length = e.mp.detail.value.length;
      // 更新数据
      this.val_arr = val_arr;
      this.input_value = now_val;
      this.value_length = value_length;
    },
  },
  onLoad(){

  },
  onUnload(){
    this.empty()
  }
}
</script>

<style scoped>
/* 支付密码框 */
.wrap > div{
  margin-left: -1rpx;
}
.wrap > div:first-child{
  margin-left: 0;
}
.pay_number {
  margin: 0 auto;
  display: flex;
  flex-direction: row;
  box-sizing: border-box;
  /* border-radius:10rpx; */
}
.pay_number_interval {
  margin: 0 auto;
  display: flex;
  flex-direction: row;
  box-sizing: border-box;
  justify-content: space-between;
  /* border:none; */
}

/* 第一个格子输入框 */
.content .noBorder{
   border-left:none; 
}


/* 单个格式样式 */

.password_dot {
  flex: 1;
  border: 1rpx solid #cfd4d3;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4rpx;
}

.password_dot_interval {
  flex: 1;
  border: 1rpx solid #cfd4d3;
  margin-right: 18rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4rpx;
}
.password_dot_interval:last-child{
  margin-right: 0;
}
/* 单个格式样式（聚焦的时候） */

.get_focus_dot {
  flex: 1;
  border: 1rpx solid #0390FF;
  display: flex;
  align-items: center;
  justify-content: center;
}

.get_focus_dot_interval {
  flex: 1;
  border: 1rpx solid #0390FF;
  margin-right: 18rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4rpx;
}
.get_focus_dot_interval:last-child{
  margin-right: 0;
}
/* 模拟光标 */

.cursor {
  width: 2rpx;
  height: 56rpx;
  background-color: #0390FF;
  animation: focus 0.7s infinite;
}

/* 光标动画 */

@keyframes focus {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}

/* 格式中的点 */

.dot {
  width: 20rpx;
  height: 20rpx;
  background-color: #000;
  border-radius: 50%;
}

/* 输入框 */

.input_container {
  height: 0;
  width: 0;
  min-height: 0;
  position: relative;
  text-indent: -999em;
  left: -100%;
}

</style>
