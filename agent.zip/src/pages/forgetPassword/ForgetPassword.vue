<template>
    <div>
        <ForgetPasswordForgetPassword />
    </div>
</template>

<script>
import ForgetPasswordForgetPassword from './components/ForgetPassword'
export default {
name:'ForgetPassword',
components:{
ForgetPasswordForgetPassword
}
}
</script>

<style>

</style>
