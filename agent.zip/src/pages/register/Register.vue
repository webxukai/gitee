<template>
    <div>
        <RegisterRegister  />
    </div>
</template>

<script>
import RegisterRegister from './components/Register'
export default {
name:'Register',
components:{
RegisterRegister 
}
}
</script>

<style>

</style>
