<template>
    <div>
        <LoginLogin />
    </div>
</template>

<script>
import LoginLogin from './components/Login'
export default {
name:'Login',
components:{
LoginLogin
}
}
</script>

<style>

</style>
