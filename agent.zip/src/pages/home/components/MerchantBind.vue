<template>
    <div>
        <div class="wrapper"></div>
    </div>
</template>

<script>
export default {
name:"HomeMerchantBind"
}
</script>

<style lang="stylus" scoped>
.wrapper
    width 30%
    height 100%
    background-color red
</style>
